/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _pfilemon_h_
#define _pfilemon_h_

#include <pclasses/pexport.h>
#include <pclasses/psignal.h>
#include <pclasses/pexception.h>

namespace P {

//! Filesystem monitor class
/*!
  A class that can be used to monitor the filesystem for changes.
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PCORE_EXPORT FileMonitor {
  public:
    FileMonitor();
    ~FileMonitor();

    void addDir(const char* path);
    void removeDir(const char* path);

    bool isMonitored(const char* path) const;

    //! Filesystem change event
    /*!
      \ingroup core
    */
    class PCORE_EXPORT Event {
      friend class FileMonitor;
      public:

        //! Change-event type
        enum type_t {
          None,
          Changed,    /*!< File/directory has changed */
          Created,    /*!< File/directory has been created */
          Deleted     /*!< File/directory has been deleted */
        };

        Event();
        Event(type_t t, const char* path);
        Event(const Event& e);
        ~Event();

        inline type_t type() const
        { return m_type; }

        inline const std::string& path() const
        { return m_path; }

        Event& operator=(const Event& e);

      private:
        type_t      m_type;
        std::string m_path;
    };

    bool wait(Event& e, unsigned int timeout);

  private:
    struct file_monitor_handle_t;
    file_monitor_handle_t*  m_handle;
};

}

#endif
