/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _ptypes_h_
#define _ptypes_h_

#include <pclasses/config.h>
#include <sys/types.h>
#include <stddef.h>

#ifdef WIN32
  typedef int ssize_t;
#endif

namespace P {

typedef char int8_t;
typedef unsigned char uint8_t;

#if SIZEOF_SHORT == 2
  typedef short int16_t;
  typedef unsigned short uint16_t;
#elif SIZEOF_INT == 2
  typedef int int16_t;
  typedef unsigned int uint16_t;
#elif SIZEOF_LONG_INT == 2
  typedef long int int16_t;
  typedef unsigned long int uint16_t;
#endif

#if SIZEOF_SHORT == 4
  typedef short int32_t;
  typedef unsigned short uint32_t;
#elif SIZEOF_INT == 4
  typedef int int32_t;
  typedef unsigned int uint32_t;
#elif SIZEOF_LONG_INT == 4
  typedef long int int32_t;
  typedef unsigned long int uint32_t;
#endif

#if SIZEOF_SHORT == 8
  typedef short int64_t;
  typedef unsigned short uint64_t;
  #define HAVE_64BIT_INT 1
#elif SIZEOF_INT == 8
  typedef int int64_t;
  typedef unsigned int uint64_t;
  #define HAVE_64BIT_INT 1
#elif SIZEOF_LONG_INT == 8
  typedef long int int64_t;
  typedef unsigned long int uint64_t;
  #define HAVE_64BIT_INT 1
#elif defined(HAVE___INT64)
  typedef __int64 int64_t;
  typedef unsigned __int64 uint64_t;
  #define HAVE_64BIT_INT 1
#elif defined(HAVE_LONGLONG) && SIZEOF_LONG_LONG == 8
  typedef long long int64_t;
  typedef unsigned long long uint64_t;
  #define HAVE_64BIT_INT 1
#endif

using ::size_t;
using ::ssize_t;
using ::off_t;

#ifdef HAVE_LARGEFILE64
  typedef uint64_t off64_t;
#endif

#ifdef _MSC_VER
  #define P_64BIT_CONSTANT(x)     x##i64
  #define P_U64BIT_CONSTANT(x)    x##ui64
#else
  #define P_64BIT_CONSTANT(x)     x##ll
  #define P_U64BIT_CONSTANT(x)    x##ull
#endif

}

#endif
