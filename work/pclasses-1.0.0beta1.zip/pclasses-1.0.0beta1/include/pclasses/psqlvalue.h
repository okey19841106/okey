/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2002  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _psqlvalue_h_
#define _psqlvalue_h_

#include <pclasses/pexport.h>
#include <pclasses/ptypes.h>
#include <pclasses/ptime.h>
#include <pclasses/psqlerror.h>
#include <string>

namespace P {

//! SQL Value base class
/*!
  \ingroup sql
*/
class PSQL_EXPORT SQLValue {
  public:
    virtual ~SQLValue();
    
    inline bool isNull() const throw()
    { return m_null; }
  
    virtual void setNull() throw() = 0;
    
    virtual std::string str() const throw() = 0;
    
  protected:
    SQLValue(bool null = true);
    bool m_null;
};

//! SQL String value
/*!
  \ingroup sql
*/
class PSQL_EXPORT SQLString: public SQLValue {
  public:
    //! NULL constructor
    SQLString();
    //! Value constructor
    SQLString(const std::string& str);
    ~SQLString();
    
    void setNull() throw();
    
    const std::string& value() const throw();
    std::string str() const throw();
    
    SQLString& operator=(const std::string& str);
        
  private:
    std::string m_str;
};

//! SQL Integer value
/*!
  \ingroup sql
*/
class PSQL_EXPORT SQLInt: public SQLValue {
  public:
    //! NULL constructor
    SQLInt();
    //! Value constructor
    SQLInt(int val);
    ~SQLInt();
    
    void setNull() throw();
    
    int value() const throw();
    std::string str() const throw();
    
    SQLInt& operator=(int val);
        
  private:
    int m_val;        
};


#ifdef HAVE_64BIT_INT

//! SQL Big integer value
/*!
  \ingroup sql
*/
class PSQL_EXPORT SQLBigInt: public SQLValue {
  public:
    //! NULL constructor
    SQLBigInt();
    //! Value constructor
    SQLBigInt(int64_t val);
    ~SQLBigInt();
    
    void setNull() throw();
    
    int64_t value() const throw();
    std::string str() const throw();
    
    SQLBigInt& operator=(int64_t val);
        
  private:
    int64_t m_val;
};

#endif

//! SQL Double value
/*!
  \ingroup sql
*/
class PSQL_EXPORT SQLDouble: public SQLValue {
  public:
    //! NULL constructor
    SQLDouble();
    //! Value constructor
    SQLDouble(const double& val);
    ~SQLDouble();
    
    void setNull() throw();
    
    const double& value() const throw();
    std::string str() const throw();
    
    SQLDouble& operator=(const double& val);
    
  private:
    double m_val;
};

//! SQL Date/time value
/*!
  \ingroup sql
*/
class PSQL_EXPORT SQLDateTime: public SQLValue {
  public:
    //! NULL constructor
    SQLDateTime();
    //! Value constructor
    SQLDateTime(const DateTime& dt);
    ~SQLDateTime();

    void setNull() throw();

    const DateTime& value() const throw();
    std::string str() const throw();
    
    SQLDateTime& operator=(const DateTime& val);
    
  private:
    DateTime m_val;        
};

}

#endif
