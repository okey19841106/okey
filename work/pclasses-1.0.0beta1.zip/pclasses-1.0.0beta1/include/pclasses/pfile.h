/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _pfile_h_
#define _pfile_h_

#include <pclasses/config.h>
#include <pclasses/pexport.h>
#include <pclasses/pfileinfo.h>
#include <pclasses/piodevice.h>
#include <pclasses/piostream.h>
#include <string>

namespace P {

//! File I/O class
/*!
  This class can be used to read, write and create objects located
  in the filesystem. Other operations include unlinking of a object,
  testing for existence, retrieving filesystem informations and
  creating a temporary file.
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PCORE_EXPORT File: public IODevice {
  public:

    //! File open mode
    /*!
      Tells File::open() where to position the file pointer
      after opening the file.
    */
    enum openMode_t {
      Normal,   /*!< Normal open - the file pointer is placed at the
                     beginning of the file */
      Append,   /*!< Open for appending - the file pointer is placed
                     past the end of the file */
      Truncate  /*!< Truncate the file and place the file
                     pointer at the beginning */
    };

    //! File creation mode
    /*!
      The file creation mode tells File::open() which action to
      tkae if the file exists, and which action to take when the
      file does not exist.
    */
    enum createMode_t {
      OpenCreate,   /*!< Open file create if not existent */
      OpenExisting, /*!< Open existing file, fail if not existent*/
      CreateFail    /*!< Create and open file, fail if already existent */
    };

    //! Default constructor
    File() throw();

    //! Copy constructor
    File(const File& f) throw(IOError);

    //! File open constructor
    /*!
      This constructor is used to construct and immediatly opening
      the file via open().
      \param path Path to the object in the filesystem
      \param access Requested access mode
      \param open Opening mode
      \param create Creation mode
      \param share Sharing mode
    */
    File(const char* path, accessMode_t access, openMode_t open = Normal,
         createMode_t create = OpenCreate, shareMode_t share = AllowNone) throw(IOError);

    //! Destructor
    ~File() throw();

    //! Open a file
    /*!
      This method is used to open objects in the filesystem. If another
      file is currently opened by the object it is closed before opening
      the new one.
      \param path Path to the object in the filesystem
      \param access Requested access mode
      \param open Opening mode
      \param create Creation mode
      \param share Sharing mode
      \throw IOError
    */
    void open(const char* path, accessMode_t access, openMode_t open = Normal,
              createMode_t create = OpenCreate, shareMode_t share = AllowNone) throw(IOError);

    //! Peek data from file
    /*!
      This method can be used to read data from a file without
      modifying the current file position pointer.
      \param buffer Buffer where data should be placed
      \param count Number of bytes to read
      \return The number of bytes actually read
      \throw IOError
    */
    size_t peek(char* buffer, size_t count) throw(IOError);

    #ifndef HAVE_LARGEFILE64

    //! Truncate/extent file to given size
    /*!
      Truncates or extents the file to the given size.
      If the file was smaller then the given size, the new allocated
      space is filled with zeros.
      The file pointer is updated to the new size of the file.
      \param size new size of the file
    */
    void truncate(off_t size) throw(IOError);

    //! Returns the size of the file
    off_t size() throw(IOError);

    #else

    //! Truncate/extent file to given size
    /*!
      Truncates or extents the file to the given size.
      If the file was smaller then the given size, the new allocated
      space is filled with zeros.
      The file pointer is updated to the new size of the file.
      \param size new size of the file
    */
    void truncate(off64_t size) throw(IOError);

    //! Returns the size of the file
    off64_t size() throw(IOError);

    #endif

    //! Reopen's the file
    void reopen() throw(IOError);

    //! Returns the path of the file
    inline const std::string& path() const throw()
    { return m_path; }

    File& operator=(const File& f) throw(IOError);

    //! Delete file
    static void unlink(const char* path) throw(IOError);

    //! Test if filesystem entry exists
    static bool exists(const char* path) throw();

    //! Get info about filesystem entry
    static FileInfo stat(const char* path) throw(IOError);

    //! Create temp file
    static File mktemp(const char* prefix) throw(IOError);

  private:
    std::string   m_path;
    accessMode_t  m_accessMode;
    openMode_t    m_openMode;
    createMode_t  m_createMode;
    shareMode_t   m_shareMode;
};


//! File I/O stream
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PCORE_EXPORT FileStream: public File, public IOStream {
  public:
    FileStream()
    : File(), IOStream(*this, 4096) {}

    FileStream(const char* path, accessMode_t access, openMode_t open = Normal,
               createMode_t create = OpenCreate, shareMode_t share = AllowNone) throw(IOError)
    : File(path, access, open, create), IOStream(*this, 4096) {}

    FileStream(const FileStream& fs) throw(IOError)
    : File(fs), IOStream(*this, 4096) {}

    FileStream(const File& f) throw(IOError)
    : File(f), IOStream(*this, 4096) {}

    ~FileStream() throw()
    {
      try
      {
        close();
      }
      catch(...)
      {
      }
    }

    void close() throw(IOError)
    {
      commit();
      File::close();
    }

    void commit() throw(IOError)
    {
      sync();
      File::commit();
    }

    FileStream& operator=(const FileStream& fs) throw(IOError)
    {
      sync(); flush();
      File::operator=(fs);
      return *this;
    }

};

}

#endif
