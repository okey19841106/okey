/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _psqlstatement_h_
#define _psqlstatement_h_

#include <pclasses/pexport.h>
#include <pclasses/psqldriver.h>
#include <pclasses/psqlconnection.h>
#include <pclasses/psqlvalue.h>
#include <memory>
#include <map>
#include <string>
#include <sstream>

namespace P {

class SQLStatement;

//! SQL Result class
/*!
  \ingroup sql
*/
class PSQL_EXPORT SQLResult {
  friend class SQLStatement;

  public:
    SQLResult(SQLStatement& stmt);
    virtual ~SQLResult();
    
    //! Returns the number of columns in this result
    unsigned int columnCount() const throw();

    //! Returns the name of the column
    std::string columnName(unsigned int pos) const;
        
    //! Fetch next row
    bool fetch();
    
    //! Retrieve value by column name
    const SQLValue& operator[](const std::string& fieldName);
    
    //! Retrieve value by column position
    const SQLValue& operator[](unsigned int fieldPos);
    
  protected:
    SQLResult(std::auto_ptr<SQLDriver::ResultHandle> handle);
    
  private:
    std::auto_ptr<SQLDriver::
      ResultHandle> m_handle;
};

//! SQL Statement class
/*!
  \ingroup sql
*/
class PSQL_EXPORT SQLStatement {
  friend class SQLResult;

  public:
    enum state_t {
      Initial,
      Prepared,
      Executed
    };

    SQLStatement(SQLConnection& conn, const std::string& stmt = "");
    virtual ~SQLStatement();

    //! Prepare the statement
    void prepare() throw(SQLError);

    //! Execute the statement
    void exec() throw(SQLError);

    //! Get the statement result
    std::auto_ptr<SQLResult> result() throw(SQLError);

    //! Returns the number of rows affected
    sqlcount_t affectedRows() const throw();

    void format(const std::string& fmt, const std::map<std::string,const SQLValue*>& vals);

    inline state_t state() const throw()
    { return m_state; }

    inline SQLConnection& conn() const throw()
    { return m_conn; }

    SQLStatement& operator<<(char ch);
    SQLStatement& operator<<(const char* str);
    SQLStatement& operator<<(const std::string& str);
    SQLStatement& operator<<(const SQLValue& val);

  protected:
    const std::auto_ptr<SQLDriver::
      StatementHandle>& handle() const throw()
    { return m_handle; }

  private:
    state_t             m_state;
    SQLConnection&      m_conn;
    std::auto_ptr<SQLDriver::
      StatementHandle>  m_handle;
    std::ostringstream  m_stmt;
};

}

#endif
