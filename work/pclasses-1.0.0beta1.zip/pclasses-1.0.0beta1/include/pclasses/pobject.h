/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2002  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _pobject_h_
#define _pobject_h_

#include <pclasses/config.h>
#include <pclasses/pexport.h>
#include <pclasses/psignal.h>

#ifdef CXX_NAMESPACES
namespace P {
#endif

//! Object base class
class PCORE_EXPORT Object {
  public:
    Object() {}
    virtual ~Object() {}
  
    //! Emit a signal with no arguments
    template <class RetType>
    RetType emit(Signal0<RetType>& s) {
      return s.emit();
    }

    //! Emit a signal with 1 argument
    template <class RetType, class P1>
    RetType emit(Signal1<RetType, P1>& s, P1 p1) {
      return s.emit(p1);
    }

    //! Emit a signal with 2 arguments
    template <class RetType, class P1, class P2>
    RetType emit(Signal2<RetType, P1, P2>& s, P1 p1, P2 p2) {
      return s.emit(p1, p2);
    }
    
};

#ifdef CXX_NAMESPACES
}
#endif

#endif
