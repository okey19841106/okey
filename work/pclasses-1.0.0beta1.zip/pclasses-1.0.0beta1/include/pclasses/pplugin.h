/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _pplugin_h_
#define _pplugin_h_

#include <pclasses/pexport.h>
#include <pclasses/psharedlib.h>
#include <typeinfo>
#include <list>
#include <map>
#include <string>

namespace P {

//! Base class for Plugin-Objects
/*!
  This class is used as a base class for objects that can be
  dynamically loaded and created by the PluginFactory.
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PCORE_EXPORT PluginBase {
  public:
    PluginBase();
    virtual ~PluginBase();
};

//! Plugin meta information
/*!
  The structure is used to hold information about a
  plugin that is exported from a shared library.
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
struct PluginMetaInfo {
  const char* iface;
  const char* feature;
  PluginBase* (*create)();
  void (*destroy)(PluginBase* c);
};

#define P_PLUGINS_BEGIN \
  extern "C" { \
    CXX_CLASS_EXPORT PluginMetaInfo P_plugin[] = {

#define P_PLUGIN(iface, feature, cl) \
  { typeid(iface).name(), feature, &cl::create, &cl::destroy },

#define P_PLUGINS_END \
  { 0, 0, 0, 0 } \
  }; }

//! Plugin factory implementation class
/*!
  The Plugin factory is used to load shared libraries which export
  plugin objects for a given interface (class).
  The factory will only load shared libraries which export features
  for the interface given in the constructor, others will be silently
  ignored.
  Using the feature as an identifier you can create instances of
  dynamically loaded objects.
  Please use the PluginFactory template class which avoids typecasts.
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PCORE_EXPORT PluginFactoryImpl {
  public:
    PluginFactoryImpl(const char* iface);
    virtual ~PluginFactoryImpl();

    //! Load a plugin library
    void addPlugin(const char* path) throw(SystemError);

    //! Try loading plugin libraries found in directory
    void addPluginDir(const char* path) throw(SystemError, IOError);

    //! Create instance of plugin object
    PluginBase* create(const char* feature);

    //! Destroy instance of plugin object
    void destroy(PluginBase* inst);

    //! Checks if the factory provides a plugin with given feature
    bool provides(const char* feature) const;

  private:
    struct Plugin;
    Plugin* find(const char* feature) const;

    std::string        m_iface;
    std::list<Plugin*> m_plugins;
    std::map<PluginBase*, Plugin*> m_pinst;
};


//! Plugin factory template class
/*
  \sa PluginFactoryImpl
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <class Iface>
class PluginFactory: public PluginFactoryImpl {
  public:
    //! Constructs the object
    /*!
      The constructor initializes the base object using
      the RTTI typeid of the template'd interface type.
    */
    inline PluginFactory()
    : PluginFactoryImpl(typeid(Iface).name())
    {}

    inline ~PluginFactory()
    {}

    //! Create instance of plugin object
    inline Iface* create(const char* feature)
    { return dynamic_cast<Iface*>(PluginFactoryImpl::create(feature)); }

    //! Destroy instance of plugin object
    inline void destroy(Iface* inst)
    { PluginFactoryImpl::destroy(dynamic_cast<PluginBase*>(inst)); }

};

}

#endif
