/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _psemaphore_h_
#define _psemaphore_h_

#include <pclasses/pexport.h>
#include <pclasses/pexception.h>

namespace P {

//! Semaphore synchronization class
/*!
  Semaphores are counters for resources shared between threads or processes.
  The basic operations on semaphores are: increment the counter atomically,
  and wait until the counter is non-null and decrement it atomically.
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PCORE_EXPORT Semaphore {
  public:
    //! Default constructor
    /*!
      Construct's a semaphore object. The semaphore may be process-
      shared if a name is supplied. On systems with SYSV semaphores the
      name must reffer to an existing file and the process must be
      able to stat() the file. On systems that do not have SYSV
      semaphores a semaphore cannot be process shared otherwise a
      SyncError will be thrown.
      \param name a pointer to the name of the semaphore which is used
             to identify the mutex, or a NULL pointer if the semaphore
             should be process-local.
      \param initial the initial count the semaphore should be initialized to
      \throw SyncError
    */
    Semaphore(const char* name = 0, unsigned int initial = 0) throw(SyncError);

    //! Destructor
    ~Semaphore() throw(SyncError);

    //! Wait for the semaphore to become signaled
    /*!
      Waits for the semaphore to become signaled (count is greater
      than zero) and atomically decreases the semaphore count.
      \throw SyncError
    */
    void wait() throw(SyncError);

    //! Non-blocking wait for semaphore
    /*!
      If the semahore is signaled (count greater than zero), atomically
      decreases the semaphore count and returns true. If the semaphore
      is currently not signaled (count is equal to zero) it immediatly
      returns false.
      \return true if semaphore has been acquired, false otherwise
      \throw SyncError
    */
    bool tryWait() throw(SyncError);

    //! Increases the semaphore count
    void post() throw(SyncError);

  private:
    struct sem_handle_t;
    sem_handle_t* m_handle;
};

}

#endif
