/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _psimpleapp_h_
#define _psimpleapp_h_

#include <pclasses/config.h>
#include <pclasses/pexport.h>
#include <pclasses/paboutdata.h>
#include <pclasses/psemaphore.h>

#ifndef WIN32

  #define P_IMPLEMENT_MAIN(cl) \
    int main(int argc, char* argv[]) \
    { \
      cl app; \
      return app.run(argc, argv); \
    }

#else

  #define P_IMPLEMENT_MAIN(cl) \
    int main(int argc, char* argv[]) \
    { \
      cl app; \
      return app.run(argc, argv); \
    }

#endif

namespace P {

//! A simple application base class
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PCORE_EXPORT SimpleApp {
  public:
    //! Simple application constructor
    /*!
      Simple application constructor.
      \param about A reference to the applications about data.
    */
    SimpleApp(const AboutData& about);
    virtual ~SimpleApp();
    
    //! Init & run the application
    /*!
      This method initializes the application by calling
      init(). When initialization was successfull the main
      method will be called. Before returning with the app's
      exit code, cleanup() will be called.
      \return the applications exit code, returned by the main() method
    */
    int run(int argc, char* argv[]);
    
    //! Stop the application
    /*!
      The stop functions increases a semaphore to 
      tell the main-loop that it should exit.
      \param code applications exit code
    */
    void stop(int code);
    
    //! Terminate application on signal
    virtual void terminate(int signal);
    
    //! Returns a reference to the about data
    const AboutData& about() const throw()
    { return m_about; }

    //! Returns a pointer to the application object
    PCORE_EXPORT friend SimpleApp* theApp() throw();

  protected:
    //! Application init
    /*!
      Overload this method to implement application initialization.
      Remember to call the default implementation to initialize the
      process signal handlers.
      \return returns zero if initialization was successfull,
          otherwise the exit code of the application.
    */
    virtual int init(int argc, char* argv[]);
    
    //! Application main loop
    /*!
      Overfload this method to implement the application main-loop.
      The default implementation does nothing except waiting for the
      exit semaphore to become increased and will then return with
      the value given to the stop() method.
      \return the applications exit code
    */
    virtual int main();
    
    //! Application cleanup function
    /*!
      Implement this method for cleaning up the application before
      exiting it.
    */
    virtual void cleanup() {}
        
    //! Process termination signal handler
    static RETSIGTYPE SIGTERM_handler(int);
           
    //! Returns a reference to the exit-semaphore
    Semaphore& exitSem()
    { return m_exitSem; }
    
    //! Returns the application's exit code
    inline int exitCode() const
    { return m_exitCode; }
    
  private:
    SimpleApp(const SimpleApp&);
    SimpleApp& operator=(const SimpleApp&);

    Semaphore         m_exitSem;
    int               m_exitCode;
    const AboutData&  m_about;
    static SimpleApp* m_theApp;
};

}

#endif
