/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _pnamedpipe_h_
#define _pnamedpipe_h_

#include <pclasses/pexport.h>
#include <pclasses/piodevice.h>
#include <string>

namespace P {

class NamedPipe;

//! Named pipe server
/*!
  Named pipe server class used to create a named pipe and
  accept client connections.
  On UNIX systems named pipes are implemented using a PF_UNIX
  type socket.
  \author Christian Prochnow <cproch@seculogix.de>
  \ingroup core
*/
class PCORE_EXPORT NamedPipeServer {
  public:
    friend class NamedPipe;

    //! Named pipe server constructor
    NamedPipeServer() throw();

    //! Named pipe server listen constructor
    NamedPipeServer(const char* name) throw(IOError);

    ~NamedPipeServer() throw();

    void listen(const char* name) throw(IOError);

    void close() throw(IOError);

    //! Wait for client
    /*!
      Waits for a client to connect to the named pipe.
      \param timeout timeout in milliseconds.
      \return true if a client has connected, false otherwise.
    */
    bool waitClient(unsigned int timeout) throw(IOError);

    inline const std::string& path() const throw()
    { return m_name; }

  protected:

    io_handle_t accept() throw(IOError);

  private:
    NamedPipeServer(const NamedPipeServer&);
    NamedPipeServer& operator=(const NamedPipeServer&);

    io_handle_t   m_handle;
    std::string   m_name;
};

//! Named pipe i/o device
/*!
  Named pipe client (inbound & outbound).
  On UNIX systems named pipes are implemented using a PF_UNIX
  type socket.
  \author Christian Prochnow <cproch@seculogix.de>
  \ingroup core
*/
class PCORE_EXPORT NamedPipe: public IODevice {
  public:
    //! Default constructor
    NamedPipe() throw();

    //! Connect constructor
    NamedPipe(const char* name) throw(IOError);

    //! Client accept constructor
    NamedPipe(NamedPipeServer& srv) throw(IOError);

    ~NamedPipe() throw();

    //! Connect to given named pipe
    void connect(const char* name) throw(IOError);

    //! Close the connection
    void close() throw(IOError);

    size_t peek(char* buffer, size_t count) throw(IOError);

    inline bool isSeekable() const throw()
    { return false; }

};

}

#endif
