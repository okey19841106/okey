/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _ptime_h_
#define _ptime_h_

#include <pclasses/pexport.h>
#include <pclasses/pexception.h>
#include <string>
#include <iostream>
#include <time.h>

namespace P {

//! Timespan class
/*!
  This class is used to add or subtract a timespan from a
  Date, Time or DateTime object.
  \ingroup core
*/
class PCORE_EXPORT TimeSpan {
  public:
    TimeSpan(unsigned int days = 0, unsigned int hours = 0, unsigned int minutes = 0,
             unsigned int seconds = 0, unsigned int usecs = 0) throw(OverflowError);
    ~TimeSpan() throw();

    void setDays(unsigned int days) throw(OverflowError);
    unsigned int days() const throw();

    void setHours(unsigned int hours) throw(OverflowError);
    unsigned int hours() const throw();

    void setMinutes(unsigned int minutes) throw(OverflowError);
    unsigned int minutes() const throw();

    void setSeconds(unsigned int seconds) throw(OverflowError);
    unsigned int seconds() const throw();

    void setUsecs(unsigned int usec) throw(OverflowError);
    unsigned int usecs() const throw();

    //! Normalize the timespan
    void normalize() throw(OverflowError);

    bool operator>(const TimeSpan& sp) const throw();
    bool operator<(const TimeSpan& sp) const throw();
    bool operator>=(const TimeSpan& sp) const throw();
    bool operator<=(const TimeSpan& sp) const throw();
    bool operator==(const TimeSpan& sp) const throw();
    bool operator!=(const TimeSpan& sp) const throw();

    TimeSpan& operator+=(const TimeSpan& sp) throw(OverflowError);
    TimeSpan& operator-=(const TimeSpan& sp) throw();

    PCORE_EXPORT friend TimeSpan operator+(const TimeSpan& sp1, const TimeSpan& sp2) throw(OverflowError);
    PCORE_EXPORT friend TimeSpan operator-(const TimeSpan& sp1, const TimeSpan& sp2) throw();

  private:
    unsigned int m_days;
    unsigned int m_hours;
    unsigned int m_minutes;
    unsigned int m_seconds;
    unsigned int m_usecs;
};


//! Invalid date error
/*!
  \ingroup core
*/
class PCORE_EXPORT InvalidDate: public RuntimeError {
  public:
    InvalidDate(const char* _what, const SourceInfo& si)
      : RuntimeError(_what, si) {}
};


//! Date class
/*!
  \ingroup core
*/
class PCORE_EXPORT Date {
  public:
    //! Enumeration of weekdays
    enum weekDay_t {
      Saturday = 0,
      Sunday,
      Monday,
      Tuesday,
      Wednesday,
      Thursday,
      Firday
    };

    //! Enumeration of months
    enum month_t {
      January = 1,
      February,
      March,
      April,
      May,
      June,
      July,
      August,
      September,
      October,
      November,
      December
    };

    Date(unsigned short year = 1970, unsigned char month = 1, unsigned char day = 1)
      throw(InvalidDate);

    ~Date() throw();

    double julianDayNumber() const throw();

    void setYear(unsigned short year);
    unsigned short year() const throw();

    void setMonth(unsigned char month) throw(InvalidDate);
    unsigned char month() const throw();

    //! Returns the number of days in stored month
    unsigned char daysInMonth() throw();

    void setDay(unsigned char day) throw(InvalidDate);
    unsigned char day() const throw();

    unsigned short dayOfYear() const throw();

    unsigned char dayOfWeek() const throw();

    //! Test if date is in a leap year
    bool isInLeapYear() const throw();

    Date& operator+=(const TimeSpan& sp);
    Date& operator-=(const TimeSpan& sp);

    bool operator>(const Date& d) const throw();
    bool operator<(const Date& d) const throw();
    bool operator>=(const Date& d) const throw();
    bool operator<=(const Date& d) const throw();
    bool operator==(const Date& d) const throw();
    bool operator!=(const Date& d) const throw();

    //! Returns the number of days in month
    static unsigned char daysInMonth(unsigned char month, unsigned short year) throw(InvalidDate);

    //! Test if the given year is a leap year
    static bool isLeapYear(unsigned short year) throw();

    PCORE_EXPORT friend std::ostream& operator << (std::ostream& os, const Date& d);

  private:
    unsigned short m_year;
    unsigned char  m_month;
    unsigned char  m_day;
};


//! Invalid time error
/*!
  \ingroup core
*/
class PCORE_EXPORT InvalidTime: public RuntimeError {
  public:
    InvalidTime(const char* _what, const SourceInfo& si)
      : RuntimeError(_what, si) {}
};


//! Time class
/*!
  \ingroup core
*/
class PCORE_EXPORT Time {
  public:
    Time(unsigned char hour = 0, unsigned char minute = 0,
         unsigned char second = 0, unsigned int usec = 0) throw(InvalidTime);
    ~Time() throw();

    void setHour(unsigned char hour);
    unsigned char hour() const throw();

    void setMinute(unsigned char minute);
    unsigned char minute() const throw();

    void setSecond(unsigned char second);
    unsigned char second() const throw();

    void setUsec(unsigned int usec);
    unsigned int usec() const throw();

    Time& operator+=(const TimeSpan& sp);
    Time& operator-=(const TimeSpan& sp);

    bool operator>(const Time& t) const throw();
    bool operator<(const Time& t) const throw();
    bool operator>=(const Time& t) const throw();
    bool operator<=(const Time& t) const throw();
    bool operator==(const Time& t) const throw();
    bool operator!=(const Time& t) const throw();

    PCORE_EXPORT friend std::ostream& operator << (std::ostream& os, const Time& t);

  private:
    unsigned char m_hour;
    unsigned char m_minute;
    unsigned char m_second;
    unsigned int  m_usec;
};


//! Date/time class
/*!
  \ingroup core
*/
class PCORE_EXPORT DateTime:
  public Date,
  public Time
{
  public:
    DateTime();
    DateTime(const Date& d);
    DateTime(const Time& t);
    DateTime(const Date& d, const Time& t);
    ~DateTime();

    //! Converts the date/time to current's local timezone
    /*!
      Returns the stored date/time value converted to local timezone.
      The function does the same as toTimeZone(currentTimeZone()).
    */
    DateTime toLocalTime() const;

    //! Converts the date/time to the given timezone
    DateTime toTimeZone(const std::string& tzname) const;

    //! Returns the name of the timezone
    inline const std::string& timeZone() const throw()
    { return m_tzname; }

    DateTime& operator+=(const TimeSpan& sp);
    DateTime& operator-=(const TimeSpan& sp);

    bool operator>(const DateTime& dt) const throw();
    bool operator<(const DateTime& dt) const throw();
    bool operator>=(const DateTime& dt) const throw();
    bool operator<=(const DateTime& dt) const throw();
    bool operator==(const DateTime& dt) const throw();
    bool operator!=(const DateTime& dt) const throw();

    //! Operation mode for current()
    enum currentMode_t {
      Local,    /*!< Retrieve current system time in local time */
      UTC       /*!< Retrieve current system time in UTC */
    };

    //! Retrieves the current system time
    static DateTime current(currentMode_t mode = Local);

    //! Returns the name of the current timezone
    static std::string currentTimeZone();

    PCORE_EXPORT friend std::ostream& operator << (std::ostream& os, const DateTime& dt);

  private:
    DateTime(const Date& d, const Time& t, const std::string& tzname);
    std::string m_tzname;
};

}

#endif
