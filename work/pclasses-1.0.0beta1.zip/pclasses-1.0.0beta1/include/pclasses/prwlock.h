/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _prwlock_h_
#define _prwlock_h_

#include <pclasses/pexport.h>
#include <pclasses/pexception.h>

namespace P {

//! Read-write lock synchronization object
/*!
  A read-write lock is like a mutex but allows multiple readers or 
  one writer to hold the lock at the same time. Also, read-write 
  locks are not recursive. On Win32 systems the read-write lock is
  implemented using a mutex which does not allow multiple readers.
  \sa Mutex
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PCORE_EXPORT RWLock {
  public:
    //! Default constructor
    /*!
    Construct the RWLock object. If a name is given, the read-write
    lock can be shared by multiple processes, otherwise a process-
    local	rwlock is created. On POSIX systems that support SYSV
    shared memory process-shared rwlock's are implemented	using a
    shared memory segment which contains the pthread_rwlock_t structure.
    \param name a pointer to the name of the rwlock which is used
           to identify it, or a NULL pointer if the mutex should be
           process-local. On POSIX systems the name must reffer to
           an existing file and the process must be able to stat() the
           file.
    \throw SyncError
    */
    RWLock(const char* name = 0) throw(SyncError);

     //! Destructor
    /*!
     The destructor destroys the read-write lock. The rwlock must be in
     unlocked state when the destructor is called. On POSIX systems this
     also removes the shared memory segment which contains the pthread_rwlock_t
     structure if no more processes reference to it.
    */
    ~RWLock() throw();

    //! Lock the read-write lock for reading
    /*!
     If the read-write lock is currently locked for writing by another
     thread the calling thread suspends until the write-lock has been
     released. If another thread already holds a read-lock, or the read-
     write lock is currently unlocked the function returns immediatly.
     \throw SyncError
    */
    void readLock() throw(SyncError);

    //! Try to lock the read-write lock for reading with timeout
    /*!
     This method does the same than readLock() but also supports a timeout-
     value. If the read-lock cannot be acquired in the given interval the
     method returns without locking the rwlock and a FALSE return value.
     \param timeout the timeout in milliseconds to wait for the read-lock.
            If zero is specified the method returns immediatly.
     \return TRUE if the read-lock has been acquired, FALSE otherwise.
     \throw SyncError
    */
    bool tryReadLock(unsigned int timeout) throw(SyncError);

    //! Lock the read-write lock for writing
    /*!
     If the read-write lock is currently locked for reading or writing
     by another thread, the calling thread suspends until the lock has
     been released. If the read-write lock is currently unlocked, the
     function returns immediatly.
     \throw SyncError
    */
    void writeLock() throw(SyncError);

    //! Try to lock the mutex for writing with timeout
    /*!
     This method does the same than writeLock() but also supports a timeout-
     value. If the lock cannot be acquired in the given interval the
     method returns without locking the rwlock and a FALSE return value.
     \param timeout the timeout in milliseconds to wait for the read-lock.
            If zero is specified the method returns immediatly.
     \return TRUE if the write-lock has been acquired, FALSE otherwise.
     \throw SyncError
    */
    bool tryWriteLock(unsigned int timeout) throw(SyncError);

    //! Release the previously acquired lock
    void unlock() throw(SyncError);

    //! Read Lock Guard class
    /*!
      The lock guard class is used to do exception-safe
      locking. Simply put a Lock object on the Stack.
      When the stack-frame is unwinded (by a throw, or
      a return) the RWLock will be unlocked.
      \ingroup core
      The following example shows how to use the Lock guard:
\code
class X {
  void set(int val);
  int get();
  private:
    RWLock rwl;
    int   var;
}

int X::get()
{
  RWLock::ReadLock l(rwl);
  return var;
}
\endcode
    */
    class ReadLock {
      public:
        inline ReadLock(RWLock& lock)
        : m_lock(lock) { lock.readLock(); }

        ~ReadLock()
        { m_lock.unlock(); }

        ReadLock& operator=(RWLock& mutex)
        {
          m_lock.unlock();
          m_lock = mutex;
          m_lock.readLock();
          return *this;
        }

      private:
        ReadLock(const ReadLock&);
        ReadLock& operator=(const ReadLock&);

        RWLock& m_lock;
    };

    //! Write Lock class
    /*!
      The lock guard class is used to do exception-safe
      locking. Simply put a Lock object on the Stack.
      When the stack-frame is unwinded (by a throw, or
      a return) the RWLock will be unlocked.
      \ingroup core
      The following example shows how to use the Lock guard:
\code
class X {
  void set(int val);
  int get();
  private:
    RWLock rwl;
    int   var;
}

void X::set(int val)
{
  RWLock::WriteLock l(rwl);
  var = val;
}
\endcode
    */
    class WriteLock {
      public:
        inline WriteLock(RWLock& lock)
        : m_lock(lock) { lock.writeLock(); }

        ~WriteLock()
        { m_lock.unlock(); }

        WriteLock& operator=(RWLock& mutex)
        {
          m_lock.unlock();
          m_lock = mutex;
          m_lock.writeLock();
          return *this;
        }

      private:
        WriteLock(const WriteLock&);
        WriteLock& operator=(const WriteLock&);

        RWLock& m_lock;
    };
    
  private:
    RWLock(const RWLock&);
    RWLock& operator=(const RWLock&);
  
    struct rwlock_handle_t;
    rwlock_handle_t* m_handle;
};

}

#endif
