/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2002  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _psqlerror_h_
#define _psqlerror_h_

#include <pclasses/pexport.h>
#include <pclasses/pexception.h>
#include <string>

namespace P {

//! SQL Error exception class
/*!
  \ingroup sql
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PSQL_EXPORT SQLError: public RuntimeError {
  public:
    typedef long sqlerr_t;
  
    inline SQLError(sqlerr_t errnum, const char* _what, const SourceInfo& _si) throw()
      : RuntimeError(_what,_si), m_errnum(errnum) {}

    virtual BaseError* clone() const = 0;
    
    inline sqlerr_t errnum() const throw() 
    { return m_errnum; }
    
    virtual std::string text() const throw() = 0;

  private:
    sqlerr_t  m_errnum;

};

}

#endif
