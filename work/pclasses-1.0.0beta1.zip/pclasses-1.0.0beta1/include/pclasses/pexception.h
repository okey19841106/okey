/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _pexception_h_
#define _pexception_h_

#include <pclasses/pexport.h>
#include <pclasses/psourceinfo.h>
#include <string>

namespace P {

//! Exception base class
/*!
  The base class for all exceptions thrown by the P::Classes
  Application Framework. A exception object contains a cause-
  message and a SourceInfo object that describes where the
  exception occured.
  \author Christian Prochnow <cproch@seculogix.de>
  \ingroup core
*/
class PCORE_EXPORT BaseError {
  public:
    //! Exception constructor
    /*!
      Constructs the exception object.
      \param _what a pointer to string containing the error message
      \param _si a reference to a SourceInfo object
    */
    inline BaseError(const char* _what, const SourceInfo& _si) throw()
      : m_what(_what), m_sourceInfo(_si) {}

    //! Destructor
    inline virtual ~BaseError() throw() {}

    //! Returns the error message
    /*!
      Returns a pointer to the message which caused the exception.
      \return the cause of the exception
    */
    inline const char* what() const throw()
    { return m_what; }

    //! Clones the object
    /*!
      This method returns an exact copy of the exception object.
      \return the copied exception object
    */
    inline virtual BaseError* clone() const
    { return new BaseError(*this); }

    //! Returns the source information
    /*!
      The method returns a reference to a SourceInfo object,
      which stores the location where the exception occured.
      \return const reference to the SourceInfo
    */
    inline const SourceInfo& sourceInfo() const throw()
    { return m_sourceInfo; }

    //! Assign operator
    BaseError& operator=(const BaseError& e);

  private:
    const char* m_what;
    SourceInfo	m_sourceInfo;
};

//! Logic error
/*!
  Logic errors are thrown whenever a class was used "logically
  incorrect". Eg. if you try to start a Thread which has already
  been started.
  \author Christian Prochnow <cproch@seculogix.de>
  \ingroup core
*/
class PCORE_EXPORT LogicError: public BaseError {
  public:
    inline LogicError(const char* _what, const SourceInfo& _si) throw()
      : BaseError(_what,_si) {}

    inline BaseError* clone() const
    { return new LogicError(*this); }
};

//! Runtime error
/*!
  \author Christian Prochnow <cproch@seculogix.de>
  \ingroup core
*/
class PCORE_EXPORT RuntimeError: public BaseError {
  public:
    inline RuntimeError(const char* _what, const SourceInfo& _si) throw()
      : BaseError(_what,_si) {}

    inline BaseError* clone() const
    { return new RuntimeError(*this); }
};

//! Invalid argument exception class
/*class InvalidArgument: public LogicError {
  public:
    inline InvalidArgument(const SourceInfo& _si) throw()
      : LogicError("Invalid argument",_si) {}
};

//! Unexpected NULL-pointer exception class
class NullPointerError: public LogicError {
  public:
    inline NullPointerError(const SourceInfo& _si) throw()
      : LogicError("Unexpected NULL-pointer",_si) {}
};
*/

//! Out of range error
/*!
  \author Christian Prochnow <cproch@seculogix.de>
  \ingroup core
*/
class PCORE_EXPORT OutOfRangeError: public LogicError {
  public:
    inline OutOfRangeError(const SourceInfo& _si) throw()
      : LogicError("Out of range",_si) {}

    inline BaseError* clone() const
    { return new OutOfRangeError(*this); }
};

//! Overflow error
/*!
  \author Christian Prochnow <cproch@seculogix.de>
  \ingroup core
*/
class PCORE_EXPORT OverflowError: public RuntimeError {
  public:
    inline OverflowError(const SourceInfo& _si) throw()
      : RuntimeError("Overflow",_si) {}

    inline BaseError* clone() const
    { return new OverflowError(*this); }
};

//! Operating System error
/*!
  This exception class is thrown whenever a operating
  system error has occured.
  \author Christian Prochnow <cproch@seculogix.de>
  \ingroup core
*/
class PCORE_EXPORT SystemError: public RuntimeError {
  public:
    typedef long oserr_t;

    inline SystemError(oserr_t errnum, const char* _what, const SourceInfo& _si) throw()
      : RuntimeError(_what,_si), m_errnum(errnum) {}

    inline BaseError* clone() const
    { return new SystemError(*this); }

    //! Native error code
    /*!
      Returns the native operating system error code.
      \return error code
    */
    inline oserr_t errnum() const throw()
    { return m_errnum; }

    //! System error message
    /*!
      Retrieves the operating system error message that
      correspends to the error code.
      \return system error message
    */
    std::string text() const throw();

  private:
    oserr_t m_errnum;
};

//! Synchronization error
/*!
  \author Christian Prochnow <cproch@seculogix.de>
  \ingroup core
*/
class PCORE_EXPORT SyncError: public SystemError {
  public:
    inline SyncError(oserr_t errnum, const char* _what, const SourceInfo& _si) throw()
      : SystemError(errnum, _what, _si) {}

    inline BaseError* clone() const
    { return new SyncError(*this); }

};

//! Input/output error
/*!
  \author Christian Prochnow <cproch@seculogix.de>
  \ingroup core
*/
class PCORE_EXPORT IOError: public SystemError {
  public:
    inline IOError(oserr_t errnum, const char* _what, const SourceInfo& _si) throw()
      : SystemError(errnum, _what, _si) {}

    inline BaseError* clone() const
    { return new IOError(*this); }

};

}

#endif
