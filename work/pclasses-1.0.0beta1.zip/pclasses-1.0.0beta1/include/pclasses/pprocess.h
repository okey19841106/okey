/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003 Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _pprocess_h_
#define _pprocess_h_

#include <pclasses/pexport.h>
#include <pclasses/pexception.h>
#include <pclasses/piodevice.h>
#include <string>
#include <list>

namespace P {

//! Child process I/O device
/*!
  \todo ProcessIO Win32 implementation
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PCORE_EXPORT ProcessIO: public IODevice {
  friend class Process;
  public:

    //! Close pipe's to child process
    void close() throw(IOError);

    //! Write to process stdin
    size_t write(const char* buffer, size_t count) throw(IOError);

    //! Read from process stdout
    size_t read(char* buffer, size_t count) throw(IOError);

    //! Read from process stderr
    size_t readErr(char* buffer, size_t count) throw(IOError);

  protected:
    ProcessIO(io_handle_t in, io_handle_t out, io_handle_t err) throw();
    ~ProcessIO() throw();

  private:
    io_handle_t m_in;
    io_handle_t m_out;
    io_handle_t m_err;

};


//! Process Environment
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PCORE_EXPORT ProcessEnv {
  public:

    //! Set environment variable
    static void set(const char* name, const char* value);

    //! Unset environment variable
    static void unset(const char* name);

    //! Get environment variable
    static const char* get(const char* name);

  private:
    ProcessEnv();
    ~ProcessEnv();
};


//! Child process class
/*!
  This class is used to concurrently execute child processes.
  \ingroup core
  \todo Process Win32 implementation
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PCORE_EXPORT Process {
  public:
    //! Child process state
    enum state_t {
      Stopped,
      Running,
      Stopping
    };

    //! Communication mode flags
    enum commMode_t {
      NoCommunication = 0,  /*!< No input/output */
      StdIn     = 1,        /*!< Standard input */
      StdOut    = 2,        /*!< Standard output */
      StdErr    = 4,        /*!< Standard error output */
      AllOutput = 6,        /*!< All output */
      All       = 7         /*!< All input/output */
    };

    //! Argument list type
    typedef std::list<std::string> arg_list;

    //! Process constructor
    Process(const char* path, const arg_list& args = arg_list())
      throw(IOError);

    ~Process() throw();

    //! Returns the process state
    inline state_t state() const
    { return m_state; }

    //! Add argument
    void addArg(const char* arg);

    //! Clear arguments
    void clearArgs();

    //! Set working directory
    void setWorkDir(const char* dir);

    inline const std::string& workDir() const
    { return m_dir; }

    //! Run program
    void start(commMode_t mode = NoCommunication)
      throw(SystemError,IOError,LogicError);

    //! Terminate process
    void stop() throw(SystemError);

    //! Kill process
    void kill() throw(SystemError);

    //! Try wait for program to finish
    bool tryWait(int& exitCode) throw(SystemError);

    //! Wait for program to finish
    int wait() throw(SystemError);

    //! Try waiting for any child process to exit
    static Process* tryWaitAny(int& exitCode) throw(SystemError);

    //! Wait for any child process to exit
    static Process* waitAny(int& exitCode) throw(SystemError);

    //! Return pointer to process i/o object
    /*!
      This method returns a pointer to the ProcessIO object that
      can be used to communicate with the child process's stdin,
      stdout and stderr. The pointer returned maybe NULL if no
      process is active.
      \return a pointer to the ProcessIO object, which maybe NULL
    */
    inline ProcessIO* processIO() const throw()
    { return m_procIO; }

  private:
    struct process_handle_t;
    process_handle_t* m_handle;

    ProcessIO*    m_procIO;
    state_t       m_state;
    std::string   m_dir;
    std::string   m_program;
    arg_list      m_args;
};

}

#endif
