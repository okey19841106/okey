/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _pbyteorder_h_
#define _pbyteorder_h_

#include <pclasses/config.h>
#include <pclasses/pexport.h>

namespace P {

inline uint16_t swab(uint16_t __x)
{
  return ((uint16_t)(
         (((uint16_t)(__x) & (uint16_t)0x00ff) << 8) |
         (((uint16_t)(__x) & (uint16_t)0xff00) >> 8) ));
}

inline uint32_t swab(uint32_t __x)
{
  return ((uint32_t)(
          (((uint32_t)(__x) & (uint32_t)0x000000ff) << 24) |
          (((uint32_t)(__x) & (uint32_t)0x0000ff00) <<  8) |
          (((uint32_t)(__x) & (uint32_t)0x00ff0000) >>  8) |
          (((uint32_t)(__x) & (uint32_t)0xff000000) >> 24) ));
}

inline uint64_t swab(uint64_t __x)
{
  return ((uint64_t)(
          (uint64_t)(((uint64_t)(__x) & (uint64_t)P_U64BIT_CONSTANT(0x00000000000000ff)) << 56) |
          (uint64_t)(((uint64_t)(__x) & (uint64_t)P_U64BIT_CONSTANT(0x000000000000ff00)) << 40) |
          (uint64_t)(((uint64_t)(__x) & (uint64_t)P_U64BIT_CONSTANT(0x0000000000ff0000)) << 24) |
          (uint64_t)(((uint64_t)(__x) & (uint64_t)P_U64BIT_CONSTANT(0x00000000ff000000)) <<  8) |
          (uint64_t)(((uint64_t)(__x) & (uint64_t)P_U64BIT_CONSTANT(0x000000ff00000000)) >>  8) |
          (uint64_t)(((uint64_t)(__x) & (uint64_t)P_U64BIT_CONSTANT(0x0000ff0000000000)) >> 24) |
          (uint64_t)(((uint64_t)(__x) & (uint64_t)P_U64BIT_CONSTANT(0x00ff000000000000)) >> 40) |
          (uint64_t)(((uint64_t)(__x) & (uint64_t)P_U64BIT_CONSTANT(0xff00000000000000)) >> 56) ));
}

inline uint16_t cpu_to_le(uint16_t word)
{
  #ifdef WORDS_BIGENDIAN
  return swab(word);
  #else
  return word;
  #endif
}

inline uint16_t le_to_cpu(uint16_t word)
{
  #ifdef WORDS_BIGENDIAN
  return swab(word);
  #else
  return word;
  #endif
}

inline uint32_t cpu_to_le(uint32_t dword)
{
  #ifdef WORDS_BIGENDIAN
  return swab(dword);
  #else
  return dword;
  #endif
}

inline uint32_t le_to_cpu(uint32_t dword)
{
  #ifdef WORDS_BIGENDIAN
  return swab(dword);
  #else
  return dword;
  #endif
}

inline uint64_t cpu_to_le(uint64_t qword)
{
  #ifdef WORDS_BIGENDIAN
  return swab(qword);
  #else
  return qword;
  #endif
}

inline uint64_t le_to_cpu(uint64_t qword)
{
  #ifdef WORDS_BIGENDIAN
  return swab(qword);
  #else
  return qword;
  #endif
}

inline uint16_t cpu_to_be(uint16_t word)
{
  #ifdef WORDS_BIGENDIAN
  return word;
  #else
  return swab(word);
  #endif
}

inline uint16_t be_to_cpu(uint16_t word)
{
  #ifdef WORDS_BIGENDIAN
  return word;
  #else
  return swab(word);
  #endif
}

inline uint32_t cpu_to_be(uint32_t dword)
{
  #ifdef WORDS_BIGENDIAN
  return dword;
  #else
  return swab(dword);
  #endif
}

inline uint32_t be_to_cpu(uint32_t dword)
{
  #ifdef WORDS_BIGENDIAN
  return dword;
  #else
  return swab(dword);
  #endif
}

inline uint64_t cpu_to_be(uint64_t qword)
{
  #ifdef WORDS_BIGENDIAN
  return qword;
  #else
  return swab(qword);
  #endif
}

inline uint64_t be_to_cpu(uint64_t qword)
{
  #ifdef WORDS_BIGENDIAN
  return qword;
  #else
  return swab(qword);
  #endif
}

}

#endif
