/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#ifndef _plocktraits_h_
#define _plocktraits_h_

#include <pclasses/pcriticalsection.h>
#include <pclasses/pmutex.h>
#include <pclasses/prwlock.h>

namespace P {

//! Dummy mutex
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
class VoidMutex {
  public:
    VoidMutex() { }
    ~VoidMutex() { }

    //! Dummy mutex lock
    /*!
      \ingroup mt
      \author Christian Prochnow <cproch@seculogix.de>
    */
    class Lock {
      public:
        Lock(VoidMutex&) { }
        ~Lock() { }
    };
};

//! LockTraits template
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <class _T>
struct LockTraits {
  typedef VoidMutex MutexType;
  typedef VoidMutex::Lock ReadLock;
  typedef VoidMutex::Lock WriteLock;
};

//! LockTraits for CriticalSection
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <>
struct LockTraits<CriticalSection> {
  typedef CriticalSection MutexType;
  typedef CriticalSection::Lock ReadLock;
  typedef CriticalSection::Lock WriteLock;
};

//! LockTraits for Mutex
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <>
struct LockTraits<Mutex> {
  typedef Mutex MutexType;
  typedef Mutex::Lock ReadLock;
  typedef Mutex::Lock WriteLock;
};

//! LockTraits for RWLock
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <>
struct LockTraits<RWLock> {
  typedef RWLock MutexType;
  typedef RWLock::ReadLock ReadLock;
  typedef RWLock::WriteLock WriteLock;
};

}

#endif
