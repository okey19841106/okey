/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _patalkaddr_h_
#define _patalkaddr_h_

#include <pclasses/pexport.h>
#include <pclasses/psocket.h>
#include <iostream>
#include <string>

struct at_addr;

namespace P {

//! AppleTalk address
/*!
  \ingroup net
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PNET_EXPORT ATalkAddress: public NetworkAddress {
  public:
    //! Default constructor
    ATalkAddress();

    //! Copy constructor
    ATalkAddress(const NetworkAddress& addr) throw(LogicError);

    //! Native address constructor
    ATalkAddress(const at_addr& addr);

    //! Address string constructor
    ATalkAddress(const std::string& ataddr);

    //! Returns the AppleTalk address
    const at_addr& ataddr() const;

    //! Returns the address as a string
    std::string str() const;

    NetworkAddress* clone() const;

    //! Address assign operator
    ATalkAddress& operator=(const NetworkAddress& addr) throw(LogicError);

    //! Address assign operator
    ATalkAddress& operator=(const at_addr& addr);

    //! Address string assign operator
    ATalkAddress& operator=(const std::string& ataddr);

    PNET_EXPORT friend std::ostream& operator<<(std::ostream& os, const ATalkAddress& addr);
    PNET_EXPORT friend std::istream& operator>>(std::istream& is, ATalkAddress& addr);
};

}

#endif
