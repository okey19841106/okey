/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _paboutdata_h_
#define _paboutdata_h_

#include <pclasses/pexport.h>
#include <utility>
#include <string>
#include <list>

/*!
  \defgroup core Core library
*/

namespace P {

//! Application about data
/*!
  This class is used to store data about the application itself.
  \author Christian Prochnow <cproch@seculogix.de>
  \ingroup core
*/
class PCORE_EXPORT AboutData {
  public:

    //! Distribution license type
    enum license_t {
      GPL,      /*!< GNU Public License */
      LGPL,     /*!< Lesser GNU Public License */
      QPL,      /*!< Qt Publis License */
      Custom    /*!< Custom License */
    };

    //! Type used to store authors name & email address
    typedef std::pair<std::string, std::string> author_t;

    //! Type used to store name & email address for credits
    typedef std::pair<std::string, std::string> credit_t;

    //! Construct about data
    /*!
      Constructs the about data object with the given values.
      \param appName Applications short name
      \param appDesc Short application description
      \param version Application version
      \param copyright Copyright string
      \param lic Distribution license
    */
    AboutData(const std::string& appName, const std::string& appDesc,
              const std::string& version, const std::string& copyright, license_t lic);
    ~AboutData();

    //! Returns the application name
    inline const std::string& name() const
    { return m_appName; }

    //! Returns the applications short description
    inline const std::string& description() const
    { return m_appDesc; }

    //! Returns the application version
    inline const std::string& version() const
    { return m_version; }

    //! Returns the application copyright
    inline const std::string& copyright() const
    { return m_copyright; }

    //! Returns the distribution license
    inline license_t license() const
    { return m_license; }

    //! Add an author to the list of authors
    void addAuthor(const std::string& name, const std::string& email);

    //! Returns the list of authors
    inline const std::list<author_t>& authors() const
    { return m_authors; }

    //! Add a credit to the list of authors
    void addCredit(const std::string& name, const std::string& email);

    //! Returns the list of credits
    inline const std::list<credit_t>& credits() const
    { return m_credits; }

  private:
    std::string         m_appName;
    std::string         m_appDesc;
    std::string         m_version;
    std::string         m_copyright;
    license_t           m_license;
    std::list<author_t> m_authors;
    std::list<credit_t> m_credits;
};

}

#endif
