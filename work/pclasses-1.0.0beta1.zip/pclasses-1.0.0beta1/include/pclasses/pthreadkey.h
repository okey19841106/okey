/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _pthreadkey_h_
#define _pthreadkey_h_

#include <pclasses/pexport.h>

namespace P {

//! Thread-specific storage class
/*!
  This class should not be used directly, instead you
  should use the ThreadKey template class.
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PCORE_EXPORT ThreadKeyImpl {
  public:
    ThreadKeyImpl();
    virtual ~ThreadKeyImpl();

    void set(void* ptr) throw();
    void* get() throw();

  private:
    ThreadKeyImpl(const ThreadKeyImpl&);
    ThreadKeyImpl& operator=(const ThreadKeyImpl&);

    struct key_handle_t;
    key_handle_t* m_handle;
};

//! Thread-specific storage template class
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <class T>
class ThreadKey: private ThreadKeyImpl {
  public:
    inline ThreadKey()
    : ThreadKeyImpl() {}

    inline ThreadKey(const ThreadKey& k)
    : ThreadKeyImpl()
    { set(k.get()); }

    inline ~ThreadKey() {}

    inline ThreadKey& operator=(const ThreadKey& k)
    {
      set(k.get());
      return *this;
    }

    ThreadKey& operator=(const T* val)
    {
      set((void*)val);
      return *this;
    }

    operator T* ()
    { return (T*)get(); }

};

}

#endif
