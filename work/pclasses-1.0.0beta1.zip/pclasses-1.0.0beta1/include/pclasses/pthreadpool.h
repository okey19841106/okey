/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2002  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _pthreadpool_h_
#define _pthreadpool_h_

#include <pclasses/pexport.h>
#include <pclasses/pthread_.h>
#include <pclasses/psemaphore.h>
#include <pclasses/pcriticalsection.h>
#include <pclasses/psignal.h>
#include <queue>
#include <list>

namespace P {

class ThreadPool;
class WorkerThread;

class CXX_CLASS_EXPORT ThreadJob {
  friend class WorkerThread;

  public:
    ThreadJob();
    virtual ~ThreadJob();

    void wait();
    void tryWait();

    Signal0<int> sigMain;

  protected:
    virtual void main();
    void finished();

  private:
    Semaphore   m_lock;

};

class CXX_CLASS_EXPORT ThreadPool {
  friend class WorkerThread;

  public:
    ThreadPool(unsigned int numThreadsInit, unsigned int numThreadsMaxIdle,
               unsigned int numThreadsMax);
    ~ThreadPool();

    void enqueue(ThreadJob* job);

  protected:
    void finished(WorkerThread* worker);

  private:
    CriticalSection   m_lock;
    Semaphore         m_threadStartSem;
    unsigned int      m_numThreads;
    unsigned int      m_numThreadsMaxIdle;
    unsigned int      m_numThreadsMax;
    unsigned int      m_numThreadsIdle;
    std::queue<
      ThreadJob*>     m_jobs;
    std::queue<
      WorkerThread*>  m_idle;

};

}

#endif
