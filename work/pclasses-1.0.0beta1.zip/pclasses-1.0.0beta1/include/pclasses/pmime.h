/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _pmime_h_
#define _pmime_h_

#include <pclasses/pexport.h>
#include <pclasses/psingleton.h>
#include <vector>
#include <string>
#include <map>

namespace P {

//! MIME type
/*!
  \author Christian Prochnow <cproch@seculogix.de>
  \ingroup netio
*/
class PIO_EXPORT MimeType {
  public:
    //! Vector for file extensions
    typedef std::vector<std::string> FileExtVector;
  
    //! Constructor
    /*!
      \param mediaType MIME media type
      \param subType MIME sub type
      \param fileExts vector of associated file extensions
    */
    MimeType(const std::string& mediaType, const std::string& subType,
             const FileExtVector& fileExts);
             
    ~MimeType();
    
    //! Return the full MIME type
    inline const std::string mimeType() const
    { return m_mediaType + "/" + m_subType; }
    
    //! Returns the MIME media type
    inline const std::string& mediaType() const
    { return m_mediaType; }
    
    //! Returns the MIME sub type
    inline const std::string& subType() const
    { return m_subType; }
    
    //! Returns a reference to the file extensions vector
    inline const FileExtVector& fileExts() const
    { return m_fileExts; }
    
  private:
    std::string    m_mediaType;
    std::string    m_subType;
    FileExtVector  m_fileExts;
};


//! MIME type database
/*!
  The class is used as an application wide MIME type registry.
  \author Christian Prochnow <cproch@seculogix.de>
  \ingroup netio
*/
class PIO_EXPORT MimeTypeDb: 
  public Singleton<MimeTypeDb, CriticalSection> 
{
  public:
    typedef std::multimap<
      std::string,MimeType
    >::const_iterator const_iterator;
  
    //! Add MIME type to database
    bool add(const MimeType& type);
    
    //! Find MIME type by full name
    MimeType* findByMimeType(const std::string& mimeType) const;

    //! Find MIME type by file extension
    MimeType* findByFileExt(const std::string& fileExt) const;

    inline const_iterator begin() const
    { return m_types.begin(); }

    inline const_iterator end() const
    { return m_types.end(); }

  protected:
    friend class Singleton<MimeTypeDb, CriticalSection>;

    MimeTypeDb();
    ~MimeTypeDb();

  private:
    void insert(const MimeType& type);
    void readMimeTypes();

    std::multimap<
      std::string,
      MimeType>      m_types;
};

}

#endif
