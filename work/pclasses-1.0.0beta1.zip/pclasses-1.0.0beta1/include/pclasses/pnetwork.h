/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _pnetwork_h_
#define _pnetwork_h_

#include <pclasses/pexport.h>
#include <pclasses/pinetaddr.h>

#include <string>
#include <list>

namespace P {

//! Network device info
/*!
  This class hold various informations about a network-
  devices. Use the enumDevices() method to retrieve it
  from the system.
  \ingroup net
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PNET_EXPORT NetDeviceInfo {
  public:
    NetDeviceInfo(const NetDeviceInfo& ndi);
    ~NetDeviceInfo();

    //! Returns the IPv4 address of the device
    inline const InetAddress& addr() const
    { return m_addr; }

    //! Returns the IPv4 network mask
    inline const InetAddress& netmask() const
    { return m_netmask; }

    //! Returns the IPv4 broadcast address
    inline const InetAddress& broadcast() const
    { return m_broadcast; }
    
    //! Returns the MTU of the device
    /*!
      Returns the Maximum transfer unit (MTU) of the device.
      A packet sent over this device cannot exceed the MTU
      (including packet header and payload).
    */
    inline int mtu() const
    { return m_mtu; }
    
    NetDeviceInfo& operator=(const NetDeviceInfo& ndi);

    //! Enumerate all network devices
    static void enumDevices(std::list<NetDeviceInfo>& devlist);
    
  private:
    NetDeviceInfo(const std::string& devName, const InetAddress& addr, const InetAddress& netmask,
                  const InetAddress& brdcast, int mtu);

    std::string m_devName;
    InetAddress m_addr;
    InetAddress m_netmask;
    InetAddress m_broadcast;
    int         m_mtu;
};

}

#endif
