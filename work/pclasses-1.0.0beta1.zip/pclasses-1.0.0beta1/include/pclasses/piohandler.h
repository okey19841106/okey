/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _piohandler_h_
#define _piohandler_h_

#include <pclasses/pexport.h>
#include <pclasses/purl.h>
#include <string>

namespace P {

class IORequest;
class IORequest_Get;
class IORequest_Put;
class IORequest_Unlink;
class IORequest_MakeDir;
class IORequest_RemoveDir;
class IORequest_ListDir;

//! Network I/O Plugin base
/*!
  \ingroup netio
*/
class PIO_EXPORT IOHandler {
  public:
    IOHandler();
    virtual ~IOHandler();

    virtual IORequest_Get* get(const URL& url);

    virtual IORequest_Put* put(const URL& url);

    virtual IORequest_Unlink* unlink(const URL& url);

    virtual IORequest_MakeDir* mkdir(const URL& url);

    virtual IORequest_RemoveDir* rmdir(const URL& url);

    virtual IORequest_ListDir* list(const URL& url);

    virtual void finish(IORequest* job) = 0;
};

}

#endif
