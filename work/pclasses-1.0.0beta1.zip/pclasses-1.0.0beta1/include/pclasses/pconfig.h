/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _pconfig_h_
#define _pconfig_h_

#include <pclasses/pexport.h>
#include <string>
#include <map>

namespace P {

class ConfigStore;

//! Configuration database class
class PCORE_EXPORT Config {
  public:

    //! Config database constructor
    /*!
      \param store The configuration storage to use
    */
    Config(ConfigStore& store);
    ~Config();

    //! Reload configuration (discarding any changes)
    void reload();

    //! Save configuration (if modified)
    void save();

    //! Configuration key class
    class PCORE_EXPORT Key {
      friend class Config;

      public:
        typedef std::multimap<std::string, std::string> value_map;
        typedef value_map::const_iterator value_iterator;

        typedef std::multimap<std::string, Key*> key_map;
        typedef key_map::const_iterator key_iterator;

        //! Retrieve config value
        const std::string& value(const std::string& name, const std::string& def);

        //! Set config value
        void setValue(const std::string& name, const std::string& value);

        // Remove config value
        void removeValue(const std::string& name);

        //! Retrieve pointer to config key
        Key* key(const std::string& name);

        //! Add config key
        Key* addKey(const std::string& name);

        //! Remove config key
        void removeKey(const std::string& name);

        inline const value_map& values() const
        { return m_values; }

        inline const key_map& keys() const
        { return m_keys; }

      protected:
        Key(Config* cfg, const std::string& name);
        ~Key();

      private:
        Key(const Key&);
        Key& operator=(const Key&);

        Config*     m_cfg;
        std::string m_name;
        value_map   m_values;
        key_map     m_keys;
    };

    friend class Key;

    //! Return reference to the config root
    inline Key& root()
    { return m_root; }

    //! Return reference to the config store
    inline ConfigStore& store()
    { return m_store; }

    //! Test if config was modifies
    inline bool isModified() const
    { return m_modified; }

  private:
    Config(const Config&);
    Config& operator=(const Config&);

    bool          m_modified;
    ConfigStore&  m_store;
    Key           m_root;
};

}

#endif
