/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2002  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _purl_h_
#define _purl_h_

#include <pclasses/pexport.h>
#include <pclasses/pexception.h>
#include <pclasses/pnetdb.h>
#include <iostream>
#include <string>

namespace P {

//! Invalid url error
/*!
  \ingroup net
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PNET_EXPORT InvalidURL: public RuntimeError {
  public:
    inline InvalidURL(const char* _what, const SourceInfo& _si) throw()
      : RuntimeError(_what,_si) {}
};

//! Uniform resource locator
/*!
  This class is used to parse and store uniform resource
  locators. When storing a URL with password the password
  will not be printed out by the operator<< but can
  be retrieved via password().
  \ingroup net
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PNET_EXPORT URL {
  public:
    //! Default constructor
    /*!
      Initializes the URL to 'file:///'
    */
    URL();
    
    //! Parse URL constructor
    URL(const std::string& url) throw(InvalidURL,NetDbError);
    
    URL(const URL& url);
    
    ~URL();

    inline const std::string& protocol() const
    { return m_proto; }

    void setProtocol(const std::string& proto, bool setPort = true);
    
    inline const std::string& host() const
    { return m_host; }

    void setHost(const std::string& host);

    inline const std::string& user() const
    { return m_user; }

    void setUser(const std::string& user);

    inline const std::string& password() const
    { return m_passwd; }

    void setPassword(const std::string& passwd);
                        
    inline unsigned short port() const
    { return m_port; }

    void setPort(unsigned short port);
    
    inline const std::string& path() const
    { return m_path; }

    void setPath(const std::string& path);

    URL& operator=(const URL& url);
    URL& operator=(const std::string& url) throw(InvalidURL,NetDbError);

    bool operator==(const URL& url) const;
    
    std::string str() const;
    
    PNET_EXPORT friend std::ostream& operator<<(std::ostream& os, const URL& url);
    PNET_EXPORT friend std::istream& operator>>(std::istream& is, URL& url) throw(InvalidURL);
            
  private:
    static unsigned short lookupPort(const std::string& service, const std::string& proto = "tcp");
    
    std::string    m_proto;
    std::string    m_host;
    std::string    m_user;
    std::string    m_passwd;
    unsigned short m_port;
    std::string    m_path;
};

}

#endif
