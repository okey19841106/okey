/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _pexport_h_
#define _pexport_h_

#ifdef WIN32
  #define CXX_CLASS_EXPORT __declspec(dllexport)
  #define CXX_CLASS_IMPORT __declspec(dllimport)
#else
  #define CXX_CLASS_EXPORT
  #define CXX_CLASS_IMPORT
#endif

#ifdef PCORE_BUILD
  #define PCORE_EXPORT CXX_CLASS_EXPORT
#else
  #define PCORE_EXPORT CXX_CLASS_IMPORT
#endif

#ifdef PNET_BUILD
  #define PNET_EXPORT CXX_CLASS_EXPORT
#else
  #define PNET_EXPORT CXX_CLASS_IMPORT
#endif

#ifdef PIO_BUILD
  #define PIO_EXPORT CXX_CLASS_EXPORT
#else
  #define PIO_EXPORT CXX_CLASS_IMPORT
#endif

#ifdef PSQL_BUILD
  #define PSQL_EXPORT CXX_CLASS_EXPORT
#else
  #define PSQL_EXPORT CXX_CLASS_IMPORT
#endif

#ifdef PCRYPTO_BUILD
  #define PCRYPTO_EXPORT CXX_CLASS_EXPORT
#else
  #define PCRYPTO_EXPORT CXX_CLASS_IMPORT
#endif

#ifdef PGUI_BUILD
  #define PGUI_EXPORT CXX_CLASS_EXPORT
#else
  #define PGUI_EXPORT CXX_CLASS_IMPORT
#endif

#endif
