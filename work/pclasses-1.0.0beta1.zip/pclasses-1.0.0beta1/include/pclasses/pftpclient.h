/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _pftpclient_h_
#define _pftpclient_h_

#include <pclasses/pexport.h>
#include <pclasses/ptypes.h>
#include <pclasses/psocket.h>
#include <pclasses/purl.h>
#include <memory>
#include <iostream>
#include <string>
#include <list>

namespace P {

//! FTP error
/*!
  \ingroup net
*/
class PNET_EXPORT FTPError: public RuntimeError {
  public:
    FTPError(const char* what, const std::list<std::string>& text,
             const SourceInfo& si) throw();

    ~FTPError() throw();

    inline BaseError* clone() const
    { return new FTPError(*this); }

    inline const std::string& text() const
    { return m_text; }

  private:
    std::string m_text;
};


//! FTP response
/*!
  \ingroup net
*/
class PNET_EXPORT FTPResponse {
  public:
    FTPResponse(unsigned int code, std::list<std::string>& text);
    ~FTPResponse();

    //! Returns the response code
    inline unsigned int code() const
    { return m_code; }

    inline bool isPositivePreliminary() const
    { return (m_code >= 100 && m_code < 200); }

    inline bool isPositiveCompletion() const
    { return (m_code >= 200 && m_code < 300); }

    inline bool isPositiveIntermediate() const
    { return (m_code >= 300 && m_code < 400); }

    inline bool isNegativeTransient() const
    { return (m_code >= 400 && m_code < 500); }

    inline bool isNegativePermanent() const
    { return (m_code >= 500 && m_code < 600); }

    inline const std::list<std::string>& text() const
    { return m_text; }

    friend PNET_EXPORT std::ostream& operator<<(std::ostream& os, const FTPResponse& resp);

  private:
    unsigned int            m_code;
    std::list<std::string>  m_text;

};

class FTPClient;

//! FTP Client Data connection
/*!
  \ingroup net
*/
class PNET_EXPORT FTPData: public StreamSocket {
  public:
    FTPData(FTPClient* cl, StreamSocketServer& srv) throw(IOError);
    FTPData(FTPClient* cl, const NetworkAddress& addr, port_t port) throw(IOError);

    ~FTPData() throw();

    size_t write(const char* buffer, size_t count) throw(IOError);

    size_t read(char* buffer, size_t count) throw(IOError);

  private:
    FTPClient*  m_client;
};

//! FTP Client
/*!
  \ingroup net
*/
class PNET_EXPORT FTPClient: protected StreamSocket {
  public:
    //! FTP transfer modes
    enum transMode_t {
      ModeStream,
      ModeBlock,
      ModeCompressed
    };

    enum transType_t {
      TypeASCII,
      TypeEBCDIC,
      TypeImage
    };

    enum dataMode_t {
      Passive,
      Active
    };

    FTPClient(int domain) throw(IOError);
    FTPClient(const NetworkAddress& addr, port_t port) throw(IOError);
    ~FTPClient() throw();

    void connect(const NetworkAddress& addr, port_t port) throw(IOError, FTPError);

    void close() throw(IOError);

    void sendCmd(const std::string& cmd) throw(IOError);
    const FTPResponse* readResponse() throw(IOError);

    const FTPResponse* lastResponse();

    void login(const std::string& user, const std::string& passwd,
               const std::string& account = "") throw(IOError, FTPError);

    void logout() throw(IOError, FTPError);

    void setMode(transMode_t mode) throw(IOError, FTPError);

    inline transMode_t mode() const throw()
    { return m_transMode; }

    void setType(transType_t type) throw(IOError,FTPError);

    inline transType_t type() const throw()
    { return m_transType; }

    //! Current working directory
    /*!
      This method is used to retrieve the current working directory
      from the server.
    */
    std::string cwd() throw(IOError, FTPError);

    //! Change working directory
    void chdir(const std::string& path) throw(IOError, FTPError);

    //! Change directory one level up
    void cdup() throw(IOError, FTPError);

    //! Remove directory
    /*!
      Use this method to create a directory on the server.
      \param path the path of the Directory that should be created
      \return true on success, false otherwise
    */
    void mkdir(const std::string& path) throw(IOError, FTPError);

    //! Remove directory
    /*!
      Use this method to remove a directory on the server.
      \param path the path of the Directory to remove
      \return true on success, false otherwise
    */
    void rmdir(const std::string& path) throw(IOError, FTPError);

    //! Remove file
    void remove(const std::string& path) throw(IOError, FTPError);

    //! Retrieve directory listing
    FTPData* dir(const std::string& path = "") throw(IOError, FTPError);

    FTPData* store(const std::string& path) throw(IOError, FTPError);

    FTPData* retrieve(const std::string& path) throw(IOError, FTPError);

    //! No operation
    /*!
      This method executes a NO-OP on the server. This command
      can be used to keep the server from closing the connection
      after a idle timeout.
      \return true on success, false otherwise
    */
    void noop() throw(IOError, FTPError);

    //! Test if data is available
    bool testResponse() throw(IOError);

    inline FTPData* dataConn() const throw()
    { return m_dataConn; }

  private:
    void initDataConn(const std::string& cmd) throw(IOError, FTPError);

    transMode_t   m_transMode;
    transType_t   m_transType;
    dataMode_t    m_dataMode;
    FTPData*      m_dataConn;
    FTPResponse*  m_lastResp;
};

}

#endif
