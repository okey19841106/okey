/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _plog_h_
#define _plog_h_

#include <pclasses/pexport.h>
#include <pclasses/pexception.h>
#include <pclasses/pcriticalsection.h>
#include <pclasses/pthreadkey.h>
#include <pclasses/ptime.h>
#include <set>
#include <list>
#include <string>
#include <iostream>

namespace P {

//! Log message level
/*!
  Log message severities
  \ingroup core
*/
enum LogLevel {
  LOG_DEBUG = 0,    /*!< Debug message */
  LOG_INFO,         /*!< Informational message */
  LOG_NOTICE,       /*!< Noticable message */
  LOG_WARNING,      /*!< Warning message */
  LOG_ERROR,        /*!< Error message */
  LOG_CRITICAL,     /*!< Critical error message */
  LOG_EMERGENCY     /*!< Emergency error message */
};

//! Message logging target base class
/*!
  The base class for all application log message targets.
  \author Christian Prochnow <cproch@seculogix.de>
  \ingroup core
*/
class PCORE_EXPORT Logger {
  public:
    Logger();
    virtual ~Logger();

    inline void setLogLevel(LogLevel l)
    { m_level = l; }

    inline LogLevel logLevel() const
    { return m_level; }

    virtual void start(const std::string& path) = 0;
    virtual void stop() = 0;
    virtual void restart() = 0;

    virtual bool isActive() const = 0;

    virtual void output(const DateTime& t, LogLevel l, const std::string& ident, const std::string& subsys, const char* msg) = 0;

    static std::string logLevel2Str(LogLevel l);
    static LogLevel str2LogLevel(const std::string& str);

  private:
    LogLevel  m_level;
};

//! Application message logging class
/*!
  The system logging class can be used to output application log
  messages on multiple logging targets.
  To output a log message simply use the stream output operators.
  The class is thread-safe. It maintains a separate output buffer,
  subsystem identifier and log message level for each thread.
  \author Christian Prochnow <cproch@seculogix.de>
  \ingroup core
*/
class PCORE_EXPORT SystemLog: protected std::streambuf, public std::ostream
{
  public:
    //! Constructor
    /*!
      \param ident Application identifier
    */
    SystemLog(const std::string& ident);
    ~SystemLog();

    //! Returns the application identifier
    inline const std::string& ident() const
    { return m_ident; }

    //! Add a logger
    void addLogger(Logger* log);

    //! Remove a logger
    bool removeLogger(Logger* log);

    //! Restart current active loggers
    void restart();

    //! Enable logging of subsystem
    void enableSubsys(const std::string& name);

    //! Disable logging of subsystem
    void disableSubsys(const std::string& name);

    //! Set subsystem identifier and log message severity for calling thread
    SystemLog& operator()(const std::string& subsys, LogLevel l);

    //! Set log message severity for calling thread
    SystemLog& operator()(LogLevel l);

    inline const std::list<Logger*> loggers() const
    { return m_loggers; }

  protected:
    int overflow(int c);

  private:
    struct LogState;
    LogState* state();

    std::string           m_ident;
    ThreadKey<LogState>   m_state;
    CriticalSection       m_lock;
    std::list<Logger*>    m_loggers;
    std::set<std::string> m_disabled;
};

/*!
  \example logging.cpp
  Example of how to use the SystemLog class.
*/

}

#endif
