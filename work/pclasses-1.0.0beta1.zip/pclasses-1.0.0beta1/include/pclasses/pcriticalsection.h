/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */                                                    

#ifndef _pcriticalsection_h_
#define _pcriticalsection_h_

#include <pclasses/pexport.h>

namespace P {

//! Critical section synchronization object
/*!
  Critical section objects provide synchronization similar
  to that provided by mutex objects, except that critical
  section objects can be used only by the threads of a
  single process, and they are slightly faster.
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PCORE_EXPORT CriticalSection {
 public:
  //! Constructor
  CriticalSection() throw();

  //! Destructor
  ~CriticalSection() throw();

  //! Lock the critical section
  /*!
    Tries to lock the critical section, if another thread
    currently owns the critical section, the caller will
    block until the critical section becomes available.
  */
  void lock() throw();

  //! Try locking the critical section
  bool tryLock() throw();

  //! Unlock the critical section
  void unlock() throw();

  //! CriticalSection Lock Guard
  /*!
    The lock guard class is used to do exception-safe
    locking. Simply put a Lock object on the Stack.
    When the stack-frame is unwinded (by a throw, or
    a return) the CriticalSection will be unlocked.
    \ingroup core
    The following example shows how to use the Lock guard:
\code
class X {
  void a(int val);
  private:
    CriticalSection cs;
    int   var;
}

void X::a(int val)
{
  CriticalSection::Lock l(cs);
  var = val;
}
\endcode
  */
  class Lock {
    public:
      inline Lock(CriticalSection& cs)
      : m_cs(cs) { cs.lock(); }
  
      ~Lock()
      { m_cs.unlock(); }

      Lock& operator=(CriticalSection& cs)
      {
        m_cs.unlock();
        m_cs = cs;
        m_cs.lock();
        return *this;
      }

    private:
      Lock(const Lock&);
      Lock& operator=(const Lock&);

      CriticalSection& m_cs;
  };
  
 private:
  CriticalSection(const CriticalSection&);
  CriticalSection& operator=(const CriticalSection&);

  struct cs_handle_t;
  cs_handle_t* m_handle;
};

}

#endif
