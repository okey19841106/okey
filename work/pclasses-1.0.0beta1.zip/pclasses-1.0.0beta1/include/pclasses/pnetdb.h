/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _pnetdb_h_
#define _pnetdb_h_

#include <pclasses/pexport.h>
#include <pclasses/pexception.h>
#include <pclasses/psocket.h>
#include <string>
#include <vector>

struct hostent;
struct servent;

namespace P {

//! NetDb error class
/*!
  \author Christian Prochnow <cproch@seculogix.de>
  \ingroup net
*/
class PNET_EXPORT NetDbError: public RuntimeError {
  public:
    inline NetDbError(int err, const char* _what, const SourceInfo& _si) throw()
      : RuntimeError(_what,_si), m_err(err) {}

    inline BaseError* clone() const
    { return new NetDbError(*this); }

    inline int error() const throw()
    { return m_err; }

    std::string text() const throw();

  private:
    int m_err;
};

//! NetDb resolver class
/*!
  \author Christian Prochnow <cproch@seculogix.de>
  \ingroup net
*/
class PNET_EXPORT NetDb {
  public:

    //! NetDb Hostentry class
    /*!
      \author Christian Prochnow <cproch@seculogix.de>
      \ingroup net
    */
    class PNET_EXPORT HostEntry {
      friend class NetDb;

      public:
        HostEntry();
        HostEntry(const HostEntry& h);
        HostEntry(const hostent* h);
        ~HostEntry();

        inline int domain() const
        { return m_domain; }

        inline const std::string& name() const
        { return m_name; }

        inline const std::string& alias(int num) const
        { return m_aliases[num]; }

        inline const NetworkAddress& addr(int num) const
        { return *m_addrs[num]; }

        inline int addrCount() const
        { return m_addrs.size(); }

        HostEntry& operator=(const HostEntry& h);

      private:
        int                          m_domain;
        std::string                  m_name;
        std::vector<std::string>     m_aliases;
        std::vector<NetworkAddress*> m_addrs;
    };

    //! NetDb Serviceentry class
    /*!
      \author Christian Prochnow <cproch@seculogix.de>
      \ingroup net
    */
    class PNET_EXPORT ServiceEntry {
      friend class NetDb;
      
      public:
        ServiceEntry();
        ServiceEntry(const ServiceEntry& s);
        ServiceEntry(const servent* s);
        ~ServiceEntry();
        
        inline const std::string& name() const
        { return m_name; }

        inline const std::string& alias(int num) const
        { return m_aliases[num]; }

        inline port_t port() const
        { return m_port; }

        inline const std::string& protocol() const
        { return m_proto; }

        ServiceEntry& operator=(const ServiceEntry& s);

      private:
        std::string     m_name;
        std::vector<
          std::string>  m_aliases;
        port_t          m_port;
        std::string     m_proto;
    };


    //! Resolve a host by it's name
    static HostEntry hostByName(const std::string& name, int domain) throw(NetDbError);

    //! Resolve a host by it's address
    static HostEntry hostByAddress(const NetworkAddress& addr) throw(NetDbError);

    //! Resolve a service by it's name & protocol
    static ServiceEntry serviceByName(const std::string& name, const std::string& proto) throw(NetDbError);

    //! Resolve a service by it's port & protocol
    static ServiceEntry serviceByPort(port_t port, const std::string& proto) throw(NetDbError);

};

}

#endif
