/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _pfileinfo_h_
#define _pfileinfo_h_

#include <pclasses/config.h>
#include <pclasses/pexport.h>
#include <pclasses/ptypes.h>
#include <pclasses/ptime.h>
#include <string>

namespace P {

//! Filesystem object info class
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PCORE_EXPORT FileInfo {
  public:
    #ifndef HAVE_LARGEFILE64
    typedef off_t fsize_t;
    #else
    typedef off64_t fsize_t;
    #endif

    //! Filesystem object type
    enum ftype_t {
      Unknown,      /*!< Unknown file type */
      File,         /*!< Regular file */
      Directory,    /*!< Directory */
      CharDevice,   /*!< Character device */
      BlockDevice,  /*!< Block device */
      Link,         /*!< Filesystem link */
      Pipe          /*!< Anonymous-/Namedpipe */
    };

    FileInfo(const char* path) throw(IOError);
    FileInfo(const FileInfo& fi);
    ~FileInfo();

    //! Returns the name of the directory (may be relative)
    inline const std::string& dirName() const throw()
    { return m_dirName; }

    //! Returns the absolute directory name
    std::string absDirName() const throw(SystemError);

    //! Returns the name of the filesystem object
    inline const std::string& name() const throw()
    { return m_name; }

    //! Returns the full path to the filesystem object
    std::string path() const throw();

    //! Returns the full absolute path to the filesystem object
    std::string absPath() const throw(SystemError);

    //! Returns the size of the filesystem object
    inline fsize_t size() const throw()
    { return m_size; }

    //! Returns the type of the filesystem object
    inline ftype_t type() const throw()
    { return m_type; }

    //! Returns the creation time
    inline const DateTime& ctime() const throw()
    { return m_ctime; }

    //! Returns the last-modified time
    inline const DateTime& mtime() const throw()
    { return m_mtime; }

    //! Returns the last-accessed time
    inline const DateTime& atime() const throw()
    { return m_atime; }

    FileInfo& operator=(const FileInfo& fi) throw();

  private:
    fsize_t     m_size;
    ftype_t     m_type;
    std::string m_dirName;
    std::string m_name;
    DateTime    m_ctime, m_mtime, m_atime;
};

}

#endif
