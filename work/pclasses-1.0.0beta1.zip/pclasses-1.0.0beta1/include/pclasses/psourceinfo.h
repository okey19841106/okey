/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _psourceinfo_h_
#define _psourceinfo_h_

#include <pclasses/pexport.h>

/* GNU C++ compiler */
#ifdef __GNUC__
  #define P_PRETTY_FUNCTION __PRETTY_FUNCTION__
/* Borland C++ */
#elif defined(__BORLANDC__)
  #define P_PRETTY_FUNCTION __FUNC__
/* Microsoft C++ compiler */
#elif defined(_MSC_VER_)
  /* .NET 2003 support's demangled function names */
  #if _MSC_VER_ >= 1300
    #define P_PRETTY_FUNCTION __FUNCDNAME__
  #else
    #define P_PRETTY_FUNCTION __FUNCTION__
  #endif
/* otherwise use standard macro */
#else
  #define P_PRETTY_FUNCTION __FUNCTION__
#endif

#define P_SOURCEINFO P::SourceInfo(__FILE__,__LINE__,P_PRETTY_FUNCTION)

namespace P {

//! Source code error location class
/*!
  This class is used by exception classes for storing information
  about the location in the source code where the error occured.
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PCORE_EXPORT SourceInfo {
  public:
    //! Default constructor
    SourceInfo() throw();

    //! Copy constructor
    SourceInfo(const SourceInfo& si) throw();

    //! Constructor
    /*!
      \param _file pointer to the filename of the source
      \param _line line number of the source
      \param _func function name of the source
    */
    SourceInfo(const char* _file, unsigned int _line, const char* _func) throw();

    //! Return the filename
    /*!
      Returns the name of the file where the exception has
      been thrown.
      \return name of the file where the exception was thrown
    */
    inline const char* file() const throw() {
      return m_file;
    }

    //! Returns the line number
    /*!
      Returns the line number of the file where the exception
      has been thrown.
      \return line number where the exception was thrown
    */
    inline unsigned int line() const throw() {
      return m_line;
    }

    //! Returns the function signature
    /*!
      Returns the signature of the function where the exception
      has been thrown.
      \return the function signature
    */
    inline const char* func() const throw() {
      return m_func;
    }

    //! Assign operator
    SourceInfo& operator=(const SourceInfo& si);

  private:
    const char*   m_file;
    unsigned int  m_line;
    const char*   m_func;

};

}

#endif
