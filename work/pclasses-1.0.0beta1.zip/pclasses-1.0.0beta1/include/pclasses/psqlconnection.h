/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2002  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _psqlconnection_h_
#define _psqlconnection_h_

#include <pclasses/pexport.h>
#include <pclasses/psqlerror.h>
#include <pclasses/psqldriver.h>
#include <iostream>

namespace P {

//! SQL Database connection
/*!
  \ingroup sql
*/
class PSQL_EXPORT SQLConnection {
  public:
    //! Connection ctor
    /*!
      Initializes the connection object and then tries to connect 
      using the given database description.
    */
    SQLConnection(SQLDriver* drv, const std::string& user, const std::string& passwd,
                  const std::string& db, const std::string& host) throw(SQLError);
                  
    ~SQLConnection() throw();
    
    //! Open connection to database
    /*!
      Opens a connection to the database if not already
      connected.
    */
    void open() throw(SQLError);
    
    //! Close connection to database
    /*!
      Closes the connection to the database if connected.
    */
    void close() throw();
    
    //! Commit transaction
    void commit() throw(SQLError);
    
    //! Rollback transaction
    void rollback() throw(SQLError);
    
    //! Returns true if the connection is valid
    bool isValid() const throw();
            
    inline SQLDriver* driver() const throw()
    { return m_driver; }
    
    inline SQLDriver::ConnectionHandle* handle() const throw()
    { return m_handle; }
        
  private:
    SQLDriver*    m_driver;
    std::string   m_user;
    std::string   m_passwd;
    std::string   m_db;
    std::string   m_host;
    
    SQLDriver::
      ConnectionHandle* m_handle;

};

}

#endif
