/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _piomanager_h_
#define _piomanager_h_

#include <pclasses/pexport.h>
#include <pclasses/pcriticalsection.h>
#include <pclasses/piohandler.h>
#include <pclasses/piorequest.h>
#include <pclasses/pioplugin.h>
#include <map>

/*!
  \defgroup netio Transparent Network I/O library
  The library provides you with an easy to handle solution for accessing files
  and directories over network protocols. IOManager will automatically extend
  your program with network protocol handlers by dynamically loading protocol
  handler plugins.
  \sa IOManager
\code
IOManager ioman;
IORequest_Get* req = ioman.get(URL("http://web.de/"));
req->open();
while(1)
{
  req->receive(buff,sizeof(buff));
}
ioman.finish(req);
\endcode
*/

namespace P {

//! Network I/O Manager
/*!
  The Network I/O Manager is used to transparently access files
  stored on the network.
  \ingroup netio
*/
class PIO_EXPORT IOManager {
  public:
    IOManager();
    ~IOManager();

    inline void addPlugin(const char* path) throw(SystemError)
    { m_pluginFactory.addPlugin(path); }

    inline void addPluginDir(const char* path) throw(SystemError)
    { m_pluginFactory.addPluginDir(path); }

    //! Get a file from network
    IORequest_Get* get(const URL& url);

    //! Put a file onto network
    IORequest_Put* put(const URL& url);

    //! Unlink (delete) a file
    IORequest_Unlink* unlink(const URL& url);

    //! Create a directory
    IORequest_MakeDir* mkdir(const URL& url);

    //! Remove a directory
    IORequest_RemoveDir* rmdir(const URL& url);

    //! List directory contents
    IORequest_ListDir* list(const URL& url);

    //! Finish a request
    void finish(IORequest* job);

  private:
    IOHandler* findCreateHandler(const std::string& proto);

    IOHandlerPluginFactory             m_pluginFactory;
    std::map<std::string, IOHandler*>  m_plugins;

};

}

#endif
