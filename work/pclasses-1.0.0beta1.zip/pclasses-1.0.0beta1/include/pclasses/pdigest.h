/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _pdigest_h_
#define _pdigest_h_

#include <pclasses/pexport.h>
#include <string>
#include <iostream>

/*!
  \defgroup crypto Crypto/Digest library
*/

namespace P {

//! Digest base class
/*!
  The base class for digest algorithms.
  \ingroup crypto
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PCRYPTO_EXPORT Digest {
  public:
    Digest();
    virtual ~Digest();

    //! Update digest sum
    /*!
      Updates the digest. The method may be called many times
      before the digest string is being retrieved with digest().
      \param buff The input buffer
      \param len Size of the input buffer
    */
    virtual void update(const char* buff, size_t len) = 0;

    //! Get the current digest
    /*!
      Retrieves the current digest sum as a string. The method
      does not wipe out the current object state, if you want
      to re-use the object to calculate another sum call clear().
      \return A string containing the current digest
    */
    virtual std::string digest() const = 0;

    //! Clear the digest
    /*!
      Reinitializes the digest object.
      Wipes out current object state and reinitializes it with
      the magic values. After that you can calculate another
      digest using update().
    */
    virtual void clear() = 0;

    //! Update digest sum
    Digest& operator<<(const std::string& str);

    //! Output digest
    friend PCRYPTO_EXPORT std::ostream& operator<<(std::ostream& os, const Digest& dig);

};

}

#endif
