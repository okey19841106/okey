/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _pinet6addr_h_
#define _pinet6addr_h_

#include <pclasses/pexport.h>
#include <pclasses/ptypes.h>
#include <pclasses/pnetaddr.h>
#include <iostream>
#include <string>

struct in6_addr;

namespace P {

//! Internet address (IPv6)
/*!
  \ingroup net
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PNET_EXPORT Inet6Address: public NetworkAddress {
  public:
    //! Default constructor (IN6ADDR_ANY)
    Inet6Address();

    Inet6Address(const NetworkAddress& addr);

    //! Address string constructor
    Inet6Address(const std::string& ip6addr);

    //! Native address constructor
    Inet6Address(const in6_addr& addr);

    //! Returns the 64bit internet address
    const in6_addr& inaddr() const;

    //! Returns the address as a string
    std::string str() const;

    NetworkAddress* clone() const;

    //! Address assign operator
    Inet6Address& operator=(const in6_addr& addr);

    //! Address string assign operator
    Inet6Address& operator=(const std::string& ip6addr);

    PNET_EXPORT friend std::ostream& operator<<(std::ostream& os, const Inet6Address& addr);
    PNET_EXPORT friend std::istream& operator>>(std::istream& is, Inet6Address& addr);

};

}

#endif
