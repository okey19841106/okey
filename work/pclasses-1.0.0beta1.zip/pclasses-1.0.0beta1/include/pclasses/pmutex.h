/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *   
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *   
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _pmutex_h_
#define _pmutex_h_

#include <pclasses/pexport.h>
#include <pclasses/pexception.h>

namespace P {

//! Mutex synchronization object
/*!
  A Mutex is a mutual exclusion device. It is used to synchronize
  the access to data which is accessed by more than one thread or
  process at the same time. Mutexes are recursive, that is the
  same thread can lock a mutex multiple times without deadlocking.
  When unlocking the mutex, unlock() must be called for each time
  a thread has successfully called lock() or tryLock().
  \sa RWLock
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PCORE_EXPORT Mutex {
  public:
    //! Default constructor
    /*!
    Construct the Mutex object. If a name is given, the mutex can be
    shared by multiple processes, otherwise a process-local	mutex is
    created. On POSIX systems named mutexes are implemented	using a
    shared memory segment which contains the pthread_mutex_t structure.
    \param name a pointer to the name of the mutex which is used
           to identify the mutex, or a NULL pointer if the mutex
           should be process-local. On POSIX systems the name must
           reffer to an existing file and the process must be able
           to stat() the file.
    \throw SyncError
    */
    Mutex(const char* name = 0) throw(SyncError);

    //! Destructor
    /*!
     The destructor destroys the mutex. The mutex must be in unlocked
     state when the destructor is called. On POSIX systems this also
     removes the shared memory segment which contains the pthread_mutex_t
     structure if no more processes references to it.
    */
    ~Mutex() throw();

    //! Lock the mutex
    /*!
     Locks the mutex. If the mutex is currently locked by another
     thread, the calling thread suspends until no other thread holds
     a lock on it. If the mutex is already locked by the calling
     thread the function returns immediatly with incrementing the lock-
     count of the mutex. This prevents a thread from dead-locking while
     waiting for a mutex it already owns. To release its ownership under
     such circumstances the thread must unlock the mutex once for each
     time the thread has locked the mutex.
     \sa Mutex::Lock
     \throw SyncError
    */
    void lock() throw(SyncError);

    //! Try locking the mutex with timeout
    /*!
     This method does the same than lock() but also supports a timeout-
     value. If the lock cannot be acquired in the given interval the
     method returns without locking the mutex and a FALSE return value.
     \param timeout the timeout in milliseconds to wait for the mutex. If
             zero is specified the method returns immediatly.
     \return TRUE if the mutex has been locked, FALSE otherwise.
     \throw SyncError
    */
    bool tryLock(unsigned int timeout) throw(SyncError);

    //! Unlock the mutex
    /*!
     Unlocks the mutex. If the mutex was locked more than one time by the
     same thread unlock decrements the lock-count. The mutex is actually
     unlocked when the lock-count is zero.
     \throw SyncError
    */
    void unlock() throw(SyncError);

    //! Mutex Lock Guard class
    /*!
      The lock guard class is used to do exception-safe
      locking. Simply put a Lock object on the Stack.
      When the stack-frame is unwinded (by a throw, or
      a return) the Mutex will be unlocked.
      \ingroup core
      The following example shows how to use the Lock guard:
\code
class X {
  void a(int val);
  private:
    Mutex mtx;
    int   var;
}

void X::a(int val)
{
  Mutex::Lock l(mtx);
  var = val;
}
\endcode
    */
    class Lock {
      public:
        inline Lock(Mutex& mutex)
        : m_mutex(mutex) { mutex.lock(); }

        ~Lock()
        { m_mutex.unlock(); }

        Lock& operator=(Mutex& mutex)
        {
          m_mutex.unlock();
          m_mutex = mutex;
          m_mutex.lock();
          return *this;
        }

      private:
        Lock(const Lock&);
        Lock& operator=(const Lock&);
        
        Mutex& m_mutex;
    };
    
  private:
    Mutex(const Mutex&);
    Mutex& operator=(const Mutex&);
 
    struct mutex_handle_t;
    mutex_handle_t* m_handle;
};

}

#endif
