/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _pinetaddr_h_
#define _pinetaddr_h_

#include <pclasses/pexport.h>
#include <pclasses/ptypes.h>
#include <pclasses/pnetaddr.h>
#include <iostream>
#include <string>

struct in_addr;

namespace P {

//! Internet address (IPv4)
/*!
  \ingroup net
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PNET_EXPORT InetAddress: public NetworkAddress {
  public:
    //! Default constructor (INADDR_ANY)
    InetAddress();

    //! Construct from a compatible NetworkAddress
    InetAddress(const NetworkAddress& addr);

    //! Native address constructor
    InetAddress(const in_addr& addr);

    //! Native address constructor
    InetAddress(uint32_t addr);

    //! Address string constructor
    InetAddress(const std::string& ipaddr);

    //! Address constructor using four octets
    InetAddress(uint8_t oct1, uint8_t oct2, uint8_t oct3, uint8_t oct4); 

    //! Returns the 32bit internet address
    const in_addr& inaddr() const;

    uint8_t oct1() const;
    uint8_t oct2() const;
    uint8_t oct3() const;
    uint8_t oct4() const;

    //! Returns the address as a string
    std::string str() const;

    NetworkAddress* clone() const;

    //! Address assign operator
    InetAddress& operator=(const in_addr& addr);

    //! Address assign operator
    InetAddress& operator=(uint32_t addr);

    //! Address string assign operator
    InetAddress& operator=(const std::string& ipaddr);

    PNET_EXPORT friend std::ostream& operator<<(std::ostream& os, const InetAddress& addr);
    PNET_EXPORT friend std::istream& operator>>(std::istream& is, InetAddress& addr);
};

}

#endif
