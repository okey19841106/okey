/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _piodevice_h_
#define _piodevice_h_

#include <pclasses/pconfig.h>
#include <pclasses/pexport.h>
#include <pclasses/pexception.h>
#include <pclasses/ptypes.h>

#ifdef WIN32
  #include <windows.h>
#endif

namespace P {

#ifdef WIN32
  typedef HANDLE io_handle_t;
#else
  typedef int io_handle_t;
  enum { INVALID_HANDLE_VALUE = -1 };
#endif

//! I/O device base class
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PCORE_EXPORT IODevice {
  public:
    //! Device access mode
    /*!
      Specifies how you want to access the device.
    */
    enum accessMode_t {
      Read,     /*!< Open file for reading */
      Write,    /*!< Open file for writing */
      ReadWrite /*!< Open file for reading and writing */
    };
    
    //! Device sharing mode
    /*!
      The device sharing mode is used to enable other processes
      to share the device while your process has it open.
    */
    enum shareMode_t {
      AllowNone,      /*!< Do'nt allow sharing */
      AllowRead,      /*!< Allow open for reading */
      AllowWrite,     /*!< Allow open for writing */
      AllowReadWrite  /*!< Allow open for read & write */
    };
    
    //! Operation modes for seek()
    enum seekMode_t {
      seekSet,     /*!< Absolute positioning */
      seekCurrent, /*!< Relative from current position */
      seekEnd      /*!< Relative from the end */
    };

    //! Default constructor
    IODevice() throw()
    : m_handle(INVALID_HANDLE_VALUE)
    { }

    //! Native handle constructor
    /*!
      The native I/O handle will be duplicated.
    */
    IODevice(io_handle_t handle) throw(IOError);

    //! Copy constructor
    IODevice(const IODevice& dev) throw(IOError);

    //! Destructor
    virtual ~IODevice() throw();

    //! Close i/o device
    virtual void close() throw(IOError);

    //! Write to device
    virtual size_t write(const char* buffer, size_t count) throw(IOError);

    //! Read from device
    virtual size_t read(char* buffer, size_t count) throw(IOError);

    //! Peek incoming data on device
    /*!
      Retrieves data from the receive queue without removing it.
      \param buffer pointer to buffer receiving the data
      \param count size of the buffer
      \return number of received bytes
    */
    virtual size_t peek(char* buffer, size_t count) throw(IOError)
    { throw IOError(0, "peek() is not supported on this type of device", P_SOURCEINFO); }

    //! Sync device with disk
    virtual void commit() throw(IOError);

    #ifndef HAVE_LARGEFILE64
    virtual off_t seek(off_t offset, seekMode_t mode) throw(IOError);
    #else
    virtual off64_t seek(off64_t offset, seekMode_t mode) throw(IOError);
    #endif

    //! Test if device is seekable
    virtual bool isSeekable() const throw();

    //! Test if device is valid
    inline bool isValid() const throw()
    { return (m_handle != INVALID_HANDLE_VALUE); }

    IODevice& operator=(const IODevice& dev) throw(IOError);

    //! Returns the native handle
    inline io_handle_t handle() const throw()
    { return m_handle; }

    static void copy(IODevice& src, IODevice& dst, bool commit = false);
    
  protected:
    inline void setHandle(io_handle_t handle) throw()
    { m_handle = handle; }

  private:
    io_handle_t   m_handle;
};

}

#endif
