/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _phtml_h_
#define _phtml_h_

#include "pclasses/pexport.h"
#include <string>
#include <map>

namespace P {

//! HTML Push parser
/*!
  \ingroup core
*/
class PCORE_EXPORT HTMLParser {
  public:
    HTMLParser();
    virtual ~HTMLParser();

    typedef std::map<std::string, std::string> attr_map;

    //! Parse chunk of HTML data
    void parse(const char* buffer, int len);

    //! Finish parsing
    void finish();

    //! Reset the parser
    void reset();

    //! Called on start of an HTML-Document
    virtual void documentStart() {}

    //! Called at the end of an HTML-Document
    virtual void documentEnd() {}

    virtual void comment(const std::string& text) {}

    virtual void characters(const char* text, unsigned len) {}

    //! Called on start of an HTML-Element
    virtual void elementStart(const std::string& name, const attr_map& attrs) {}
    
    //! Called at the end of an HTML-Element 
    virtual void elementEnd(const std::string& name) {}

    virtual void warning(const std::string& msg) {}
    virtual void error(const std::string& msg) {}
    virtual void fatal(const std::string& msg) {}

  private:
    struct parser_context;
    parser_context*  m_context;

};

}

#endif
