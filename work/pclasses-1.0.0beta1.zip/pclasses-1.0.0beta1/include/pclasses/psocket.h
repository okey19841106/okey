/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _psocket_h_
#define _psocket_h_

#ifdef WIN32
  #include <winsock2.h>
#else
  #include <sys/types.h>
  #include <sys/socket.h>
#endif

#include <pclasses/pexport.h>
#include <pclasses/ptypes.h>
#include <pclasses/piodevice.h>
#include <pclasses/pnetaddr.h>
#include <string>

/*!
  \defgroup net Networking library
*/

namespace P {

typedef uint16_t port_t;

//! Socket i/o device
/*!
  \ingroup net
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PNET_EXPORT Socket: public IODevice {
  public:
    //! Socket constructor
    /*!
      Constructs a socket for the given protocol domain,
      socket type and protocol.
      for and accept incoming client connections.
      \param domain the protocol domain to use. supported
      domains are AF_INET, AF_INET6, AF_IPX and AF_ATALK.
      \param type the socket type to use. (SOCK_STREAM, SOCK_DGRAM)
      \param proto the protocol to use. use 0 for default.
      \throw IOError
    */
    Socket(int domain, int type, int proto) throw(IOError);

    //! Socket handle constructor
    Socket(io_handle_t handle, int domain, int type, int proto) throw(IOError);

    ~Socket() throw();

    //! Close the socket
    void close() throw(IOError);

    size_t write(const char* buffer, size_t count) throw(IOError);

    size_t peek(char* buffer, size_t count) throw(IOError);

    size_t read(char* buffer, size_t count) throw(IOError);

    inline bool isSeekable() const throw()
    { return false; }

    //! Protocol domain
    inline int domain() const throw()
    { return m_domain; }

    //! Socket type
    inline int type() const throw()
    { return m_type; }

    //! Socket protocol
    inline int protocol() const throw()
    { return m_protocol; }

    //! Socket wait flags
    enum wait_t {
      pendingInput   = 0x01,  /*!< Wait for pending input */
      pendingOutput  = 0x02   /*!< Wait for pending output */
    };

    //! Wait for socket events
    /*!
      \param wait mask of wait flags specifying for which
        events we should wait
      \param timeout the timeout in milliseconds to wait
      \throw IOError
    */
    int wait(int wait, unsigned int timeout) throw(IOError);

    void setBroadcast(bool enable) throw(IOError);

    void setRouting(bool enable) throw(IOError);

    //! Bind socket to given address and port
    void bind(const NetworkAddress& addr, port_t port) throw(IOError);

    //! Get name of socket
    void getName(NetworkAddress& addr, port_t& port) const throw(LogicError,IOError);

    //! Get address of peer
    void getPeer(NetworkAddress& addr, port_t& port) const throw(LogicError,IOError);

  private:
    int m_domain;
    int m_type;
    int m_protocol;
};

//! Stream socket server
/*!
  \ingroup net
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PNET_EXPORT StreamSocketServer: protected Socket {
  public:
    friend class StreamSocket;

    //! Protocol domain constructor
    /*!
      Constructs a stream server socket for the given
      protocol domain. The socket can then be used to listen
      for and accept incoming client connections.
      \param domain the protocol domain to use. supported
      domains are AF_INET, AF_INET6, AF_IPX and AF_ATALK.
      \throw IOError
    */
    StreamSocketServer(int domain) throw(IOError);

    //! Listen constructor
    /*!
      Constructs a stream server socket that is bound to
      the given address and listen's for client connections.
      \param addr the network address to bind to
      \param port the port on which the socket should be bound
      \throw IOError
    */
    StreamSocketServer(const NetworkAddress& addr, port_t port) throw(IOError);

    //! Destructor
    ~StreamSocketServer() throw();

    //! Listen for incoming connections
    /*!
      Listen for incoming connections on socket. The socket
      must be bound to an address before listening.
      Use Socket::bind() to bind the socket to an address.
      \throw IOError
    */
    void listen() throw(IOError);

    //! Wait for client
    /*!
      Waits for a client to connect to the socket server.
      \param timeout timeout in milliseconds.
      \return true if a client has connected, false otherwise.
    */
    bool waitClient(unsigned int timeout) throw(IOError);

    //! Get the address and port the Socket is bound to
    inline void getName(NetworkAddress& addr, port_t& port) const throw(LogicError,IOError)
    { Socket::getName(addr, port); }

  protected:

    //! Accept the pending connection
    io_handle_t accept() throw(IOError);

  private:
    StreamSocketServer(const StreamSocketServer&);
    StreamSocketServer& operator=(const StreamSocketServer&);

    io_handle_t m_lastAcceptHandle;
};

//! Stream socket
/*!
  \ingroup net
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PNET_EXPORT StreamSocket: public Socket {
  public:
    //! Socket shutdown modes
    enum sdmode_t {
      disableRecv = 0,  /*!< Disable receiving data */
      disableSend,      /*!< Disable sending data */
      disableBoth       /*!< Disable reading & sending of data */
    };

    //! Connecting constructor
    StreamSocket(const NetworkAddress& addr, port_t port) throw(IOError);

    //! Protocol domain constructor
    StreamSocket(int domain) throw(IOError);

    //! Connection accept constructor
    StreamSocket(StreamSocketServer& srv) throw(IOError);

    ~StreamSocket() throw();

    void close() throw(IOError);

    //! Shutdown socket stream
    void shutdown(sdmode_t mode);

    void connect(const NetworkAddress& addr, port_t port) throw(IOError);

    std::string readLine(unsigned int timeout) throw(IOError);

};

//! Datagram socket
/*!
  \ingroup net
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PNET_EXPORT DatagramSocket: public Socket {
  public:
    //! Connecting constructor
    DatagramSocket(const NetworkAddress& addr, port_t port) throw(IOError);

    //! Protocol domain constructor
    DatagramSocket(int domain) throw(IOError);

    ~DatagramSocket() throw();

    size_t write(const char* buffer, size_t count) throw(IOError);

    size_t read(char* buffer, size_t count) throw(IOError);

    size_t peek(char* buffer, size_t count) throw(IOError);

    void setPeer(const NetworkAddress& addr, port_t port) throw();

    const NetworkAddress& getSender(port_t& port) const throw();

  private:
    void retrSenderAddr(sockaddr* sa, size_t salen);

    NetworkAddress* m_peer;
    port_t          m_peerPort;
    NetworkAddress* m_sender;
    port_t          m_senderPort;
};

}

#endif
