/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _pmd4_h_
#define _pmd4_h_

#include <pclasses/pexport.h>
#include <pclasses/pdigest.h>
#include <pclasses/ptypes.h>

namespace P {

//! MD5 Message Digest
/*!
  \ingroup crypto
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PCRYPTO_EXPORT MD4Digest: public Digest {
  public:
    enum {
      DIGEST_SIZE = 16,
      BLOCK_SIZE  = 64,
      BLOCK_WORDS = 16,
      HASH_WORDS  = 4
    };

    MD4Digest();
    MD4Digest(const MD4Digest& dig);
    ~MD4Digest();

    virtual void update(const char* buff, size_t len);
    virtual std::string digest() const;
    virtual void clear();

    MD4Digest& operator=(const MD4Digest& dig);

  private:
    void init();
    void transform(const uint32_t* buffer);

    uint64_t  m_byteCount;
    uint32_t  m_hash[HASH_WORDS];
    uint32_t  m_block[BLOCK_WORDS];
};

}

#endif
