/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _psharedlib_h_
#define _psharedlib_h_

#include <pclasses/pexport.h>
#include <pclasses/pexception.h>
#include <string>

namespace P {

//! Shared library loader
/*!
  A class that can be used to dynamically load shared libraries
  to resolve symbols from it. The example below shows how to retrieve
  the address of the cos function in the math library:
\code
SharedLib shl("libm.so");
double (*cosine)(double);
cosine = shl["cos"];
(*cosine)(2.0);
\endcode
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PCORE_EXPORT SharedLib {
  public:
    //! Function binding mode
    enum ldmode_t {
      bindNow,  /*!< Bind now */
      bindLazy  /*!< Bind lazy (on first call) */
    };

    //! Constructor
    /*!
      Constructs the object and loads the shared library specified
      in the path argument.
      \param path the path to the shared library
      \param mode enum specifying the mode when loading the shlib
      \throw SystemError
    */
    SharedLib(const std::string& path, ldmode_t mode = bindLazy) throw(SystemError);

    //! Destructor
    /*!
      The destructor unloads the shared library from memory.
    */
    ~SharedLib() throw();

    //! Resolve symbol from shared library
    /*!
      Resolves a symbol from the shared library and
      returns a pointer to the symbol.
      \return the address of the symbol
        or NULL if it was not found
    */
    void* operator[](const char* symbol) throw();

  private:
    SharedLib(const SharedLib&);
    SharedLib& operator=(const SharedLib&);
  
    struct dso_handle_t;
    dso_handle_t* m_handle;
};

}

#endif
