/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _pconfigstore_h_
#define _pconfigstore_h_

#include <pclasses/pexport.h>
#include <pclasses/pconfig.h>
#include <string>

namespace P {

//! Configuration storage interface
/*!
  \ingroup core
*/
class PCORE_EXPORT ConfigStore {
  public:
    friend class Config;

    //! Config storage constructor
    /*!
      \param path The path to the configuration store
    */
    ConfigStore(const std::string& path);
    virtual ~ConfigStore();

    //! Returns the path to the configuration store
    inline const std::string& path() const
    { return m_path; }

  protected:
    virtual void read(Config::Key& root) = 0;
    virtual void update(Config::Key& root) = 0;

  private:
    std::string m_path;

};

}

#endif
