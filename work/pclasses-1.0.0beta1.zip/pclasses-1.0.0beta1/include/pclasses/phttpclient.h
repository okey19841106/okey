/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _phttpclient_h_
#define _phttpclient_h_

#include <pclasses/pexport.h>
#include <pclasses/ptypes.h>
#include <pclasses/psocket.h>
#include <pclasses/purl.h>
#include <memory>
#include <map>
#include <string>

namespace P {

//! HTTP Response codes
/*!
  Response codes used by the Hypertext-Transfer-Protocol.
  \ingroup net
*/
enum httpResponseCode_t {
  HTTP_100_CONTINUE           = 100,
  HTTP_101_SWITCHING_PROTOCOL = 101,
  HTTP_200_OK                 = 200,
  HTTP_201_CREATED            = 201,
  HTTP_202_ACCEPTED           = 202,
  HTTP_203_NON_AUTH_INFO      = 203,
  HTTP_204_NO_CONTENT         = 204,
  HTTP_205_RESET_CONTENT      = 205,
  HTTP_206_PARTIAL_CONTENT    = 206,
  HTTP_300_MULTIPLE_CHOICES   = 300,
  HTTP_301_MOVED_PERMANENTLY  = 301,
  HTTP_302_FOUND              = 302,
  HTTP_303_SEE_OTHER          = 303,
  HTTP_304_NOT_MODIFIED       = 304,
  HTTP_305_USE_PROXY          = 305,
  HTTP_307_TEMPORARY_REDIRECT = 307,
  HTTP_400_BAD_REQUEST        = 400,
  HTTP_401_UNAUTHORIZED       = 401,
  HTTP_402_PAYMENT_REQUIRED   = 402,
  HTTP_403_FORBIDDEN          = 403,
  HTTP_404_NOT_FOUND          = 404,
  HTTP_405_METHOD_NOT_ALLOWED = 405,
  HTTP_406_NOT_ACCEPTABLE     = 406,
  HTTP_407_PROXY_AUTH_REQUIRED= 407,
  HTTP_408_REQUEST_TIMEOUT    = 408,
  HTTP_409_CONFLICT           = 409,
  HTTP_410_GONE               = 410,
  HTTP_411_LENGTH_REQUIRED    = 411,
  HTTP_412_PRECONDITION_FAILED= 412,
  HTTP_413_REQUEST_TOO_LARGE  = 413,
  HTTP_414_REQ_URI_TOO_LONG   = 414,
  HTTP_415_UNSUPP_MEDIA_TYPE  = 415,
  HTTP_416_REQ_RANGE_INVALID  = 416,
  HTTP_417_EXPECTATION_FAILED = 417,
  HTTP_500_INTERNAL_ERROR     = 500,
  HTTP_501_NOT_IMPLEMENTED    = 501,
  HTTP_502_BAD_GATEWAY        = 502,
  HTTP_503_SERVICE_UNAVAILABLE= 503,
  HTTP_504_GATEWAY_TIMEOUT    = 504,
  HTTP_505_VERSION_UNSUPPORTED= 505
};

//! HTTP Header class
/*!
  The base class for a HTTP-Request or -Response.
  \ingroup net
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PNET_EXPORT HTTPHeader {
  public:
    typedef std::map<std::string, std::string> field_map;
    typedef field_map::iterator iterator;
    typedef field_map::const_iterator const_iterator;

    HTTPHeader();
    ~HTTPHeader();

    void set(const std::string& head, const std::string& val);
    const std::string& get(const std::string& head) const;

    bool remove(const std::string& head);
    bool contains(const std::string& head) const;

    inline void setCacheControl(const std::string& val)
    { set("Cache-Control", val); }

    inline void setConnection(const std::string& val)
    { set("Connection", val); }

    inline const std::string& connection() const
    { return get("Connection"); }

    inline void setDate(const std::string& val)
    { set("Date", val); }

    inline void setPragma(const std::string& val)
    { set("Pragma", val); }

    inline void setTrailer(const std::string& val)
    { set("Trailer", val); }

    inline void setTransferEncoding(const std::string& val)
    { set("Transfer-Encoding", val); }

    inline const std::string& transferEncoding() const
    { return get("Transfer-Encoding"); }

    inline void setUpgrade(const std::string& val)
    { set("Upgrade", val); }

    inline void setVia(const std::string& val)
    { set("Via", val); }

    inline void setWarning(const std::string& val)
    { set("Warning", val); }

    const std::string& operator[](const std::string& head) const;

    inline const_iterator begin() const
    { return m_values.begin(); }

    inline const_iterator end() const
    { return m_values.end(); }

    inline iterator begin()
    { return m_values.begin(); }

    inline iterator end()
    { return m_values.end(); }

  private:
    field_map m_values;
};

//! HTTP Request-Header
/*!
  A class used to encapsulate a HTTP Request-Header
  \ingroup net
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PNET_EXPORT HTTPRequestHeader: public HTTPHeader {
  public:
    HTTPRequestHeader() {}
    ~HTTPRequestHeader() {}

    inline void setAccept(const std::string& val)
    { set("Accept", val); }

    inline void setAcceptCharset(const std::string& val)
    { set("Accept-Charset", val); }

    inline void setAcceptEncoding(const std::string& val)
    { set("Accept-Encoding", val); }

    inline void setAcceptLanguage(const std::string& val)
    { set("Accept-Language", val); }

    inline void setAuthorization(const std::string& val)
    { set("Authorization", val); }

    inline void setExpect(const std::string& val)
    { set("Expect", val); }

    inline void setFrom(const std::string& val)
    { set("From", val); }

    inline void setHost(const std::string& val)
    { set("Host", val); }

    inline void setIfMatch(const std::string& val)
    { set("If-Match", val); }

    inline void setIfModifiedSince(const std::string& val)
    { set("If-Modified-Since", val); }

    inline void setIfNoneMatch(const std::string& val)
    { set("If-None-Match", val); }

    inline void setIfRange(const std::string& val)
    { set("If-Range", val); }

    inline void setIfUnmodifiedSince(const std::string& val)
    { set("If-Unmodified-Since", val); }

    inline void setMaxForwards(const std::string& val)
    { set("Max-Forwards", val); }

    inline void setProxyAuthorization(const std::string& val)
    { set("Proxy-Authorization", val); }

    inline void setRange(const std::string& val)
    { set("Range", val); }

    inline void setReferer(const std::string& val)
    { set("Referer", val); }

    inline void setTE(const std::string& val)
    { set("TE", val); }

    inline void setUserAgent(const std::string& val)
    { set("User-Agent", val); }

};

//! HTTP Response-Header
/*!
  A class used to encapsulate a HTTP Response-Header
  \ingroup net
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PNET_EXPORT HTTPResponseHeader: public HTTPHeader {
  public:
    HTTPResponseHeader() {}
    ~HTTPResponseHeader() {}

    inline void setAcceptRanges(const std::string& val)
    { set("Accept-Ranges", val); }

    inline void setAge(const std::string& val)
    { set("Age", val); }

    inline void setETag(const std::string& val)
    { set("ETag", val); }

    inline void setLocation(const std::string& val)
    { set("Location", val); }

    inline void setProxyAuthenticate(const std::string& val)
    { set("Proxy-Authenticate", val); }

    inline void setRetryAfter(const std::string& val)
    { set("Retry-After", val); }

    inline void setServer(const std::string& val)
    { set("Server", val); }

    inline void setVary(const std::string& val)
    { set("Vary", val); }

    inline void setWWWAuthenticate(const std::string& val)
    { set("WWW-Authenticate", val); }

    inline void setAllow(const std::string& val)
    { set("Allow", val); }

    inline void setContentEncoding(const std::string& val)
    { set("Content-Encoding", val); }

    inline void setContentLanguage(const std::string& val)
    { set("Content-Language", val); }

    inline void setContentLegth(const std::string& val)
    { set("Content-Legth", val); }

    inline void setContentLocation(const std::string& val)
    { set("Content-Location", val); }

    inline void setContentMD5(const std::string& val)
    { set("Content-MD5", val); }

    inline void setContentRange(const std::string& val)
    { set("Content-Range", val); }

    inline void setContentType(const std::string& val)
    { set("Content-Type", val); }

    inline void setExpires(const std::string& val)
    { set("Expires", val); }

    inline void setLastModified(const std::string& val)
    { set("Last-Modified", val); }

};

//! HTTP Client-Request
/*!
  \ingroup net
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PNET_EXPORT HTTPRequest {
  public:
    //! HTTP Request methods
    enum reqmethod_t {
      METHOD_HEAD   = 0,
      METHOD_GET    = 1,
      METHOD_POST   = 2,
      METHOD_PUT    = 3,
      METHOD_DELETE = 4
    };

    HTTPRequest(reqmethod_t method, const URL& url);
    ~HTTPRequest();

    inline reqmethod_t method() const
    { return m_method; }

    inline const URL& url() const
    { return m_url; }

    inline const HTTPRequestHeader& header() const
    { return m_header; }

    inline HTTPRequestHeader& header()
    { return m_header; }

  private:
    reqmethod_t       m_method;
    URL               m_url;
    HTTPRequestHeader m_header;
};

//! HTTP Server-Response
/*!
  \ingroup net
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PNET_EXPORT HTTPResponse {
  public:
    HTTPResponse(const std::string& proto, int code, const std::string& resp);
    ~HTTPResponse();

    inline const HTTPResponseHeader& header() const
    { return m_header; }

    inline HTTPResponseHeader& header()
    { return m_header; }

    inline int code() const
    { return m_code; }

  private:
    std::string  m_proto;
    int          m_code;
    std::string  m_resp;
    HTTPResponseHeader m_header;
};

//! HyperText-Transfer-Protocol client class
/*!
  \ingroup net
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PNET_EXPORT HTTPClient: protected StreamSocket {
  public:
    HTTPClient(int domain) throw(IOError);

    HTTPClient(const NetworkAddress& addr, port_t port) throw(IOError);

    virtual ~HTTPClient() throw();

    void connect(const NetworkAddress& addr, port_t port) throw(IOError)
    { StreamSocket::connect(addr, port); }

    void sendRequest(const HTTPRequest& req) throw(IOError);

    std::auto_ptr<HTTPResponse> readResponse() throw(IOError);

    size_t readBody(const HTTPResponse& resp, char* buffer, size_t size);

  private:
    size_t  m_contentLength;    /*!< Content length as given by header */
    bool    m_chunkedEncoding;  /*!< True if chunked transfer encoding */
    size_t  m_chunkSize;        /*!< Current chunk size */
    size_t  m_bodyLength;       /*!< Already received length of body/chunk */

};

}

#endif
