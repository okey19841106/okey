/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _ptokenizer_h_
#define _ptokenizer_h_

#include <pclasses/pexport.h>
#include <string>
#include <iostream>
#include <sstream>

namespace P {

//! Stream tokenizer
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PCORE_EXPORT StreamTokenizer {
  public:
  
    //! Seperator match mode
    enum matchMode_t {
      MatchAll,    /*!< Match all characters */
      MatchAny     /*!< Match any character */
    };
  
    //! Constructor
    /*!
      \param is Reference to a stream that should be tokenized
      \param seperator The seperator string
      \param mode Matching mode for the given seperator
    */
    StreamTokenizer(std::istream& is, const std::string& seperator, matchMode_t mode = MatchAny);
    ~StreamTokenizer();

    //! Returns true while data is available
    operator bool() const;

    //! Read the next token
    StreamTokenizer& operator>>(std::string& token);

  private:
    matchMode_t     m_mode;
    std::istream&   m_is;
    std::string     m_separator;
};


//! String tokenizer
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PCORE_EXPORT StringTokenizer: public StreamTokenizer {
  public:
    StringTokenizer(const std::string& str, const std::string& seperator, matchMode_t mode = MatchAny);
    ~StringTokenizer();

  private:
    std::istringstream  m_is;
};

}

#endif
