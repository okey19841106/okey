/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _piorequest_h_
#define _piorequest_h_

#include <pclasses/pexport.h>
#include <pclasses/ptypes.h>
#include <pclasses/pexception.h>
#include <pclasses/psemaphore.h>
#include <pclasses/purl.h>
#include <string>
#include <map>


namespace P {

class IOHandler;
class IOManager;

//! Network I/O Request
/*!
  The base class for Network I/O requests. You may not need
  to use this class directly.
  \sa IORequest_Get IORequest_Put IORequest_Unlink IORequest_MakeDir
   IORequest_RemoveDir IORequest_ListDir
  \ingroup netio
*/
class PIO_EXPORT IORequest {
  public:
  
    //! Current state of the request
    enum state_t {
      Initial,     /*!< Initial */
      Open,        /*!< Connection is open */
      Transfer,    /*!< Transfer in progress */
      Finished,    /*!< Request is finihed */
      Failed       /*!< Request has failed */
    };

    friend class IOManager;
    friend class IOHandler;

    //! Constructor
    /*!
      Constructs the IORequest object.    
      \param handler Pointer to an IOHandler object
      \param url URL for the request
    */
    IORequest(IOHandler* handler, const URL& url);
    virtual ~IORequest();

    //! Returns a pointer to the IOHandler
    inline IOHandler* handler() const throw()
    { return m_handler; }

    //! Returns the URL addressed with this request
    inline const URL& url() const throw()
    { return m_url; }

    //! Returns the state of the request
    inline state_t state() const throw()
    { return m_state; }

  protected:
    inline void setState(state_t s) throw()
    { m_state = s; }

  private:
    IORequest(const IORequest&);
    IORequest& operator=(const IORequest&);

    IOHandler*    m_handler;
    URL           m_url;
    state_t       m_state;

  public:

    //! Network I/O Request error
    /*!
      \ingroup netio
    */
    class PIO_EXPORT Error: public RuntimeError {
      public:
        Error(const char* what, const std::string& text,
              const SourceInfo& si) throw();

        ~Error() throw();

        inline BaseError* clone() const
        { return new Error(*this); }

        inline const std::string& text() const
        { return m_text; }

      private:
        std::string m_text;
    };
};

//! Network I/O Get-request
/*!
  \ingroup netio
*/
class PIO_EXPORT IORequest_Get: public IORequest {
  public:
    IORequest_Get(IOHandler* handler, const URL& url);
    virtual ~IORequest_Get();

    //! Opens a connection to the requested URL
    /*!
      Open a connection to the URL through the IOHandler object
      that has been given upon object creation.
    */
    virtual void open() = 0;
    
    //! Closes the connection
    /*!
      Closes the previously opened connection through the 
      IOHandler object.
    */
    virtual void close() = 0;

    //! Receives requested data
    /*!
      Receives data from the previously opened connection
      using the IOHandler object.
      \param buff buffer for receiving the data
      \param count number of bytes requested
      \return number of bytes actually read, which may be
        less than requested.
    */
    virtual size_t receive(char* buff, size_t count) = 0;
};

//! Network I/O Put-request
/*!
  \ingroup netio
*/
class PIO_EXPORT IORequest_Put: public IORequest {
  public:
    IORequest_Put(IOHandler* handler, const URL& url);
    virtual ~IORequest_Put();

    //! Opens a connection to the requested URL
    /*!
      Open a connection to the URL through the IOHandler object
      that has been given upon object creation.
    */
    virtual void open() = 0;
    
    //! Closes the connection
    /*!
      Closes the previously opened connection through the 
      IOHandler object.
    */
    virtual void close() = 0;

    //! Send data
    /*!
      Sends data to the previously opened connection
      using the IOHandler object.
      \param buff buffer which should be sent
      \param count size of the buffer to send
      \return number of bytes actually sent, which may be
        less than requested.
    */
    virtual size_t send(const char* buff, size_t count) = 0;
};

//! Network I/O Unlink-request
/*!
  \ingroup netio
*/
class PIO_EXPORT IORequest_Unlink: public IORequest {
  public:
    IORequest_Unlink(IOHandler* handler, const URL& url);
    virtual ~IORequest_Unlink();

    virtual void unlink() = 0;
};

//! Network I/O Make directory-request
/*!
  \ingroup netio
*/
class PIO_EXPORT IORequest_MakeDir: public IORequest {
  public:
    IORequest_MakeDir(IOHandler* handler, const URL& url);
    virtual ~IORequest_MakeDir();

    virtual void mkdir() = 0;
};

//! Network I/O Remove directory-request
/*!
  \ingroup netio
*/
class PIO_EXPORT IORequest_RemoveDir: public IORequest {
  public:
    IORequest_RemoveDir(IOHandler* handler, const URL& url);
    virtual ~IORequest_RemoveDir();

    virtual void rmdir() = 0;
};

//! Network I/O List directory-request
/*!
  \ingroup netio
*/
class PIO_EXPORT IORequest_ListDir: public IORequest {
  public:
    IORequest_ListDir(IOHandler* handler, const URL& url);
    virtual ~IORequest_ListDir();

    virtual void list() = 0;
};

}

#endif
