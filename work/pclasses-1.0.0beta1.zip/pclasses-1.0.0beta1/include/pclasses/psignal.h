/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _psignal_h_
#define _psignal_h_

#include <pclasses/config.h>
#include <pclasses/pslot.h>
#include <pclasses/plocktraits.h>
#include <list>

namespace P {

//! Signal base class
/*!
  This class is used as a base class for the Signal<> classes.
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
  \param _SlotT
  \param _Mutex
*/
template <class _SlotT, class _Mutex>
class SignalBase {
  public:
    typedef _SlotT                SlotType;
    typedef std::list<SlotType*>  SlotList;
    typedef LockTraits<_Mutex>    LockTraits;

    typedef typename LockTraits::MutexType  MutexType;
    typedef typename LockTraits::ReadLock   ReadLock;
    typedef typename LockTraits::WriteLock  WriteLock;

    inline SignalBase()
    { }

    inline ~SignalBase()
    {
      /* delete all bound slots ... */
      typename SlotList::iterator i = _slots.begin();
      while(i != _slots.end())
      {
        delete *i;
        i = _slots.erase(i);
      }
    }

    //! Bind slot to signal
    inline void bind(SlotType& slot)
    {
      WriteLock wl(_mutex);
      _slots.push_back(slot.clone());
    }

    //! Unbind slot from signal
    template <class UnbindSlotType>
    inline void unbind(UnbindSlotType& slot)
    {
      WriteLock wl(_mutex);
      typename SlotList::iterator i = _slots.begin();
      while(i != _slots.end())
      {
        UnbindSlotType* s = static_cast<UnbindSlotType*>(*i);
        if(s && *s == slot)
        {
          delete *i;
          _slots.erase(i);
          return;
        }
        ++i;
      }
    }

  protected:

    //! Returns the list of bound slots
    SlotList slotList()
    {
      ReadLock rl(_mutex);
      return _slots;
    }

  private:
    SignalBase(const SignalBase&);
    SignalBase& operator=(const SignalBase&);

    MutexType  _mutex;
    SlotList   _slots;
};


//! Signal with no arguments and non-void return-type
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <class _RetT, class _Mutex = VoidMutex>
class Signal0: public SignalBase<Slot0<_RetT>, _Mutex> {
  public:
    typedef _RetT RetType;

    typedef SignalBase<
      Slot0<_RetT>,
      _Mutex
    > SignalBase;

    //! Emit the signal
    RetType emit()
    {
      typedef typename SignalBase::SlotList SlotList;
      RetType ret = RetType();
      SlotList slots = slotList();
      for(typename SlotList::const_iterator i = slots.begin(); i != slots.end(); ++i) {
        ret = (*i)->proxy();
        if(ret)
          break;
      }
      return ret;
    }
};


#ifdef CXX_PARTIAL_SPECIALIZATION

//! Signal with no arguments and void return-type
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <class _Mutex>
class Signal0<void, _Mutex>: public SignalBase<Slot0<void>, _Mutex> {
  public:
    typedef SignalBase<
      Slot0<void>,
      _Mutex
    > SignalBase;

    //! Emit the signal
    void emit()
    {
      typedef typename SignalBase::SlotList SlotList;
      SlotList slots = slotList();
      for(typename SlotList::const_iterator i = slots.begin(); i != slots.end(); ++i)
        (*i)->proxy();
    }
};

#endif


//! Signal with 1 argument and non-void return-type
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <class _RetT, class _ParamType1, class _Mutex = VoidMutex>
class Signal1: public SignalBase<Slot1<_RetT, _ParamType1>, _Mutex> {
  public:
    typedef _RetT RetType;

    typedef SignalBase<
      Slot1<_RetT, _ParamType1>,
      _Mutex
    > SignalBase;

    //! Emit the signal
    RetType emit(_ParamType1 p1)
    {
      typedef typename SignalBase::SlotList SlotList;
      RetType ret = RetType();
      SlotList slots = slotList();
      for(typename SlotList::const_iterator i = slots.begin(); i != slots.end(); ++i)
      {
        ret = (*i)->proxy(p1);
        if(ret)
          break;
      }
      return ret;
    }
};


#ifdef CXX_PARTIAL_SPECIALIZATION

//! Signal with 1 argument and void return-type
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <class _ParamType1, class _Mutex>
class Signal1<void, _ParamType1, _Mutex>:
  public SignalBase<Slot1<void, _ParamType1>, _Mutex>
{
  public:
    typedef SignalBase<
      Slot1<void, _ParamType1>,
      _Mutex
    > SignalBase;

    //! Emit the signal
    void emit(_ParamType1 p1)
    {
      typedef typename SignalBase::SlotList SlotList;
      SlotList slots = slotList();
      for(typename SlotList::const_iterator i = slots.begin(); i != slots.end(); ++i)
        (*i)->proxy(p1);
    }
};

#endif


//! Signal with 2 arguments and non-void return-type
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <class _RetT, class _ParamType1, class _ParamType2, class _Mutex = VoidMutex>
class Signal2:
  public SignalBase<Slot2<_RetT, _ParamType1, _ParamType2>, _Mutex>
{
  public:
    typedef _RetT RetType;

    typedef SignalBase<
      Slot2<_RetT, _ParamType1, _ParamType2>,
      _Mutex
    > SignalBase;

    //! Emit the signal
    RetType emit(_ParamType1 p1, _ParamType2 p2)
    {
      typedef typename SignalBase::SlotList SlotList;
      RetType ret = RetType();
      SlotList slots = slotList();
      for(typename SlotList::const_iterator i = slots.begin(); i != slots.end(); ++i)
      {
        ret = (*i)->proxy(p1,p2);
        if(ret)
          break;
      }
      return ret;
    }
};


#ifdef CXX_PARTIAL_SPECIALIZATION

//! Signal with 2 argument and void return-type
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <class _ParamType1, class _ParamType2, class _Mutex>
class Signal2<void, _ParamType1, _ParamType2, _Mutex>:
  public SignalBase<Slot2<void, _ParamType1, _ParamType2>, _Mutex>
{
  public:
    typedef SignalBase<
      Slot2<void, _ParamType1, _ParamType2>,
      _Mutex
    > SignalBase;

    //! Emit the signal
    void emit(_ParamType1 p1, _ParamType2 p2)
    {
      typedef typename SignalBase::SlotList SlotList;
      SlotList slots = slotList();
      for(typename SlotList::const_iterator i = slots.begin(); i != slots.end(); ++i)
        (*i)->proxy(p1,p2);
    }
};

#endif


//! Signal with 3 arguments and non-void return-type
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <
  class _RetT, class _ParamType1, class _ParamType2,
  class _ParamType3, class _Mutex = VoidMutex
>
class Signal3:
  public SignalBase<Slot3<_RetT, _ParamType1, _ParamType2, _ParamType3>, _Mutex>
{
  public:
    typedef _RetT RetType;

    typedef SignalBase<
      Slot3<_RetT, _ParamType1, _ParamType2, _ParamType3>,
      _Mutex
    > SignalBase;

    //! Emit the signal
    RetType emit(_ParamType1 p1, _ParamType2 p2, _ParamType3 p3)
    {
      typedef typename SignalBase::SlotList SlotList;
      RetType ret = RetType();
      SlotList slots = slotList();
      for(typename SlotList::const_iterator i = slots.begin(); i != slots.end(); ++i)
      {
        ret = (*i)->proxy(p1,p2,p3);
        if(ret)
          break;
      }
      return ret;
    }
};


#ifdef CXX_PARTIAL_SPECIALIZATION

//! Signal with 3 argument and void return-type
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <
  class _ParamType1, class _ParamType2,
  class _ParamType3, class _Mutex
>
class Signal3<void, _ParamType1, _ParamType2, _ParamType3, _Mutex>:
  public SignalBase<Slot3<void, _ParamType1, _ParamType2, _ParamType3>, _Mutex>
{
  public:
    typedef SignalBase<
      Slot3<void, _ParamType1, _ParamType2, _ParamType3>,
      _Mutex
    > SignalBase;

    //! Emit the signal
    void emit(_ParamType1 p1, _ParamType2 p2, _ParamType3 p3)
    {
      typedef typename SignalBase::SlotList SlotList;
      SlotList slots = slotList();
      for(typename SlotList::const_iterator i = slots.begin(); i != slots.end(); ++i)
        (*i)->proxy(p1,p2);
    }
};

#endif


//! Bind a slot to a signal
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <class _SignalT, class _SlotT>
void bind(_SignalT& sig, _SlotT slot)
{ sig.bind(slot); }

//! Unbind a slot from a signal
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <class _SignalT, class _SlotT>
void unbind(_SignalT& sig, _SlotT slot)
{ sig.unbind(slot); }

}

#endif
