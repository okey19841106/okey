/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _pdirectory_h_
#define _pdirectory_h_

#include <pclasses/pexport.h>
#include <pclasses/pexception.h>
#include <string>
#include <list>

namespace P {

//! Directory stream class
/*!
  This class can be used to enumerate the contents
  of a directory. It also provides some static methods
  to create or remove directories as well as for changing
  and retrieven the current directory.
  \todo check win32 behaviour of Directory-ctor
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PCORE_EXPORT Directory {
  public:
    //! Constructs a directory stream
    /*!
      Constructs a directory stream object for the given
      path. If the directory does not exist or is not
      readable a IOError will be thrown.
      \param path the path of the directory to enumerate
      \throw IOError
    */
    Directory(const char* path) throw(IOError);
    ~Directory() throw();

    //! Get the path of the directory stream
    inline const std::string& path() const throw()
    { return m_path; }

    //! Get next entry from directory stream
    const char* operator++() throw(IOError);

    //! Get current entry from directory stream
    const char* operator*() const throw();

    //! Rewind the directory stream to the beginning
    void rewind() throw();

    //! Create the given directory
    static void create(const char* path) throw(IOError);

    //! Remove (unlink) the given directory
    static void remove(const char* path) throw(IOError);

    //! Get the current working directory
    static std::string current() throw(IOError);

    //! Change the current working directory
    static void change(const char* path) throw(IOError);

    //! Returns the systems directory separator
    static std::string separator() throw();

    //! Returns path to the home directory
    static std::string homeDir() throw();

    //! Returns a list of drive letters
    static void getDriveList(std::list<std::string>& dl) throw();

  private:
    struct dir_handle_t;
    dir_handle_t* m_handle;
    std::string   m_path;
};

}

#endif
