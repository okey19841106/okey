/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2002  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _psqldriver_h_
#define _psqldriver_h_

#include <pclasses/ptypes.h>
#include <pclasses/pexport.h>
#include <pclasses/psqlerror.h>
#include <pclasses/psqlvalue.h>
#include <memory>
#include <string>

/*!
  \defgroup sql SQL Database library
*/

namespace P {

#ifdef HAVE_64BIT_INT
typedef uint64_t sqlcount_t;
#else
typedef uint32_t sqlcount_t;
#endif

//! SQL Driver base class
/*!
  \ingroup sql
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PSQL_EXPORT SQLDriver {
  public:
  
    //! SQL Driver result handle
    /*!
      \ingroup sql
      \author Christian Prochnow <cproch@seculogix.de>
    */
    class PSQL_EXPORT ResultHandle {
      public:
        ResultHandle();
        virtual ~ResultHandle();
        
        virtual unsigned int columnCount() const throw() = 0;
        virtual std::string columnName(unsigned int pos) const = 0;
        
        virtual bool fetch() = 0;
        
        virtual const SQLValue& value(const std::string& name) = 0;
        virtual const SQLValue& value(unsigned int pos) = 0;
    };
  
    //! SQL Driver statement handle
    /*!
      \ingroup sql
      \author Christian Prochnow <cproch@seculogix.de>
    */
    class PSQL_EXPORT StatementHandle {
      public:
        StatementHandle();
        virtual ~StatementHandle();
    
        virtual void prepare(const std::string& stmt) = 0;
        virtual void exec() = 0;

        virtual std::auto_ptr<ResultHandle> result() = 0;

        virtual sqlcount_t affectedRows() const throw() = 0;

        virtual std::string sqlstr(const SQLValue& val) const throw() = 0;
    };
        
    //! SQL Driver connection handle
    /*!
      \ingroup sql
      \author Christian Prochnow <cproch@seculogix.de>
    */
    class PSQL_EXPORT ConnectionHandle {
      public:
        enum state_t {
          Disconnected,
          Connected
        };
      
        ConnectionHandle();
        virtual ~ConnectionHandle();
        
        inline state_t state() const throw()
        { return m_state; }
        
        virtual std::auto_ptr<StatementHandle> createStmt() = 0;
        
        virtual void commit() = 0;
        virtual void rollback() = 0;
        
      protected:
        inline void setState(state_t st) throw()
        { m_state = st; }
        
      private:
        state_t m_state;
    };
  
    SQLDriver();
    virtual ~SQLDriver();
    
    virtual ConnectionHandle* connect(const std::string& user, const std::string& passwd, 
                                      const std::string& db, const std::string& host) throw(SQLError) = 0;
                                      
    virtual void close(ConnectionHandle* handle) throw() = 0;

};

}

#endif
