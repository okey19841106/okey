/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _pserverapp_h_
#define _pserverapp_h_

#include <pclasses/config.h>
#include <pclasses/pexport.h>
#include <pclasses/psimpleapp.h>
#include <pclasses/pexception.h>
#include <pclasses/plog.h>
#include <pclasses/pconfig.h>

namespace P {

//! Server (daemon) application base class
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PCORE_EXPORT ServerApp: public SimpleApp {
  public:
    ServerApp(const AboutData& about);
    ~ServerApp();
    
    //! Returns a reference to the logging object
    inline SystemLog& syslog() throw()
    { return *m_syslog; }
    
    //! Check for application system logging
    inline bool hasSyslog() const throw()
    { return m_syslog ? true : false; }
    
    //! Returns a reference to the config object
    inline Config& config() throw()
    { return *m_config; }
    
    //! Check for application config
    inline bool hasConfig() const throw()
    { return m_config ? true : false; }
    
    //! Reload application
    /*!
      Overfload this method for reloading your application's
      config data and for restart logging.
      Default implementation will reload the config and 
      restart the logging.
    */
    virtual void reload();

  protected:
    virtual int init(int argc, char* argv[]);
    
    //! Daemonize the process (go into background)
    void daemonize() throw(SystemError);
    
    //! Set the applications system logging object
    void setSyslog(SystemLog* log) throw();
    
    //! Set the applications config object
    void setConfig(Config* cfg) throw();
    
    static RETSIGTYPE SIGHUP_handler(int);
    
  private:
    ServerApp(const ServerApp&);
    ServerApp& operator=(const ServerApp&);

    SystemLog*  m_syslog;
    Config*     m_config;
};

}

#endif
