/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _pslot_h_
#define _pslot_h_

#include <pclasses/config.h>

namespace P {

//! Slot base-class with no arguments
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <class R>
class Slot0 {
  public:
    Slot0() {}
    virtual ~Slot0() {}
    virtual R proxy() = 0;
    virtual Slot0* clone() const = 0;
};

//! Function-slot with no arguments
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <class RetType>
class FuncSlot0: public Slot0<RetType> {
  public:
    typedef RetType (*Callback)();

    FuncSlot0(Callback cb)
    : _callback(cb) {}

    ~FuncSlot0() {}

    RetType proxy()
    { return _callback(); }

    Slot0<RetType>* clone() const
    { return new FuncSlot0(*this); }
    
    bool operator==(const FuncSlot0& slot) const
    { return (_callback == slot._callback); }
    
  private:
    Callback _callback;
};


//! Function-slot with no arguments and void return-type
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <>
class FuncSlot0<void>: public Slot0<void> {
  public:
    typedef void (*Callback)();

    FuncSlot0(Callback cb)
    : _callback(cb) {}

    ~FuncSlot0() {}

    void proxy()
    { _callback(); }

    Slot0<void>* clone() const
    { return new FuncSlot0(*this); }

    bool operator==(const FuncSlot0& slot) const
    { return (_callback == slot._callback); }

  private:
    Callback _callback;
};


//! Function-slot bind
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <class R>
FuncSlot0<R> slot(R (*func)(void))
{ return FuncSlot0<R>(func); }

//! Method-slot with no arguments
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <class RetType, class ObjType>
class MethodSlot0: public Slot0<RetType> {
  public:
    typedef RetType (ObjType::*Callback)();

    MethodSlot0(ObjType* obj, Callback cb)
    : _object(obj), _callback(cb) {}

    ~MethodSlot0() {}

    RetType proxy()
    { return (_object->*_callback)(); }

    Slot0<RetType>* clone() const
    { return new MethodSlot0(*this); }

    bool operator==(const MethodSlot0& slot) const
    { return (_object == slot._object && _callback == slot._callback); }
        
  private:
    ObjType* _object;
    Callback _callback;
};

#ifdef CXX_PARTIAL_SPECIALIZATION

//! Method-slot with no arguments and void return-type
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <class ObjType>
class MethodSlot0<void, ObjType>: public Slot0<void> {
  public:
    typedef void (ObjType::*Callback)();

    MethodSlot0(ObjType* obj, Callback cb)
    : _object(obj), _callback(cb) {}

    ~MethodSlot0() {}

    void proxy()
    { (_object->*_callback)(); }

    Slot0<void>* clone() const
    { return new MethodSlot0(*this); }

    bool operator==(const MethodSlot0& slot) const
    { return (_object == slot._object && _callback == slot._callback); }

  private:
    ObjType* _object;
    Callback _callback;
};

#endif

//! Method-slot bind
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <class R, class O>
MethodSlot0<R,O> slot(O* obj, R (O::*func)(void))
{ return MethodSlot0<R,O>(obj, func); }


//! Slot base-class with 1 argument
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <class R, class P1>
class Slot1 {
  public:
    Slot1() {}
    virtual ~Slot1() {}
    virtual R proxy(P1) = 0;
    virtual Slot1* clone() const = 0;
    
};

//! Function-slot with 1 argument
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <class RetType, class ParamType1>
class FuncSlot1: public Slot1<RetType, ParamType1> {
  public:
    typedef RetType (*Callback)(ParamType1);

    FuncSlot1(Callback cb)
    : _callback(cb) {}

    ~FuncSlot1() {}

    RetType proxy(ParamType1 p1)
    { return _callback(p1); }

    Slot1<RetType, ParamType1>* clone() const
    { return new FuncSlot1(*this); }

    bool operator==(const FuncSlot1& slot) const
    { return (_callback == slot._callback); }
        
  private:
    Callback _callback;
};

#ifdef CXX_PARTIAL_SPECIALIZATION

//! Function-slot with 1 argument and void return-type
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <class ParamType1>
class FuncSlot1<void, ParamType1>: public Slot1<void, ParamType1> {
  public:
    typedef void (*Callback)(ParamType1);

    FuncSlot1(Callback cb)
    : _callback(cb) {}

    ~FuncSlot1() {}

    void proxy(ParamType1 p1)
    { _callback(p1); }

    Slot1<void, ParamType1>* clone() const
    { return new FuncSlot1(*this); }
    
    bool operator==(const FuncSlot1& slot) const
    { return (_callback == slot._callback); }
  
  private:
    Callback _callback;
};

#endif

//! Function-slot bind
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <class R, class P1>
FuncSlot1<R,P1> slot(R (*func)(P1))
{ return FuncSlot1<R,P1>(func); }

//! Method-slot with 1 argument
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <class RetType, class ObjType, class ParamType1>
class MethodSlot1: public Slot1<RetType, ParamType1> {
  public:
    typedef RetType (ObjType::*Callback)(ParamType1);

    MethodSlot1(ObjType* obj, Callback cb)
    : _object(obj), _callback(cb) {}

    ~MethodSlot1() {}

    RetType proxy(ParamType1 p1)
    { return (_object->*_callback)(p1); }

    Slot1<RetType, ParamType1>* clone() const
    { return new MethodSlot1(*this); }
    
    bool operator==(const MethodSlot1& slot) const
    { return (_object == slot._object && _callback == slot._callback); }
    
  private:
    ObjType* _object;
    Callback _callback;
};

#ifdef CXX_PARTIAL_SPECIALIZATION

//! Method-slot with 1 argument and void return-type
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <class ObjType, class ParamType1>
class MethodSlot1<void, ObjType, ParamType1>: public Slot1<void, ParamType1> {
  public:
    typedef void (ObjType::*Callback)(ParamType1);

    MethodSlot1(ObjType* obj, Callback cb)
    : _object(obj), _callback(cb) {}

    ~MethodSlot1() {}

    void proxy(ParamType1 p1)
    { (_object->*_callback)(p1); }

    Slot1<void, ParamType1>* clone() const
    { return new MethodSlot1(*this); }

    bool operator==(const MethodSlot1& slot) const
    { return (_object == slot._object && _callback == slot._callback); }
        
  private:
    ObjType* _object;
    Callback _callback;
};

#endif

//! Method-slot bind
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <class R, class O, class P1>
MethodSlot1<R,O,P1> slot(O* obj, R (O::*func)(P1))
{ return MethodSlot1<R,O,P1>(obj, func); }


//! Slot base-class with 2 arguments
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <class R, class P1, class P2>
class Slot2 {
  public:
    Slot2() {}
    virtual ~Slot2() {}
    virtual R proxy(P1, P2) = 0;
    virtual Slot2* clone() const = 0;
};

//! Function-slot with 2 arguments
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <class RetType, class ParamType1, class ParamType2>
class FuncSlot2: public Slot2<RetType, ParamType1, ParamType2> {
  public:
    typedef RetType (*Callback)(ParamType1, ParamType2);

    FuncSlot2(Callback cb)
    : _callback(cb) {}

    ~FuncSlot2() {}

    RetType proxy(ParamType1 p1, ParamType2 p2)
    { return _callback(p1, p2); }

    FuncSlot2* clone() const
    { return new FuncSlot2(*this); }
    
    bool operator==(const FuncSlot2& slot) const
    { return (_callback == slot._callback); }
  
  private:
    Callback _callback;
};

#ifdef CXX_PARTIAL_SPECIALIZATION

//! Function-slot with 2 arguments and void return-type
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <class ParamType1, class ParamType2>
class FuncSlot2<void, ParamType1, ParamType2>: 
  public Slot2<void, ParamType1, ParamType2> 
{
  public:
    typedef void (*Callback)(ParamType1, ParamType2);

    FuncSlot2(Callback cb)
    : _callback(cb) {}

    ~FuncSlot2() {}

    void proxy(ParamType1 p1, ParamType2 p2)
    { _callback(p1, p2); }

    FuncSlot2* clone() const
    { return new FuncSlot2(*this); }
    
    bool operator==(const FuncSlot2& slot) const
    { return (_callback == slot._callback); }
  
  private:
    Callback _callback;
};

#endif

//! Function-slot bind
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <class R, class P1, class P2>
FuncSlot2<R,P1,P2> slot(R (*func)(P1, P2))
{ return FuncSlot2<R,P1,P2>(func); }

//! Method-slot with 2 arguments
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <class RetType, class ObjType, class ParamType1, class ParamType2>
class MethodSlot2: public Slot2<RetType, ParamType1, ParamType2> {
  public:
    typedef RetType (ObjType::*Callback)(ParamType1, ParamType2);

    MethodSlot2(ObjType* obj, Callback cb)
    : _object(obj), _callback(cb) {}

    ~MethodSlot2() {}

    RetType proxy(ParamType1 p1, ParamType2 p2)
    { return (_object->*_callback)(p1, p2); }

    MethodSlot2* clone() const
    { return new MethodSlot2(*this); }

    bool operator==(const MethodSlot2& slot) const
    { return (_object == slot._object && _callback == slot._callback); }
        
  private:
    ObjType* _object;
    Callback _callback;
};

#ifdef CXX_PARTIAL_SPECIALIZATION

//! Method-slot with 2 arguments and void return-type
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <class ObjType, class ParamType1, class ParamType2>
class MethodSlot2<void, ObjType, ParamType1, ParamType2>: 
  public Slot2<void, ParamType1, ParamType2> 
{
  public:
    typedef void (ObjType::*Callback)(ParamType1, ParamType2);

    MethodSlot2(ObjType* obj, Callback cb)
    : _object(obj), _callback(cb) {}

    ~MethodSlot2() {}

    void proxy(ParamType1 p1, ParamType2 p2)
    { (_object->*_callback)(p1, p2); }

    MethodSlot2* clone() const
    { return new MethodSlot2(*this); }
    
    bool operator==(const MethodSlot2& slot) const
    { return (_object == slot._object && _callback == slot._callback); }
  
  private:
    ObjType* _object;
    Callback _callback;
};

#endif

//! Method-slot bind
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <class R, class O, class P1, class P2>
MethodSlot2<R,O,P1,P2> slot(O* obj, R (O::*func)(P1,P2))
{ return MethodSlot2<R,O,P1,P2>(obj, func); }


//! Slot base-class with 3 arguments
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <class R, class P1, class P2, class P3>
class Slot3 {
  public:
    Slot3() {}
    virtual ~Slot3() {}
    virtual R proxy(P1, P2, P3) = 0;
    virtual Slot3* clone() const = 0;
};

//! Function-slot with 3 arguments
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <class RetType, class ParamType1, class ParamType2, class ParamType3>
class FuncSlot3: public Slot3<RetType, ParamType1, ParamType2, ParamType3> {
  public:
    typedef RetType (*Callback)(ParamType1, ParamType2, ParamType3);

    FuncSlot3(Callback cb)
    : _callback(cb) {}

    ~FuncSlot3() {}

    RetType proxy(ParamType1 p1, ParamType2 p2, ParamType3 p3)
    { return _callback(p1, p2, p3); }

    FuncSlot3* clone() const
    { return new FuncSlot3(*this); }
    
    bool operator==(const FuncSlot3& slot) const
    { return (_callback == slot._callback); }
  
  private:
    Callback _callback;
};

#ifdef CXX_PARTIAL_SPECIALIZATION

//! Function-slot with 3 arguments and void return-type
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <class ParamType1, class ParamType2, class ParamType3>
class FuncSlot3<void, ParamType1, ParamType2, ParamType3>: 
  public Slot3<void, ParamType1, ParamType2, ParamType3> 
{
  public:
    typedef void (*Callback)(ParamType1, ParamType2, ParamType3);

    FuncSlot3(Callback cb)
    : _callback(cb) {}

    ~FuncSlot3() {}

    void proxy(ParamType1 p1, ParamType2 p2, ParamType3 p3)
    { _callback(p1, p2); }

    FuncSlot3* clone() const
    { return new FuncSlot3(*this); }
    
    bool operator==(const FuncSlot3& slot) const
    { return (_callback == slot._callback); }
  
  private:
    Callback _callback;
};

#endif

//! Function-slot bind
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <class R, class P1, class P2, class P3>
FuncSlot3<R,P1,P2,P3> slot(R (*func)(P1, P2, P3))
{ return FuncSlot3<R,P1,P2,P3>(func); }

//! Method-slot with 3 arguments
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <class RetType, class ObjType, class ParamType1, class ParamType2, class ParamType3>
class MethodSlot3: public Slot3<RetType, ParamType1, ParamType2, ParamType3> {
  public:
    typedef RetType (ObjType::*Callback)(ParamType1, ParamType2, ParamType3);

    MethodSlot3(ObjType* obj, Callback cb)
    : _object(obj), _callback(cb) {}

    ~MethodSlot3() {}

    RetType proxy(ParamType1 p1, ParamType2 p2, ParamType3 p3)
    { return (_object->*_callback)(p1, p2, p3); }

    MethodSlot3* clone() const
    { return new MethodSlot3(*this); }

    bool operator==(const MethodSlot3& slot) const
    { return (_object == slot._object && _callback == slot._callback); }
        
  private:
    ObjType* _object;
    Callback _callback;
};

#ifdef CXX_PARTIAL_SPECIALIZATION

//! Method-slot with 3 arguments and void return-type
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <class ObjType, class ParamType1, class ParamType2, class ParamType3>
class MethodSlot3<void, ObjType, ParamType1, ParamType2, ParamType3>: 
  public Slot3<void, ParamType1, ParamType2, ParamType3> 
{
  public:
    typedef void (ObjType::*Callback)(ParamType1, ParamType2, ParamType3);

    MethodSlot3(ObjType* obj, Callback cb)
    : _object(obj), _callback(cb) {}

    ~MethodSlot3() {}

    void proxy(ParamType1 p1, ParamType2 p2, ParamType3 p3)
    { (_object->*_callback)(p1, p2, p3); }

    MethodSlot3* clone() const
    { return new MethodSlot3(*this); }
    
    bool operator==(const MethodSlot3& slot) const
    { return (_object == slot._object && _callback == slot._callback); }
  
  private:
    ObjType* _object;
    Callback _callback;
};

#endif

//! Method-slot bind
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
template <class R, class O, class P1, class P2, class P3>
MethodSlot3<R,O,P1,P2,P3> slot(O* obj, R (O::*func)(P1,P2,P3))
{ return MethodSlot3<R,O,P1,P2,P3>(obj, func); }


}

#endif
