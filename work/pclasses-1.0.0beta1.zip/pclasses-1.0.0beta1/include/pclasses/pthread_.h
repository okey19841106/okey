/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _pthread_h_
#define _pthread_h_

#include <pclasses/pexport.h>
#include <pclasses/pexception.h>
#include <pclasses/psemaphore.h>

namespace P {

//! Threading error exception class
/*!
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
class ThreadError: public SystemError {
  public:
    inline ThreadError(oserr_t errnum, const char* _what, const SourceInfo& _si) throw()
      : SystemError(errnum, _what, _si) {}

    inline BaseError* clone() const
    { return new ThreadError(*this); }

};

//! Thread base class
/*!
  \todo Thread::setPriority()
  \ingroup core
  \author Christian Prochnow <cproch@seculogix.de>
*/
class PCORE_EXPORT Thread {
  public:
    //! Thread state
    enum state_t {
      Stopped,    /*!< Thread is in stopped state */
      Running,    /*!< Thread is in running state */
      Suspended   /*!< Thread is in suspended state */
    };

    Thread() throw();
    virtual ~Thread();

    //! Start thread
    void start(Semaphore* sem = 0, int prio = 0) throw(LogicError, ThreadError);

    //! Stop thread
    bool stop(unsigned int timeout) throw(LogicError, SyncError);

    //! Kill the thread
    void kill() throw(LogicError, SystemError);

    //! Suspend threads execution
    bool suspend(unsigned int timeout) throw(LogicError, SyncError);

    //! Resume threads execution
    void resume() throw(LogicError, SyncError);

    //! Returns the state of the thread
    state_t state() const throw();

    //! Give up calling threads CPU time
    static void yield() throw();

    //! Delay execution of calling thread
    /*!
      Delays the execution of the calling thread by the
      given amount of milliseconds.
      \param timeout amount of milliseconds how long the thread
             should be suspended.
    */
    static void sleep(unsigned int timeout) throw();

    //! Terminate calling thread
    static void exit() throw();

    //! Returns a pointer to the current thread
    static Thread* current() throw();

  protected:
    virtual bool initial() = 0;
    virtual void main() = 0;
    virtual void suspended() {};
    virtual void resumed() {};
    virtual void final() {};

    bool testCancel() throw(LogicError, SyncError);

    class Private;
    friend class Private;

    struct thread_handle_t;
    friend struct thread_handle_t;

    thread_handle_t* handle() const throw();

    static thread_handle_t* createHandle();
    static void destroyHandle(thread_handle_t* handle);

  private:
    thread_handle_t* m_handle;
};

}

#endif
