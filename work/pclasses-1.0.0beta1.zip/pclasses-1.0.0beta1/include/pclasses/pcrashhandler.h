/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _pcrashhandler_h_
#define _pcrashhandler_h_

#include <pclasses/config.h>
#include <pclasses/pexport.h>

namespace P {

//! Crash handling class
/*!
  This class provides custom crash-handlers which will
  be installed by the library, when a program is linked
  against the P::Classes library.
  \author Christian Prochnow <cproch@seculogix.de>
  \ingroup core
*/
class PCORE_EXPORT CrashHandler {
  public:
    //! Terminate handler
    /*!
      The terminate handler will be called when an uncatched
      exception has been thrown. Depending on settings a backtrace
      will be dumped on exit.
    */
    static void terminate() throw();

    //! Unexpected exception handler
    /*!
      The unexpected handler will be called when an unexpected
      exception has been thrown. Depending on settings a backtrace
      will be dumped on exit.
    */
    static void unexpected() throw();

    //! SEGV handler
    /*!
      The SEGV handler will be called when the program receives a
      Segmentation fault. Depending on settings a backtrace will
      be dumped on exit. The crash dump is placed into the temp-
      directory.
    */
    static RETSIGTYPE SEGV_handler(int) throw();

    //! Enables dump of crash informations
    /*!
      Enables dumping of crash informations into a file.
      Default values if compiled for debugging is true,
      otherwise false.
    */
    static void enableDebugDump() throw();

    //! Disables dump of crash informations
    /*!
      Disables dumping of crash informations into a file.
    */
    static void disableDebugDump() throw();

    //! Test if dump of crash infos is enabled
    static bool isDebugDumpEnabled() throw();

  private:
    static bool m_enableDebug;

};

}

#endif
