/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/pthread_.h"
#include "pclasses/psemaphore.h"
#include "tests.h"
#include <iostream>

using namespace std;
using namespace P;

P_TEST_VARS();

class TestThread: public Thread {
  public:
    TestThread()
    { testValue = 0; }

    ~TestThread()
    {}

    int testValue;

  protected:
    virtual bool initial()
    { return true; }

    virtual void main()
    {
      while(!testCancel())
      {
        testValue = 0;
        yield();
      }
    }

    virtual void final()
    { }

};

int main(int argc, char* argv[])
{
  Semaphore* sem = 0;
  TestThread t;

  P_TEST("Create semaphore ... ", sem = new Semaphore(), true);

  P_TEST("Start thread ... ", t.start(sem), true);
  P_TEST("Wait for thread ... ", sem->wait(), t.state() == Thread::Running);

  P_TEST("Suspend thread ... ", t.suspend(1000), t.state() == Thread::Suspended);
  t.testValue = 1;

  P_TEST("testValue should be 1 after sleep ... ", Thread::sleep(1000), t.testValue == 1);

  P_TEST("Resume thread ... ", t.resume(), true);

  P_TEST("testValue should be 0 after sleep ... ", Thread::sleep(1000), t.testValue == 0);

  P_TEST("Stop thread ... ", t.stop(1000), t.state() == Thread::Stopped);

  P_TEST("Start thread again ... ", t.start(sem), true);
  P_TEST("Wait for thread ... ", sem->wait(), t.state() == Thread::Running);

  P_TEST("Kill thread ... ", t.kill(), t.state() == Thread::Stopped);

  P_TEST("Delete semaphore ... ", delete sem, true);

  P_TEST_EXIT();
}
