/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/pprocess.h"
#include "pclasses/pdirectory.h"
#include "tests.h"
#include <iostream>

using namespace std;
using namespace P;

P_TEST_VARS();

int main(int argc, char* argv[])
{
  Process* proc = 0;
  char buffer[4096];

  P_TEST("Creating process object ... ", proc = new Process(string(Directory::current() + "/process_slave").c_str()), proc->state() == Process::Stopped);

  P_TEST("Starting process ... ", proc->start(Process::AllOutput), proc->state() == Process::Running);

  size_t ret = 0;

  P_TEST("Read 2 bytes from slave stdout ... ", ret = proc->processIO()->read(buffer, 2), ret==2);

  P_TEST("Next read should return 0 ... ", ret = proc->processIO()->read(buffer, 2), ret==0);

  P_TEST("Read 2 bytes from slave stderr ... ", ret = proc->processIO()->readErr(buffer, 2), ret==2);

  P_TEST("Next read should return 0 ... ", ret = proc->processIO()->readErr(buffer, 2), ret==0);

  int exitCode = 0;

  P_TEST("Wait for slave to exit ... ", exitCode = proc->wait(), (exitCode==23 && proc->state() == Process::Stopped));

  proc->addArg("test2");

  P_TEST("Starting process (test2) ... ", proc->start(Process::AllOutput), proc->state() == Process::Running);

  P_TEST("Send SIGTERM to process ... ", proc->stop(), proc->state() == Process::Stopping);

  P_TEST("Trying wait for process ... ", while(!proc->tryWait(exitCode)), (exitCode==127 && proc->state() == Process::Stopped));

  P_TEST("Delete process object ... ", delete proc, true);

  P_TEST_EXIT();
}
