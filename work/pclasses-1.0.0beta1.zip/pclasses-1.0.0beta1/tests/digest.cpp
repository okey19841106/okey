/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/psha1.h"
#include "pclasses/pmd4.h"
#include "pclasses/pmd5.h"
#include "pclasses/pfile.h"
#include "tests.h"
#include <iostream>

using namespace std;
using namespace P;

P_TEST_VARS();

int test_digest(Digest* dig, const string& sum)
{
  File* f = 0;

  P_TEST("Open digest-test.txt ...", f = new File("digest-test.txt", File::Read, File::Normal, File::OpenExisting), f);

  P_TEST("Read file and update digest ...",
  {
    size_t ret = 0;
    char buffer[64000];
    do
    {
      ret = f->read(buffer, sizeof(buffer));
      dig->update(buffer, ret);
    } while(ret > 0);
  }, true);

  P_TEST("Test if sum is correct ... ", string mysum = dig->digest(); cout << mysum << " ", mysum == sum);

  P_TEST("Seek to begin of file ... ", f->seek(0,File::seekSet), true);
  P_TEST("Clear digest ... ", dig->clear(), true)

  P_TEST("Read file and update digest ...",
  {
    size_t ret = 0;
    char buffer[64000];
    do
    {
      ret = f->read(buffer, sizeof(buffer));
      dig->update(buffer, ret);
    } while(ret > 0);
  }, true);

  P_TEST("Test if sum is correct ... ", string mysum = dig->digest(); cout << mysum << " ";, mysum == sum);

  P_TEST("Close and delete file object ... ", delete f, true);

  return 0;
}

int main(int argc, char* argv[])
{
  MD4Digest md4dig;

  cout << "Testing MD4Digest ..." << endl;
  test_digest(&md4dig, "need md4 digest for test-file!!");

  MD5Digest md5dig;

  cout << "Testing MD5Digest ..." << endl;
  test_digest(&md5dig, "9beed5d24240c5e85f205d7d5db99080");

  SHA1Digest sha1dig;

  cout << "Testing SHA1Digest ..." << endl;
  test_digest(&sha1dig, "b1c92c85a2ff636eafdea89e0896f153121026a8");

  P_TEST_EXIT();
}
