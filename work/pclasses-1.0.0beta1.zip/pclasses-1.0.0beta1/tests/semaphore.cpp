/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/pthread_.h"
#include "pclasses/psemaphore.h"
#include "pclasses/pprocess.h"
#include "tests.h"
#include <iostream>

using namespace std;
using namespace P;

P_TEST_VARS();

void test_semaphore(Semaphore* sem)
{
  P_TEST("Post semaphore ... ", sem->post(), true);
  P_TEST("TryWait semaphore ... ", bool tryWait = sem->tryWait(), tryWait==true);

  P_TEST("Post semaphore ... ", sem->post(), true);
  P_TEST("Wait semaphore ... ", sem->wait(), true);

  P_TEST("Delete semaphore ... ", delete sem, true);
}

void semaphore_master(Semaphore* sem)
{
  P_TEST("Waiting for semaphore (master) ... ", sem->wait(), true);
}

void semaphore_slave(Semaphore* sem)
{
  P_TEST("Post semaphore (slave) ... ", sem->post(), true);
}

int main(int argc, char* argv[])
{
  Semaphore* sem = 0;

  if(argc > 1)
  {
    if(strcmp(argv[1], "client")==0)
    {
      P_TEST("Create named semaphore (slave) ... ", sem = new Semaphore("testsem"), true);
      semaphore_slave(sem);
      return 0;
    }
  }

  P_TEST("Create unnamed semaphore ... ", sem = new Semaphore(), true);
  test_semaphore(sem);
  sem = 0;

  P_TEST("Create named semaphore ... ", sem = new Semaphore("testsem"), true);
  if(!sem)
  {
    cout << "Further named semaphore tests skipped." << endl;
    P_TEST_EXIT();
  }

  test_semaphore(sem);

  list<string> args;
  args.push_back("client");

  Process* proc = 0;
  P_TEST("Create child process ... ", proc = new Process(argv[0], args), true);

  P_TEST("Start child process ... ", proc->start(), proc->state() == Process::Running);

  semaphore_master(sem);

  proc->wait();
  delete proc;

  return 0;
}
