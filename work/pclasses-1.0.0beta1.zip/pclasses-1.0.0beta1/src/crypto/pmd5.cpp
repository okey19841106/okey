/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

/*
 * Cryptographic API.
 *
 * MD5 Message Digest Algorithm (RFC1321).
 *
 * Derived from cryptoapi implementation, originally based on the
 * public domain implementation written by Colin Plumb in 1993.
 *
 * Copyright (c) Cryptoapi developers.
 * Copyright (c) 2002 James Morris <jmorris@intercode.com.au>
 *
 * Modified by Christian Prochnow to fit into the P::Classes portable
 * application framework.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 *
 */

#include "pclasses/pmd5.h"
#include "pclasses/pbyteorder.h"

#include <string.h>
#include <iomanip>
#include <sstream>

namespace P {

using namespace std;

static inline void le32_to_cpu_array(uint32_t *buf, unsigned int words)
{
  while (words--)
  {
    *buf = le_to_cpu(*buf);
    buf++;
  }
}

static inline void cpu_to_le32_array(uint32_t *buf, unsigned int words)
{
  while (words--)
  {
    *buf = cpu_to_le(*buf);
    buf++;
  }
}

#define F1(x, y, z)     (z ^ (x & (y ^ z)))
#define F2(x, y, z)     F1(z, x, y)
#define F3(x, y, z)     (x ^ y ^ z)
#define F4(x, y, z)     (y ^ (x | ~z))

#define MD5STEP(f, w, x, y, z, in, s) \
        (w += f(x, y, z) + in, w = (w<<s | w>>(32-s)) + x)

MD5Digest::MD5Digest()
{
  init();
}

MD5Digest::MD5Digest(const MD5Digest& dig)
{
  *this = dig;
}

MD5Digest::~MD5Digest()
{
}

void MD5Digest::clear()
{
  init();
}

MD5Digest& MD5Digest::operator=(const MD5Digest& dig)
{
  unsigned int i;

  m_byteCount = dig.m_byteCount;

  for(i=0; i < HASH_WORDS; i++)
    m_hash[i] = dig.m_hash[i];

  for(i=0; i < BLOCK_WORDS; i++)
    m_block[i] = dig.m_block[i];

  return *this;
}

void MD5Digest::init()
{
  m_byteCount = 0;
  m_hash[0] = 0x67452301;
  m_hash[1] = 0xefcdab89;
  m_hash[2] = 0x98badcfe;
  m_hash[3] = 0x10325476;
}

void MD5Digest::transform(const uint32_t* in)
{
  uint32_t a = m_hash[0];
  uint32_t b = m_hash[1];
  uint32_t c = m_hash[2];
  uint32_t d = m_hash[3];

  MD5STEP(F1, a, b, c, d, in[0] + 0xd76aa478, 7);
  MD5STEP(F1, d, a, b, c, in[1] + 0xe8c7b756, 12);
  MD5STEP(F1, c, d, a, b, in[2] + 0x242070db, 17);
  MD5STEP(F1, b, c, d, a, in[3] + 0xc1bdceee, 22);
  MD5STEP(F1, a, b, c, d, in[4] + 0xf57c0faf, 7);
  MD5STEP(F1, d, a, b, c, in[5] + 0x4787c62a, 12);
  MD5STEP(F1, c, d, a, b, in[6] + 0xa8304613, 17);
  MD5STEP(F1, b, c, d, a, in[7] + 0xfd469501, 22);
  MD5STEP(F1, a, b, c, d, in[8] + 0x698098d8, 7);
  MD5STEP(F1, d, a, b, c, in[9] + 0x8b44f7af, 12);
  MD5STEP(F1, c, d, a, b, in[10] + 0xffff5bb1, 17);
  MD5STEP(F1, b, c, d, a, in[11] + 0x895cd7be, 22);
  MD5STEP(F1, a, b, c, d, in[12] + 0x6b901122, 7);
  MD5STEP(F1, d, a, b, c, in[13] + 0xfd987193, 12);
  MD5STEP(F1, c, d, a, b, in[14] + 0xa679438e, 17);
  MD5STEP(F1, b, c, d, a, in[15] + 0x49b40821, 22);

  MD5STEP(F2, a, b, c, d, in[1] + 0xf61e2562, 5);
  MD5STEP(F2, d, a, b, c, in[6] + 0xc040b340, 9);
  MD5STEP(F2, c, d, a, b, in[11] + 0x265e5a51, 14);
  MD5STEP(F2, b, c, d, a, in[0] + 0xe9b6c7aa, 20);
  MD5STEP(F2, a, b, c, d, in[5] + 0xd62f105d, 5);
  MD5STEP(F2, d, a, b, c, in[10] + 0x02441453, 9);
  MD5STEP(F2, c, d, a, b, in[15] + 0xd8a1e681, 14);
  MD5STEP(F2, b, c, d, a, in[4] + 0xe7d3fbc8, 20);
  MD5STEP(F2, a, b, c, d, in[9] + 0x21e1cde6, 5);
  MD5STEP(F2, d, a, b, c, in[14] + 0xc33707d6, 9);
  MD5STEP(F2, c, d, a, b, in[3] + 0xf4d50d87, 14);
  MD5STEP(F2, b, c, d, a, in[8] + 0x455a14ed, 20);
  MD5STEP(F2, a, b, c, d, in[13] + 0xa9e3e905, 5);
  MD5STEP(F2, d, a, b, c, in[2] + 0xfcefa3f8, 9);
  MD5STEP(F2, c, d, a, b, in[7] + 0x676f02d9, 14);
  MD5STEP(F2, b, c, d, a, in[12] + 0x8d2a4c8a, 20);

  MD5STEP(F3, a, b, c, d, in[5] + 0xfffa3942, 4);
  MD5STEP(F3, d, a, b, c, in[8] + 0x8771f681, 11);
  MD5STEP(F3, c, d, a, b, in[11] + 0x6d9d6122, 16);
  MD5STEP(F3, b, c, d, a, in[14] + 0xfde5380c, 23);
  MD5STEP(F3, a, b, c, d, in[1] + 0xa4beea44, 4);
  MD5STEP(F3, d, a, b, c, in[4] + 0x4bdecfa9, 11);
  MD5STEP(F3, c, d, a, b, in[7] + 0xf6bb4b60, 16);
  MD5STEP(F3, b, c, d, a, in[10] + 0xbebfbc70, 23);
  MD5STEP(F3, a, b, c, d, in[13] + 0x289b7ec6, 4);
  MD5STEP(F3, d, a, b, c, in[0] + 0xeaa127fa, 11);
  MD5STEP(F3, c, d, a, b, in[3] + 0xd4ef3085, 16);
  MD5STEP(F3, b, c, d, a, in[6] + 0x04881d05, 23);
  MD5STEP(F3, a, b, c, d, in[9] + 0xd9d4d039, 4);
  MD5STEP(F3, d, a, b, c, in[12] + 0xe6db99e5, 11);
  MD5STEP(F3, c, d, a, b, in[15] + 0x1fa27cf8, 16);
  MD5STEP(F3, b, c, d, a, in[2] + 0xc4ac5665, 23);

  MD5STEP(F4, a, b, c, d, in[0] + 0xf4292244, 6);
  MD5STEP(F4, d, a, b, c, in[7] + 0x432aff97, 10);
  MD5STEP(F4, c, d, a, b, in[14] + 0xab9423a7, 15);
  MD5STEP(F4, b, c, d, a, in[5] + 0xfc93a039, 21);
  MD5STEP(F4, a, b, c, d, in[12] + 0x655b59c3, 6);
  MD5STEP(F4, d, a, b, c, in[3] + 0x8f0ccc92, 10);
  MD5STEP(F4, c, d, a, b, in[10] + 0xffeff47d, 15);
  MD5STEP(F4, b, c, d, a, in[1] + 0x85845dd1, 21);
  MD5STEP(F4, a, b, c, d, in[8] + 0x6fa87e4f, 6);
  MD5STEP(F4, d, a, b, c, in[15] + 0xfe2ce6e0, 10);
  MD5STEP(F4, c, d, a, b, in[6] + 0xa3014314, 15);
  MD5STEP(F4, b, c, d, a, in[13] + 0x4e0811a1, 21);
  MD5STEP(F4, a, b, c, d, in[4] + 0xf7537e82, 6);
  MD5STEP(F4, d, a, b, c, in[11] + 0xbd3af235, 10);
  MD5STEP(F4, c, d, a, b, in[2] + 0x2ad7d2bb, 15);
  MD5STEP(F4, b, c, d, a, in[9] + 0xeb86d391, 21);

  m_hash[0] += a;
  m_hash[1] += b;
  m_hash[2] += c;
  m_hash[3] += d;
}

void MD5Digest::update(const char* data, size_t len)
{
  const uint32_t avail = BLOCK_SIZE - (m_byteCount & 0x3f);

  m_byteCount += len;

  if(avail > len)
  {
    memcpy((char *)m_block + (BLOCK_SIZE - avail), data, len);
    return;
  }

  memcpy((char *)m_block + (BLOCK_SIZE - avail), data, avail);

  le32_to_cpu_array(m_block, BLOCK_WORDS);
  transform(m_block);

  data += avail;
  len -= avail;

  while(len >= BLOCK_SIZE)
  {
    memcpy(m_block, data, BLOCK_SIZE);
    le32_to_cpu_array(m_block, BLOCK_WORDS);
    transform(m_block);
    data += BLOCK_SIZE;
    len  -= BLOCK_SIZE;
  }

  memcpy(m_block, data, len);
}

string MD5Digest::digest() const
{
  MD5Digest work(*this);

  unsigned int i = 0;
  const unsigned int offset = work.m_byteCount & 0x3f;
  char* p = (char *)work.m_block + offset;
  int padding = 56 - (offset + 1);

  *p++ = 0x80;
  if(padding < 0)
  {
    memset(p, 0x00, padding + sizeof(uint64_t));
    le32_to_cpu_array(work.m_block, BLOCK_WORDS);
    work.transform(work.m_block);
    p = (char *)work.m_block;
    padding = 56;
  }

  memset(p, 0, padding);
  work.m_block[14] = work.m_byteCount << 3;
  work.m_block[15] = work.m_byteCount >> 29;
  le32_to_cpu_array(work.m_block, (BLOCK_SIZE - sizeof(uint64_t)) / sizeof(uint32_t));

  work.transform(work.m_block);
  cpu_to_le32_array(work.m_hash, HASH_WORDS * sizeof(uint32_t));

  ostringstream os;
  os << setfill('0');
  os << hex;

  p = (char*)work.m_hash;

  for(i = 0; i < DIGEST_SIZE; i++)
  {
    uint8_t ch = *p++;
    os << setw(2) << (int)ch;
  }

  return os.str();
}

}
