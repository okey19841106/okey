/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

/*
 * Cryptographic API.
 *
 * MD4 Message Digest Algorithm (RFC1320).
 *
 * Implementation derived from Andrew Tridgell and Steve French's
 * CIFS MD4 implementation, and the cryptoapi implementation
 * originally based on the public domain implementation written
 * by Colin Plumb in 1993.
 *
 * Copyright (c) Andrew Tridgell 1997-1998.
 * Modified by Steve French (sfrench@us.ibm.com) 2002
 * Copyright (c) Cryptoapi developers.
 * Copyright (c) 2002 David S. Miller (davem@redhat.com)
 * Copyright (c) 2002 James Morris <jmorris@intercode.com.au>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 */

#include "pclasses/pmd4.h"
#include "pclasses/pbyteorder.h"

#include <string.h>
#include <iomanip>
#include <sstream>

namespace P {

using namespace std;

static inline void le32_to_cpu_array(uint32_t *buf, unsigned int words)
{
  while (words--)
  {
    *buf = le_to_cpu(*buf);
    buf++;
  }
}

static inline void cpu_to_le32_array(uint32_t *buf, unsigned int words)
{
  while (words--)
  {
    *buf = cpu_to_le(*buf);
    buf++;
  }
}

static inline uint32_t lshift(uint32_t x, unsigned int s)
{
  x &= 0xffffffff;
  return ((x << s) & 0xffffffff) | (x >> (32 - s));
}

static inline uint32_t F(uint32_t x, uint32_t y, uint32_t z)
{
  return (x & y) | ((~x) & z);
}

static inline uint32_t G(uint32_t x, uint32_t y, uint32_t z)
{
  return (x & y) | (x & z) | (y & z);
}

static inline uint32_t H(uint32_t x, uint32_t y, uint32_t z)
{
  return x ^ y ^ z;
}

#define ROUND1(a,b,c,d,k,s) (a = lshift(a + F(b,c,d) + k, s))
#define ROUND2(a,b,c,d,k,s) (a = lshift(a + G(b,c,d) + k + (uint32_t)0x5A827999,s))
#define ROUND3(a,b,c,d,k,s) (a = lshift(a + H(b,c,d) + k + (uint32_t)0x6ED9EBA1,s))


MD4Digest::MD4Digest()
{
  init();
}

MD4Digest::MD4Digest(const MD4Digest& dig)
{
  *this = dig;
}

MD4Digest::~MD4Digest()
{
}

void MD4Digest::clear()
{
  init();
}

MD4Digest& MD4Digest::operator=(const MD4Digest& dig)
{
  unsigned int i;

  m_byteCount = dig.m_byteCount;

  for(i=0; i < HASH_WORDS; i++)
    m_hash[i] = dig.m_hash[i];

  for(i=0; i < BLOCK_WORDS; i++)
    m_block[i] = dig.m_block[i];

  return *this;
}

void MD4Digest::init()
{
  m_byteCount = 0;
  m_hash[0] = 0x67452301;
  m_hash[1] = 0xefcdab89;
  m_hash[2] = 0x98badcfe;
  m_hash[3] = 0x10325476;
}

void MD4Digest::transform(const uint32_t* in)
{
  uint32_t a = m_hash[0];
  uint32_t b = m_hash[1];
  uint32_t c = m_hash[2];
  uint32_t d = m_hash[3];

  ROUND1(a, b, c, d, in[0], 3);
  ROUND1(d, a, b, c, in[1], 7);
  ROUND1(c, d, a, b, in[2], 11);
  ROUND1(b, c, d, a, in[3], 19);
  ROUND1(a, b, c, d, in[4], 3);
  ROUND1(d, a, b, c, in[5], 7);
  ROUND1(c, d, a, b, in[6], 11);
  ROUND1(b, c, d, a, in[7], 19);
  ROUND1(a, b, c, d, in[8], 3);
  ROUND1(d, a, b, c, in[9], 7);
  ROUND1(c, d, a, b, in[10], 11);
  ROUND1(b, c, d, a, in[11], 19);
  ROUND1(a, b, c, d, in[12], 3);
  ROUND1(d, a, b, c, in[13], 7);
  ROUND1(c, d, a, b, in[14], 11);
  ROUND1(b, c, d, a, in[15], 19);

  ROUND2(a, b, c, d, in[0], 3);
  ROUND2(d, a, b, c, in[4], 5);
  ROUND2(c, d, a, b, in[8], 9);
  ROUND2(b, c, d, a, in[12], 13);
  ROUND2(a, b, c, d, in[1], 3);
  ROUND2(d, a, b, c, in[5], 5);
  ROUND2(c, d, a, b, in[9], 9);
  ROUND2(b, c, d, a, in[13], 13);
  ROUND2(a, b, c, d, in[2], 3);
  ROUND2(d, a, b, c, in[6], 5);
  ROUND2(c, d, a, b, in[10], 9);
  ROUND2(b, c, d, a, in[14], 13);
  ROUND2(a, b, c, d, in[3], 3);
  ROUND2(d, a, b, c, in[7], 5);
  ROUND2(c, d, a, b, in[11], 9);
  ROUND2(b, c, d, a, in[15], 13);

  ROUND3(a, b, c, d,in[ 0], 3);
  ROUND3(d, a, b, c, in[8], 9);
  ROUND3(c, d, a, b, in[4], 11);
  ROUND3(b, c, d, a, in[12], 15);
  ROUND3(a, b, c, d, in[2], 3);
  ROUND3(d, a, b, c, in[10], 9);
  ROUND3(c, d, a, b, in[6], 11);
  ROUND3(b, c, d, a, in[14], 15);
  ROUND3(a, b, c, d, in[1], 3);
  ROUND3(d, a, b, c, in[9], 9);
  ROUND3(c, d, a, b, in[5], 11);
  ROUND3(b, c, d, a, in[13], 15);
  ROUND3(a, b, c, d, in[3], 3);
  ROUND3(d, a, b, c, in[11], 9);
  ROUND3(c, d, a, b, in[7], 11);
  ROUND3(b, c, d, a, in[15], 15);

  m_hash[0] += a;
  m_hash[1] += b;
  m_hash[2] += c;
  m_hash[3] += d;
}

void MD4Digest::update(const char* data, size_t len)
{
  const uint32_t avail = BLOCK_SIZE - (m_byteCount & 0x3f);

  m_byteCount += len;

  if(avail > len)
  {
    memcpy((char *)m_block + (BLOCK_SIZE - avail), data, len);
    return;
  }

  memcpy((char *)m_block + (BLOCK_SIZE - avail), data, avail);

  le32_to_cpu_array(m_block, BLOCK_WORDS);
  transform(m_block);

  data += avail;
  len -= avail;

  while(len >= BLOCK_SIZE)
  {
    memcpy(m_block, data, BLOCK_SIZE);
    le32_to_cpu_array(m_block, BLOCK_WORDS);
    transform(m_block);
    data += BLOCK_SIZE;
    len  -= BLOCK_SIZE;
  }

  memcpy(m_block, data, len);
}

string MD4Digest::digest() const
{
  MD4Digest work(*this);

  unsigned int i = 0;
  const unsigned int offset = work.m_byteCount & 0x3f;
  char* p = (char *)work.m_block + offset;
  int padding = 56 - (offset + 1);

  *p++ = 0x80;
  if(padding < 0)
  {
    memset(p, 0x00, padding + sizeof(uint64_t));
    le32_to_cpu_array(work.m_block, BLOCK_WORDS);
    work.transform(work.m_block);
    p = (char *)work.m_block;
    padding = 56;
  }

  memset(p, 0, padding);
  work.m_block[14] = work.m_byteCount << 3;
  work.m_block[15] = work.m_byteCount >> 29;
  le32_to_cpu_array(work.m_block, (BLOCK_SIZE - sizeof(uint64_t)) / sizeof(uint32_t));

  work.transform(work.m_block);
  cpu_to_le32_array(work.m_hash, HASH_WORDS * sizeof(uint32_t));

  ostringstream os;
  os << setfill('0');
  os << hex;

  p = (char*)work.m_hash;

  for(i = 0; i < DIGEST_SIZE; i++)
  {
    uint8_t ch = *p++;
    os << setw(2) << (int)ch;
  }

  return os.str();
}

}
