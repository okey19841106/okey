/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/config.h"
#include "pclasses/pthread_.h"
#include "pclasses/pmutex.h"
#include "pclasses/psemaphore.h"
#include "pclasses/pcriticalsection.h"
#include "pclasses/pthreadkey.h"
#include <list>

#include "private.h"
#include <unistd.h>
#include <errno.h>
#include <signal.h>
#include <pthread.h>

namespace P {

using namespace std;

struct Thread::thread_handle_t {
  pthread_t thread;
  state_t state;
  Mutex running_mutex;
  Mutex notsuspended_mutex;
  Semaphore resume_sem;
  bool should_exit;
  bool should_suspend;
  
  // common members
  static list<Thread::thread_handle_t*> threadHandlePool;
  static CriticalSection threadHandlePoolCs;
};

#include "pthread.common.i"

class Thread::Private {
  public:
    static void* thread_entry(void* param)
    {
      thread_start_param* start_param = (thread_start_param*)param;
      Thread* thread = start_param->thread;
      g_currentThread = thread;

      // block all signals .. they must be dispatched in main thread only
      sigset_t sigset;
      sigfillset(&sigset);
      pthread_sigmask(SIG_BLOCK, &sigset, 0);
      
      thread->handle()->notsuspended_mutex.lock();
      thread->handle()->running_mutex.lock();
      thread->handle()->state = Running;

      // post the start semaphore...
      if(start_param->sem)
        start_param->sem->post();

      delete start_param;

      // run threads initial() method ...
      if(!thread->initial())
      {
        Thread::destroyHandle(thread->handle());
        return 0;
      }
 
      // push threads cleanup handler and run the main() method...
      pthread_cleanup_push(thread_cleanup, (void*)thread);
      thread->main();
      pthread_cleanup_pop(1);
      
      return 0;
    }

    static void thread_cleanup(void* param)
    {
      Thread* thread = (Thread*)param;
      thread_handle_t* handle = thread->handle();
      
      thread->final();

      handle->state = Stopped;
      handle->notsuspended_mutex.unlock();
      handle->running_mutex.unlock();
      Thread::destroyHandle(handle);
    }

};

void Thread::start(Semaphore* sem, int prio) throw(LogicError, ThreadError)
{
  if(!m_handle)
    m_handle = createHandle();

  if(m_handle->state != Stopped)
    throw LogicError("Thread is already running", P_SOURCEINFO);

  thread_start_param* start_param = new thread_start_param;
  start_param->thread = this;
  start_param->sem = sem;

  m_handle->should_exit    = false;
  m_handle->should_suspend = false;

  pthread_attr_t attr;
  pthread_attr_init(&attr);
  pthread_attr_setdetachstate(&attr, 1);

  int ret = pthread_create(&m_handle->thread, &attr, Private::thread_entry, (void*)start_param);
  pthread_attr_destroy(&attr);

  if(ret != 0)
  {
    delete start_param;
    throw ThreadError(ret, "Could not create thread", P_SOURCEINFO);
  }
}

void Thread::kill() throw(LogicError, SystemError)
{
  if(!m_handle)
    return;

  if(current() == this)
    throw LogicError("Cannot kill own thread", P_SOURCEINFO);

  int ret = pthread_kill(m_handle->thread, SIGKILL);
  if(ret != 0)
    throw SystemError(errno, "Could not kill thread", P_SOURCEINFO);

  Thread::destroyHandle(m_handle);
  m_handle = 0;
}

void Thread::yield() throw()
{
  #ifndef HAVE_PTHREAD_YIELD
  {
    Thread::sleep(1);
  }
  #else
  {
    pthread_yield();
  }
  #endif
}

void Thread::sleep(unsigned int timeout) throw()
{
  #ifdef HAVE_PTHREAD_DELAY
  {
    struct timespec ts;
    pthread_delay(get_timeout(&ts, timeout, TIMEOUT_RELATIVE));
  }
  #else
  {
    usleep(timeout * 1000);
  }
  #endif
}

void Thread::exit() throw()
{
  pthread_exit(0);
}

}
