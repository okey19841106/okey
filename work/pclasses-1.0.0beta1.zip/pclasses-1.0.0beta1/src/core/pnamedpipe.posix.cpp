/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/pnamedpipe.h"
#include "pclasses/pthread_.h"
#include "private.h"

#include <sys/time.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <errno.h>

class SIGPIPE_Init {
  public:
    SIGPIPE_Init()
    {
      signal(SIGPIPE, SIG_IGN);
    }
};

SIGPIPE_Init SocketInit;

namespace P {

using namespace std;

void NamedPipeServer::close() throw(IOError)
{
  if(m_handle != INVALID_HANDLE_VALUE)
  {
    ::close(m_handle);
    unlink(m_name.c_str());
  }

  m_handle = INVALID_HANDLE_VALUE;
}

void NamedPipeServer::listen(const char* name) throw(IOError)
{
  close();

  struct sockaddr_un npaddr;
  npaddr.sun_family = AF_UNIX;
  strcpy(npaddr.sun_path, name);

  m_handle = socket(PF_UNIX, SOCK_STREAM, 0);
  if(m_handle == -1)
    throw IOError(errno, "Could not create unix socket", P_SOURCEINFO);

  int ret = bind(m_handle, (sockaddr*)&npaddr, sizeof(sockaddr_un));
  if(ret == -1)
  {
    ::close(m_handle);
    throw IOError(errno, "Could not bind on unix socket", P_SOURCEINFO);
  }

  ret = ::listen(m_handle, 128);
  if(ret == -1)
  {
    ::close(m_handle);
    throw IOError(errno, "Could not listen on unix socket", P_SOURCEINFO);
  }

  m_name = name;
}

bool NamedPipeServer::waitClient(unsigned int timeout) throw(IOError)
{
  fd_set rfds;
  FD_ZERO(&rfds);
  FD_SET(m_handle, &rfds);

  struct timeval tv;
  _select:
  int ret = select(m_handle + 1, &rfds, 0, 0, get_timeout(&tv, timeout, TIMEOUT_RELATIVE));
  if(ret == -1)
  {
    if(errno == EINTR)
      goto _select;
    throw IOError(errno, "Could not select on unix socket", P_SOURCEINFO);
  }

  if(ret == 1)
    return true;

  return false;
}

io_handle_t NamedPipeServer::accept() throw(IOError)
{
  struct sockaddr_un npaddr;
  socklen_t addrlen = sizeof(sockaddr_un);

  io_handle_t handle = ::accept(m_handle, (sockaddr*)&npaddr, &addrlen);
  if(handle == -1)
    throw IOError(errno, "Could not accept connection on unix socket", P_SOURCEINFO);

  return handle;
}


void NamedPipe::connect(const char* name) throw(IOError)
{
  if(handle() != INVALID_HANDLE_VALUE)
    close();

  struct sockaddr_un npaddr;
  npaddr.sun_family = AF_UNIX;
  strcpy(npaddr.sun_path, name);

  io_handle_t handle = socket(PF_UNIX, SOCK_STREAM, 0);
  if(handle == -1)
    throw IOError(errno, "Could not create unix socket", P_SOURCEINFO);

  int ret = ::connect(handle, (sockaddr*)&npaddr, sizeof(sockaddr_un));
  if(ret == -1)
  {
    ::close(handle);
    throw IOError(errno, "Could not connect to unix socket", P_SOURCEINFO);
  }

  setHandle(handle);
}

void NamedPipe::close() throw(IOError)
{
  if(handle() != INVALID_HANDLE_VALUE)
  {
    ::shutdown(handle(), 2);
    IODevice::close();
  }
}

size_t NamedPipe::peek(char* buffer, size_t count) throw(IOError)
{
  int ret;
  _recv:
  ret = recv(handle(), (void*)buffer, count, MSG_PEEK);
  if(ret != -1)
    return ret;

  if(errno == EINTR)
    goto _recv;

  throw IOError(errno, "Could not peek on unix socket", P_SOURCEINFO);
}

}
