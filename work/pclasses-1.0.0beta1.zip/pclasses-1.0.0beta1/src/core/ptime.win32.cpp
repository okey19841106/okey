/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/config.h"
#include "pclasses/ptime.h"
#include <windows.h>
#include <iomanip>
#include <string.h>

namespace P {

using namespace std;

DateTime DateTime::current(currentMode_t mode)
{
  SYSTEMTIME st;
  string tzname;

  switch(mode)
  {
    case Local: tzname = currentTimeZone();
                GetLocalTime(&st);
                break;

    case UTC:
                tzname = "UTC";
                GetSystemTime(&st);
                break;

    default:
                throw;
                //@todo throw InvalidArgument

  };

  return DateTime(Date(st.wYear, st.wMonth, st.wDay),
                  Time(st.wHour, st.wMinute, st.wSecond, st.wMilliseconds * 1000),
                  tzname);
}

string DateTime::currentTimeZone()
{
  _tzset();

  time_t timet = time(0);
  string tz_name;

  struct tm* currtm = localtime(&timet);

  char tmp[256];
  sprintf(tmp, "GMT%+d", -(_timezone / 3600));

  tz_name = tmp;

  /*if(!currtm)
    tz_name = tzname[0];
  else
    tz_name = currtm->tm_isdst > 0 ? _tzname[1] : _tzname[0];*/

  return tz_name;
}

}
