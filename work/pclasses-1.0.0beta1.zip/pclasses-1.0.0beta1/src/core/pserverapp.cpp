/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/pserverapp.h"

#ifdef WIN32
  #include <windows.h>
  #include <signal.h>
#else
  #include <sys/types.h>
  #include <sys/stat.h>
  #include <fcntl.h>
  #include <unistd.h>
  #include <signal.h>
  #include <errno.h>
#endif

namespace P {

ServerApp::ServerApp(const AboutData& about)
: SimpleApp(about), m_syslog(0), m_config(0)
{
}

ServerApp::~ServerApp()
{
}

void ServerApp::setSyslog(SystemLog* log) throw()
{
  m_syslog = log;
}

void ServerApp::setConfig(Config* cfg) throw()
{
  m_config = cfg;
}

void ServerApp::daemonize() throw(SystemError)
{
  #ifdef WIN32
  #else
  {
    pid_t pid;
    
    if((pid = fork()) != 0)
      exit(0);
      
    if(setsid() == -1)
      throw SystemError(errno, "Cannot become session leader", P_SOURCEINFO);

    int nullfd = open("/dev/null", O_RDWR);
    dup2(nullfd, 0);
    dup2(nullfd, 1);
    dup2(nullfd, 2);
  }
  #endif
}

int ServerApp::init(int argc, char* argv[])
{
  int ret = 0;

  if((ret = SimpleApp::init(argc, argv)))
    return ret;
    
  #ifndef WIN32
  signal(SIGHUP, &SIGHUP_handler);
  #endif

  return 0;  
}

void ServerApp::reload()
{
  try
  {
    if(m_config)
      m_config->reload();
  }
  catch(...)
  {
  }

  try
  {
    if(m_syslog)
      m_syslog->restart();
  }
  catch(...)
  {
  }
}

RETSIGTYPE ServerApp::SIGHUP_handler(int sig)
{
  #ifdef WIN32
  {
  }
  #else
  {
    if(sig == SIGHUP)
    {
      signal(SIGHUP, SIG_IGN);
      
      ServerApp* srvapp = dynamic_cast<ServerApp*>(theApp());
      if(srvapp)
        srvapp->reload();
    
      signal(SIGHUP, &SIGHUP_handler);
    }
  }
  #endif
}

}
