/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/pnamedpipe.h"
#include "pclasses/pthread_.h"
#include <windows.h>

namespace P {

using namespace std;

void NamedPipeServer::close()
{
  if(m_handle != INVALID_HANDLE_VALUE)
  {
    CloseHandle(m_handle);
    m_handle = INVALID_HANDLE_VALUE;
  }
}

void NamedPipeServer::listen(const char* name) throw(IOError)
{
  if(m_handle != INVALID_HANDLE_VALUE)
  {
    CloseHandle(m_handle);
  }

  m_handle = CreateNamedPipe(name, PIPE_ACCESS_DUPLEX,
                            PIPE_TYPE_BYTE | PIPE_NOWAIT,
                            PIPE_UNLIMITED_INSTANCES,
                            4096, 4096, 1000, 0);
  if(m_handle == INVALID_HANDLE_VALUE)
    throw IOError(GetLastError(), "Could not create named pipe server", P_SOURCEINFO);

  m_name = name;
}

bool NamedPipeServer::waitClient(unsigned int timeout) throw(IOError)
{
  DWORD expire = GetTickCount() + timeout + 1;

  while(GetTickCount() < expire)
  {
    if(ConnectNamedPipe(m_handle, NULL))
      return true;

    if(GetLastError() == ERROR_PIPE_CONNECTED)
      return true;
    else if(GetLastError() == ERROR_PIPE_LISTENING)
    {
      Thread::yield();
      continue;
    }

    throw IOError(errno, "Could not wait for named pipe client", P_SOURCEINFO);
  }

  return false;
}

io_handle_t NamedPipeServer::accept() throw(IOError)
{
  io_handle_t client = m_handle;
  m_handle = CreateNamedPipe(m_name.c_str(), PIPE_ACCESS_DUPLEX,
                            PIPE_TYPE_BYTE | PIPE_NOWAIT,
                            PIPE_UNLIMITED_INSTANCES,
                            4096, 4096, 1000, 0);

  DWORD state = PIPE_WAIT;
  SetNamedPipeHandleState(client, &state, NULL, NULL);

  return client;
}

void NamedPipe::connect(const char* name) throw(IOError)
{
  io_handle_t handle;

  while(1)
  {
    handle = CreateFile(name, GENERIC_READ | GENERIC_WRITE,
                        0, NULL, OPEN_EXISTING, 0, NULL);

    if(handle == INVALID_HANDLE_VALUE)
    {
      if(GetLastError() == ERROR_PIPE_BUSY)
      {
        if(!WaitNamedPipe(name, NMPWAIT_WAIT_FOREVER))
          throw IOError(GetLastError(), "Could not open named pipe", P_SOURCEINFO);

        continue;
      }
      throw IOError(GetLastError(), "Could not open named pipe", P_SOURCEINFO);
    }
    else
      break;
  }

  setHandle(handle);
}

void NamedPipe::close() throw(IOError)
{
  if(handle() != INVALID_HANDLE_VALUE)
  {
    DWORD flags;
    GetNamedPipeInfo(handle(), &flags, NULL, NULL, NULL);

    if(flags & PIPE_SERVER_END)
      DisconnectNamedPipe(handle());

    IODevice::close();
  }
}

size_t NamedPipe::peek(char* buffer, size_t count) throw(IOError)
{
  DWORD bytesRead, bytesAvail, bytesLeft;
  if(PeekNamedPipe(handle(), (void*)buffer, count, &bytesRead, &bytesAvail, &bytesLeft))
    return bytesRead;

  throw IOError(GetLastError(), "Could not peek on named pipe", P_SOURCEINFO);
}

}
