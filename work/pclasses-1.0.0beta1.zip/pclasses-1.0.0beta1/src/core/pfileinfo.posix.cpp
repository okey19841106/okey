/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/pfileinfo.h"

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/param.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>

namespace P {

using namespace std;

FileInfo::FileInfo(const char* path) throw(IOError)
{
  string mypath = path;

  if(mypath.at(mypath.length()-1) == '/')
    mypath.erase(mypath.length()-1,1);

  string::size_type namepos = mypath.find_last_of("/");
  if(namepos == string::npos)
  {
    m_dirName = "/";
    m_name    = path;
  }
  else
  {
    m_dirName = mypath.substr(0,namepos+1);
    m_name    = mypath.substr(namepos+1);
  }

  #ifdef HAVE_LARGEFILE64
  struct stat64 st;
  if(stat64(mypath.c_str(), &st))
  #else
  struct stat st;
  if(stat(mypath.c_str(), &st))
  #endif
    throw IOError(errno, "Could not stat file", P_SOURCEINFO);

  m_size = st.st_size;

  if(S_ISREG(st.st_mode))
    m_type = File;
  else if(S_ISDIR(st.st_mode))
    m_type = Directory;
  else if(S_ISCHR(st.st_mode))
    m_type = CharDevice;
  else if(S_ISBLK(st.st_mode))
    m_type = BlockDevice;
  else if(S_ISFIFO(st.st_mode))
    m_type = Pipe;
  #ifdef S_ISSOCK
  else if(S_ISSOCK(st.st_mode))
    m_type = Pipe;
  #endif
  #ifdef S_ISLNK
  else if(S_ISLNK(st.st_mode))
    m_type = Link;
  #endif
  else
    m_type = Unknown;

  //@todo retrieve atime, ctime, mtime
}

string FileInfo::absDirName() const throw(SystemError)
{
  #ifdef HAVE_REALPATH
  {
    char abspath[PATH_MAX+1];
    if(!realpath(m_dirName.c_str(), abspath))
      throw SystemError(errno, "Could not resolve absolute path", P_SOURCEINFO);

    return string(abspath);
  }
  #elif defined(HAVE_CANONICALIZE_FILE_NAME)
  {
    char* abspath = canonicalize_file_name(m_dirName.c_str());
    if(!abspath)
      throw SystemError(errno, "Could not resolve absolute path", P_SOURCEINFO);

    string ret(abspath);
    free(abspath);

    return ret;
  }
  #endif
}

}
