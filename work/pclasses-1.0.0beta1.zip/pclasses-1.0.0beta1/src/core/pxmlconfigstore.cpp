/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/pxmlconfigstore.h"
#include "pclasses/pfile.h"
#include "pclasses/pxml.h"

#include <iostream>
#include <stack>

namespace P {

using namespace std;

class XMLConfigParser: public XMLParser {
  public:
    XMLConfigParser(Config::Key& root)
    : XMLParser(), m_root(root), m_unknownDepth(0), 
      m_inConfig(false), m_inValue(false) {}
    
  protected:
    void documentStart();
    void documentEnd();
    
    void comment(const string& text);
    void characters(const char* text, unsigned len);
    void elementStart(const string& name, const map<string, string>& attr);
    void elementEnd(const string& name);
    
    void warning(const string& msg) 
    { cout << "XMLConfig WARNING: " << msg << endl; }
    
    void error(const string& msg) 
    { cout << "XMLConfig ERROR: " << msg << endl; }
    
    void fatal(const string& msg) 
    { cout << "XMLConfig FATAL: " << msg << endl; }
    
  private:
    XMLConfigParser(const XMLConfigParser&);
    XMLConfigParser& operator=(const XMLConfigParser&);
  
    Config::Key&        m_root;
    stack<Config::Key*> m_keyStack;
    
    unsigned int        m_unknownDepth;
    bool                m_inConfig;
    bool                m_inValue;
    string              m_valueName;
    string              m_valueChars;
};

void XMLConfigParser::documentStart()
{
  m_keyStack.push(&m_root);
}

void XMLConfigParser::documentEnd()
{
  m_keyStack.pop();
}

void XMLConfigParser::comment(const string& text)
{
}

void XMLConfigParser::characters(const char* text, unsigned len)
{
  if(m_inValue)
  {
    m_valueChars.append(text, len);
  }
}

void XMLConfigParser::elementStart(const string& name, const map<string, string>& attr)
{
  if(m_unknownDepth > 0)
  {
    ++m_unknownDepth;
    return;
  }

  if(name == "config")
  {
    m_inConfig = true;
  }
  else if(m_inConfig)
  {  
    if(name == "key")
    {
      if(m_inValue)
      {
        error("Key tag not allowed inside a value tag!");
        ++m_unknownDepth;
        return;
      }

      string keyName = "";
      map<string, string>::const_iterator i = attr.find("name");
      if(i != attr.end())
        keyName = i->second;

      Config::Key* key = m_keyStack.top();
      key = key->addKey(keyName);
      m_keyStack.push(key);
    }
    else if(name == "value")
    {
      if(m_inValue)
      {
        error("Value tag not allowed inside a value tag!");
        ++m_unknownDepth;
        return;
      }

      map<string, string>::const_iterator i = attr.find("name");
      if(i == attr.end())
        m_valueName = "";
      else
        m_valueName = i->second;

      m_inValue = true;
    }
    else
    {
      ++m_unknownDepth;
    }
  }
  else
  {
    ++m_unknownDepth;
  }
}

void XMLConfigParser::elementEnd(const string& name)
{
  if(m_unknownDepth > 0)
  {
    --m_unknownDepth;
    return;
  }
    
  if(name == "config")
  {
    m_inConfig = false;
  }
  else if(name == "key")
  {
    m_keyStack.pop();
  }
  else if(name == "value")
  {
    Config::Key* key = m_keyStack.top();
    key->setValue(m_valueName, m_valueChars);
    
    m_valueName  = "";
    m_valueChars = "";
    m_inValue    = false;
  }
}

XMLConfigStore::XMLConfigStore(const string& path)
: ConfigStore(path)
{
}

XMLConfigStore::~XMLConfigStore()
{
}
    
void XMLConfigStore::read(Config::Key& root)
{
  XMLConfigParser parser(root);
  File f(path().c_str(), File::Read, File::Normal, File::OpenExisting);
      
  char buffer[4096];
  
  int ret;
  while(1)
  {
    ret = f.read(buffer, 4096);
    if(!ret)
      break;

    parser.parse(buffer, ret);
  }

  if(!parser.isWellFormed())
    cout << "XMLConfig WARNING: XML document is not well formed!" << endl;
  
  parser.finish();
}

void XMLConfigStore::update(Config::Key& root)
{
}

}
