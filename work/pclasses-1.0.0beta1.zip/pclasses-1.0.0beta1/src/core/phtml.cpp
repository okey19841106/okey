/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2002  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/phtml.h"
#include <libxml/xmlversion.h>
#include <libxml/parser.h>
#include <libxml/parserInternals.h>
#include <libxml/HTMLparser.h>
#include <libxml/xmlIO.h>
#include <stdarg.h>
#include <sstream>
#include <iostream>

#ifdef WIN32
  #define vsnprintf _vsnprintf
#endif

namespace P {

using namespace std;

extern "C" {

static void saxCharacters(HTMLParser* xml, const char *text, int unsigned len)
{
  xml->characters(text, len);
}

static void saxComment(HTMLParser* xml, const char *text)
{
  xml->comment(text);
}

static void saxStartDocument(HTMLParser* xml)
{
  xml->documentStart();
}

static void saxEndDocument(HTMLParser* xml)
{
  xml->documentEnd();
}

static void saxStartElement(HTMLParser* xml, const char *name, const char **attributes)
{
  map<string, string> attr_map;
  
  if(attributes)
  {
    while(*attributes)
    {
      string attr_name = *attributes;
      ++attributes;
      
      if(*attributes)
        attr_map[attr_name] = *attributes;
      else
        attr_map[attr_name] = "";
     
      ++attributes;
    }
  }
  
  xml->elementStart(name, attr_map);
}

static void saxEndElement(HTMLParser* xml, const char *name)
{
  xml->elementEnd(name);
}

static void saxWarning(HTMLParser* xml, const char* msg, ...)
{
  char buffer[1024];
  va_list args;
  va_start(args, msg);
  vsnprintf(buffer, 1024, msg, args);
  va_end(args);
  xml->warning(buffer);
}

static void saxError(HTMLParser* xml, const char* msg, ...)
{
  char buffer[1024];
  va_list args;
  va_start(args, msg);
  vsnprintf(buffer, 1024, msg, args);
  va_end(args);
  xml->error(buffer);
}

static void saxFatalError(HTMLParser* xml, const char* msg, ...)
{
  char buffer[1024];
  va_list args;
  va_start(args, msg);
  vsnprintf(buffer, 1024, msg, args);
  va_end(args);
  xml->fatal(buffer);
}

};

#define INITIAL_CHUNK_SIZE  1024
#define MAX_CHUNK_SIZE      8192

struct HTMLParser::parser_context {
  parser_context(HTMLParser* _parser)
  {
    memset(&sax, 0, sizeof(xmlSAXHandler));
    sax.startDocument = (startDocumentSAXFunc)&saxStartDocument;
    sax.endDocument   = (endDocumentSAXFunc)&saxEndDocument;
    sax.startElement  = (startElementSAXFunc)&saxStartElement;
    sax.endElement    = (endElementSAXFunc)&saxEndElement;
    sax.characters    = (charactersSAXFunc)&saxCharacters;
    sax.comment       = (commentSAXFunc)&saxComment;
    sax.warning       = (warningSAXFunc)&saxWarning;
    sax.error         = (errorSAXFunc)&saxError;
    sax.fatalError    = (fatalErrorSAXFunc)&saxFatalError;
    
    parser = _parser;
    html   = 0;
  }
 
  void parse(const char* buffer, int len)
  {
    if(!html)
    {
      /*
        htmlCreatePushParserCtxt seems to have problems with initial chunks
        that are larger than 1024 byte :(
      */
      if(len >= INITIAL_CHUNK_SIZE)
      {
        html = htmlCreatePushParserCtxt(&sax, parser, buffer, INITIAL_CHUNK_SIZE, "", XML_CHAR_ENCODING_NONE);
        buffer += INITIAL_CHUNK_SIZE;
        len    -= INITIAL_CHUNK_SIZE;
      }
      else
      {
        html = htmlCreatePushParserCtxt(&sax, parser, buffer, len, "", XML_CHAR_ENCODING_NONE);
        len = 0;
      }
    }

    while(len > 0)
    {
      int bytes = (len > MAX_CHUNK_SIZE) ? (MAX_CHUNK_SIZE) : (len);
      htmlParseChunk(html, buffer, bytes, 0);
      
      buffer += bytes;
      len    -= bytes;
    }
  }
 
  ~parser_context()
  {
    if(html)
    {
      if(html->myDoc)
        xmlFreeDoc(html->myDoc);
        
      htmlFreeParserCtxt(html);
    }
  }
    
  xmlSAXHandler     sax;
  htmlParserCtxtPtr html;
  HTMLParser*       parser;
};

HTMLParser::HTMLParser()
: m_context(new parser_context(this))
{
}

HTMLParser::~HTMLParser()
{
  delete m_context;
}

void HTMLParser::reset()
{
  if(m_context->html)
  {
    if(m_context->html->myDoc)
      xmlFreeDoc(m_context->html->myDoc);
      
    htmlFreeParserCtxt(m_context->html);
    m_context->html = 0;
  }
}

void HTMLParser::parse(const char* buffer, int len)
{
  m_context->parse(buffer, len);
}

void HTMLParser::finish()
{
  if(m_context->html)
  {
    char tmp[] = "";
    htmlParseChunk(m_context->html, tmp, 0, 1);
  }
}

}
