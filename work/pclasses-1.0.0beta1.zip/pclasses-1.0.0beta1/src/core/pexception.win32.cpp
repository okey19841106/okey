/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/pexception.h"

#include <windows.h>
#include <lmerr.h>

namespace P {

using namespace std;

string SystemError::text() const throw()
{
  char tmpbuffer[4096];

  HMODULE hModule = NULL;
  DWORD fmtFlags = FORMAT_MESSAGE_IGNORE_INSERTS | FORMAT_MESSAGE_FROM_SYSTEM;

  if(m_errnum >= NERR_BASE && m_errnum <= MAX_NERR)
  {
    hModule = LoadLibraryEx("netmsg.dll", NULL, LOAD_LIBRARY_AS_DATAFILE);

    if(hModule != NULL)
      fmtFlags |= FORMAT_MESSAGE_FROM_HMODULE;
  }

  DWORD msglen =
    FormatMessage(fmtFlags, hModule, m_errnum,
                  MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
                  tmpbuffer, 4096, NULL);

  if(hModule != NULL)
    FreeLibrary(hModule);

  string msg;
  msg.assign(tmpbuffer, msglen);
  return msg;
}

}
