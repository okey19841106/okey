/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/pthreadpool.h"
 
namespace P {

class WorkerThread: public Thread {
  friend class ThreadPool;

  public:
    WorkerThread(ThreadPool* pool)
    : m_pool(pool), m_job(0)
    {
    }

    ~WorkerThread()
    {
    }

    bool initial()
    {
      return true;
    }

    void main()
    {
      while(!testCancel())
      {
        if(m_job)
        {
          m_job->main();
          m_job->finished();
          m_pool->finished(this);
          m_job = 0;
        }
        else
        {
          Thread::yield();
        }
      }
    }

    void final()
    {
      delete this;
    }

  protected:
    ThreadPool* m_pool;
    ThreadJob*  m_job;

};


ThreadJob::ThreadJob()
{
}

ThreadJob::~ThreadJob()
{
}

void ThreadJob::wait()
{
  m_lock.wait();
}

void ThreadJob::tryWait()
{
  m_lock.tryWait();
}

void ThreadJob::main()
{
  sigMain.emit();
}

void ThreadJob::finished()
{
  m_lock.post();
}

ThreadPool::ThreadPool(unsigned int numThreadsInit, unsigned int numThreadsMaxIdle,
                       unsigned int numThreadsMax)
: m_numThreads(numThreadsInit), m_numThreadsMaxIdle(numThreadsMaxIdle),
  m_numThreadsMax(numThreadsMax), m_numThreadsIdle(numThreadsInit)
{
  try
  {
    WorkerThread* worker = 0;
    for(unsigned int i=0; i < numThreadsInit; i++)
    {
      worker = new WorkerThread(this);
      worker->suspend(1000);
      m_idle.push(worker);
    }
  }
  catch(...)
  {
    //@todo cleanup all workers
    throw;
  }
}

ThreadPool::~ThreadPool()
{
}

void ThreadPool::enqueue(ThreadJob* job)
{
  m_lock.lock();

  // if workers are idle, grab one and spawn a new one if max threads is not reached...
  if(m_numThreadsIdle)
  {
    WorkerThread* worker = m_idle.front();
    m_idle.pop();

    if(m_numThreads < m_numThreadsMax)
    {
      worker = new WorkerThread(this);
      worker->suspend(1000);
      m_idle.push(worker);

      ++m_numThreads;
    }
    else
    {
      --m_numThreadsIdle;
    }
  }
  else
  {
    m_jobs.push(job);
  }

  m_lock.unlock();

}

void ThreadPool::finished(WorkerThread* worker)
{
  m_lock.lock();

  ThreadJob* job = worker->m_job;

  // kill worker if max idle is reached ...
  if(m_numThreadsIdle+1 > m_numThreadsMaxIdle)
  {
    --m_numThreads;
    m_lock.unlock();

    Thread::exit(); // does not return
  }
  else
  {
    worker->suspend(1000);
    m_idle.push(worker);
    ++m_numThreadsIdle;
    m_lock.unlock();
  }
}

}
