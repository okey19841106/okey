/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/pdirectory.h"
#include "pclasses/pfile.h"
#include "pclasses/pprocess.h"

namespace P {

using namespace std;

ProcessIO::ProcessIO(io_handle_t in, io_handle_t out, io_handle_t err) throw()
: IODevice(), m_in(in), m_out(out), m_err(err)
{
  setHandle(in);
}

ProcessIO::~ProcessIO() throw()
{
  try
  {
    close();
  }
  catch(...)
  {
  }
}

void ProcessIO::close() throw(IOError)
{
  if(m_in != INVALID_HANDLE_VALUE)
  {
    setHandle(m_in);
    IODevice::close();
    m_in = INVALID_HANDLE_VALUE;
  }

  if(m_out != INVALID_HANDLE_VALUE)
  {
    setHandle(m_out);
    IODevice::close();
    m_out = INVALID_HANDLE_VALUE;
  }

  if(m_err != INVALID_HANDLE_VALUE)
  {
    setHandle(m_in);
    IODevice::close();
    m_err = INVALID_HANDLE_VALUE;
  }
}

size_t ProcessIO::write(const char* buffer, size_t count) throw(IOError)
{
  setHandle(m_in);
  return IODevice::write(buffer, count);
}

size_t ProcessIO::read(char* buffer, size_t count) throw(IOError)
{
  setHandle(m_out);
  return IODevice::read(buffer, count);
}

size_t ProcessIO::readErr(char* buffer, size_t count) throw(IOError)
{
  setHandle(m_err);
  return IODevice::read(buffer, count);
}


Process::Process(const char* program, const list<string>& args) throw(IOError)
: m_handle(0), m_procIO(0), m_state(Stopped), m_dir(Directory::current()), m_program(program), m_args(args)
{
}

Process::~Process() throw()
{
  try
  {
    if(m_handle)
    {
      kill();
      wait();
    }
  }
  catch(...)
  {
  }
}

void Process::addArg(const char* arg)
{
  m_args.push_back(string(arg));
}

void Process::clearArgs()
{
  m_args.clear();
}

void Process::setWorkDir(const char* dir)
{
  m_dir = dir;
}

}
