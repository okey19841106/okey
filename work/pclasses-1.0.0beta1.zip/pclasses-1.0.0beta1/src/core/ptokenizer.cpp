/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/ptokenizer.h"

namespace P {

using namespace std;

StreamTokenizer::StreamTokenizer(istream& is, const string& separator, matchMode_t mode)
: m_mode(mode), m_is(is), m_separator(separator)
{
}

StreamTokenizer::~StreamTokenizer()
{
}

StreamTokenizer::operator bool() const
{
  return m_is ? true : false;
}

StreamTokenizer& StreamTokenizer::operator>>(string& token)
{
  ostringstream os;
  char* foundsep = new char[m_separator.size()+1];
  size_t foundsepl = 0;
  char ch;

  m_is >> noskipws;

  while(1)
  {
    m_is >> ch;
    if(!m_is)
      break;

    /* match all mode */
    if(m_mode == MatchAll)
    {      
      if(ch == m_separator[foundsepl])
      {
        foundsep[foundsepl++] = ch;
        if(foundsepl == m_separator.size())
        {
          token = os.str();
          delete[] foundsep;
          return *this;
        }
      }
      else
      {
        if(foundsepl > 0)
        {
          foundsep[foundsepl++] = 0;
          foundsepl = 0;
          os << foundsep;
        }
        os << ch;
      }
    }
    /* match any */
    else
    {
      if(m_separator.find(ch) != string::npos)
      {
        token = os.str();
        return *this;
      }
      else
        os << ch;
    }
  }

  token = os.str();
  delete[] foundsep;
  return *this;
}


StringTokenizer::StringTokenizer(const string& str, const string& separator, matchMode_t mode)
: StreamTokenizer(m_is, separator), m_is(str)
{
}

StringTokenizer::~StringTokenizer()
{
}

}
