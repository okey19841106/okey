/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/pfilemon.h"
#include "pclasses/pfile.h"
#include <map>
#include <sstream>
#include <fam.h>
#include <errno.h>

#include "private.h"

namespace P {

using namespace std;

struct FileMonitor::file_monitor_handle_t {
  FAMConnection* conn;
  map<string, FAMRequest*> dirs;

  const string& get_request_dir(FAMRequest* req)
  {
    static string emptystr;

    for(map<string,FAMRequest*>::const_iterator i = dirs.begin();
        i != dirs.end(); ++i)
    {
      if(i->second->reqnum == req->reqnum)
        return i->first;
    }

    return emptystr;
  }

  bool event_pending()
  {
    // check if a fam event is pending...
    int ret = FAMPending(conn);
    if(ret == 1)
      return true;
    else if(ret == -1)
      throw IOError(0, "Could not check for pending fam events", P_SOURCEINFO);

    return false;
  }

  bool get_next_event(Event& evt)
  {
    FAMEvent fevt;

    while(FAMNextEvent(conn, &fevt) == 1)
    {
      ostringstream os;
      os << get_request_dir(&fevt.fr) << "/"  << fevt.filename;

      switch(fevt.code)
      {
        case FAMCreated:
            evt = Event(Event::Created, os.str().c_str());
            break;

        case FAMDeleted:
            evt = Event(Event::Deleted, os.str().c_str());
            break;

        case FAMChanged:
            evt = Event(Event::Changed, os.str().c_str());
            break;

        default:
            continue;
      }

      return true;
    }

    return false;
  }

};

FileMonitor::FileMonitor()
: m_handle(new file_monitor_handle_t)
{
  m_handle->conn = 0;
}

FileMonitor::~FileMonitor()
{
  if(m_handle->conn)
  {
    //TODO: delete all famrequests...
  
    FAMClose(m_handle->conn);
    free(m_handle->conn);
  }

  delete m_handle;
}

void FileMonitor::addDir(const char* path)
{
  // make sure name is a directory...
  if(File::stat(path).type() != FileInfo::Directory)
    throw LogicError("Path is not a directory", P_SOURCEINFO);

  if(isMonitored(path))
    return;

  if(!m_handle->conn)
  {
    // open connection
    m_handle->conn = (FAMConnection*)malloc(sizeof(FAMConnection));
    if(FAMOpen(m_handle->conn))
    {
      free(m_handle->conn);
      m_handle->conn = 0;
      throw IOError(0, "Could not connect to fam daemon", P_SOURCEINFO);
    }
  }

  FAMRequest* fr = (FAMRequest*)malloc(sizeof(FAMRequest));
  if(FAMMonitorDirectory(m_handle->conn, path, fr, 0))
  {
    free(fr);
    throw IOError(0, "Could not monitor directory", P_SOURCEINFO);
  }

  m_handle->dirs[path] = fr;
}

void FileMonitor::removeDir(const char* path)
{
  map<string,FAMRequest*>::iterator i = m_handle->dirs.find(path);
  if(i != m_handle->dirs.end())
  {
    FAMRequest* fr = i->second;
    FAMCancelMonitor(m_handle->conn, fr);
    free(fr);
    m_handle->dirs.erase(i);
  }
}

bool FileMonitor::isMonitored(const char* path) const
{
  return (m_handle->dirs.find(path) != m_handle->dirs.end() ? true : false);
}

bool FileMonitor::wait(Event& evt, unsigned int timeout)
{
  if(m_handle->event_pending())
    return m_handle->get_next_event(evt);

  int fd = FAMCONNECTION_GETFD(m_handle->conn);

  fd_set rfds;
  FD_ZERO(&rfds);
  FD_SET(fd, &rfds);

  struct timeval tv;
  _select:
  int ret = select(fd + 1, &rfds, 0, 0, get_timeout(&tv, timeout, TIMEOUT_RELATIVE));

  if(ret == 0)
    return false;
  else if(ret == -1)
    throw IOError(errno, "Could not select on socket", P_SOURCEINFO);

  if(m_handle->event_pending())
    return m_handle->get_next_event(evt);

  return false;
}

}
