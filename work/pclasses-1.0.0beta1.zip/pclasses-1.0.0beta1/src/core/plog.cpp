/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/plog.h"
#include "pclasses/plogplugin.h"

namespace P {

using namespace std;

Logger::Logger()
: m_level(LOG_DEBUG)
{}

Logger::~Logger()
{}

LogLevel Logger::str2LogLevel(const string& str)
{
  if(str == "DEBUG")
    return LOG_DEBUG;
  else if(str == "INFO")
    return LOG_INFO;
  else if(str == "NOTICE")
    return LOG_NOTICE;
  else if(str == "WARNING")
    return LOG_WARNING;
  else if(str == "ERROR")
    return LOG_ERROR;
  else if(str == "CRITICAL")
    return LOG_CRITICAL;
  else if(str == "EMERGENCY")
    return LOG_EMERGENCY;
    
  return LOG_INFO;
}

string Logger::logLevel2Str(LogLevel l)
{
  switch(l)
  {
    case LOG_DEBUG:     return "DEBUG";
    case LOG_INFO:      return "INFO";
    case LOG_NOTICE:    return "NOTICE";
    case LOG_WARNING:   return "WARNING";
    case LOG_ERROR:     return "ERROR";
    case LOG_CRITICAL:  return "CRITICAL";
    case LOG_EMERGENCY: return "EMERGENCY";
  }

  return "UNKNOWN";
}

struct SystemLog::LogState {
  LogLevel  level;
  string    subsys;
  char      msgbuff[1024];
  int       msgpos;
};

SystemLog::SystemLog(const string& ident)
: ostream((streambuf*)this), m_ident(ident)
{}

SystemLog::~SystemLog()
{}

void SystemLog::addLogger(Logger* log)
{
  m_lock.lock();
  m_loggers.push_back(log);
  m_lock.unlock();
}

void SystemLog::restart()
{
  m_lock.lock();
  
  for(list<Logger*>::const_iterator i = m_loggers.begin(); i != m_loggers.end(); ++i)
  {
    if((*i)->isActive())
      (*i)->restart();
  }

  m_lock.unlock();
}

bool SystemLog::removeLogger(Logger* log)
{
  m_lock.lock();

  for(list<Logger*>::iterator i = m_loggers.begin(); i != m_loggers.end(); ++i)
  {
    if(*i == log)
    {
      Logger* log = *i;
      m_loggers.erase(i);
      m_lock.unlock();
      log->stop();
      return true;
    }
  }

  m_lock.unlock();
  return false;
}

void SystemLog::enableSubsys(const string& name)
{
  m_lock.lock();

  std::set<string>::iterator i = m_disabled.find(name);
  if(i != m_disabled.end())
  {
    m_disabled.erase(i);
    m_lock.unlock();
  }

  m_lock.unlock();
}

void SystemLog::disableSubsys(const string& name)
{
  m_lock.lock();
  m_disabled.insert(name);
  m_lock.unlock();
}

SystemLog::LogState* SystemLog::state()
{
  if(!m_state)
  {
    LogState* st = new LogState;
    st->level = LOG_INFO;
    st->subsys = "";
    st->msgbuff[0] = 0;
    st->msgpos = 0;
    m_state = st;
  }

  return m_state;
}

SystemLog& SystemLog::operator()(const string& subsys, LogLevel l)
{
  //@todo flush buffer
  LogState* st = state();
  st->subsys = subsys;
  st->level  = l;
  return *this;
}

SystemLog& SystemLog::operator()(LogLevel l)
{
  //@todo flush buffer
  LogState* st = state();
  st->level  = l;
  return *this;
}

int SystemLog::overflow(int ch)
{
  LogState* st = state();

  if(ch == '\n' || !ch)
  {
    if(!st->msgpos)
      return ch;

    st->msgbuff[st->msgpos] = 0;

    DateTime currTime = DateTime::current(DateTime::Local);

    m_lock.lock();

    std::set<string>::const_iterator ei = m_disabled.find(st->subsys);
    if(ei == m_disabled.end())
    {
      for(list<Logger*>::const_iterator i = m_loggers.begin(); i != m_loggers.end(); ++i)
      {
        Logger* log = *i;
        if(log->isActive() && st->level >= log->logLevel())
          log->output(currTime, st->level, m_ident, st->subsys, st->msgbuff);
      }
    }

    m_lock.unlock();

    st->msgpos = 0;
    return ch;
  }

  if(st->msgpos < (int)(sizeof(st->msgbuff) - 1))
    st->msgbuff[st->msgpos++] = ch;
  else
    /* overflow when buffer is full */
    overflow(0);

  return ch;
}

}
