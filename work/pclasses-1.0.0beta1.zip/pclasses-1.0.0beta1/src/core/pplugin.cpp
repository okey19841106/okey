/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/pplugin.h"
#include "pclasses/pdirectory.h"
#include "pclasses/pprocess.h"
#include <string>
#include <iostream>

namespace P {

using namespace std;

typedef PluginBase* (*plugin_create_t)(void);
typedef void (*plugin_destroy_t)(PluginBase*);

PluginBase::PluginBase()
{}

PluginBase::~PluginBase()
{}

struct PluginSharedLib {
  SharedLib* shlib;
  int refCount;
};

struct PluginFactoryImpl::Plugin {
  PluginSharedLib* lib;
  int refCount;
  PluginMetaInfo* meta;
};

PluginFactoryImpl::PluginFactoryImpl(const char* iface)
: m_iface(iface)
{
  const char* pluginDir = ProcessEnv::get("PCLASSES_DIR");
  if(pluginDir)
  {
    try { addPluginDir(pluginDir); } catch(...) { }
  }
  else
  {
    #ifdef WIN32
    //@todo add win32 standard library paths
    #else
    try { addPluginDir("/usr/lib/pclasses");        } catch(...) { }
    try { addPluginDir("/usr/local/lib/pclasses");  } catch(...) { }
    #endif
  }
}

PluginFactoryImpl::~PluginFactoryImpl()
{
  /* delete all plugin instances */
  map<PluginBase*,Plugin*>::const_iterator pi = m_pinst.begin();
  while(pi != m_pinst.end())
  {
    Plugin* p = pi->second;
    p->meta->destroy(pi->first);
    --p->refCount;
    ++pi;
  }

  m_pinst.clear();
  
  /* unload all plugins */
  list<Plugin*>::const_iterator i = m_plugins.begin();
  while(i != m_plugins.end())
  {
    Plugin* p = *i;

    if(!(--p->lib->refCount))
      delete p->lib->shlib;

    delete p->lib;
    delete p;
    ++i;
  }

  m_plugins.clear();
}

void PluginFactoryImpl::addPlugin(const char* path) throw(SystemError)
{
  SharedLib* shlib = new SharedLib(path, SharedLib::bindNow);

  PluginMetaInfo* meta = (PluginMetaInfo*)(*shlib)["P_plugin"];
  if(!meta)
  {
    delete shlib;
    return;
  }

  PluginSharedLib* lib = new PluginSharedLib;
  lib->shlib    = shlib;
  lib->refCount = 0;

  int i = 0;

  while(meta[i].iface)
  {
    if(m_iface == meta[i].iface && !find(meta[i].feature))
    {
      Plugin* plugin = new Plugin;
      plugin->lib      = lib;
      plugin->refCount = 0;
      plugin->meta     = &meta[i];

      ++lib->refCount;

      m_plugins.push_back(plugin);
    }
    ++i;
  }

  if(!lib->refCount)
  {
    delete lib;
    delete shlib;
  }

}

void PluginFactoryImpl::addPluginDir(const char* path) throw(SystemError, IOError)
{
  Directory dir(path);
  string fullPath;
  ++dir;

  const char* file = *dir;

  while(file)
  {
    try
    {
      fullPath = dir.path() + Directory::separator() + file;
      addPlugin(fullPath.c_str());
    }
    catch(...)
    {
    }

    ++dir;
    file = *dir;
  }
}

PluginFactoryImpl::Plugin* PluginFactoryImpl::find(const char* feature) const
{
  list<Plugin*>::const_iterator i = m_plugins.begin();
  while(i != m_plugins.end())
  {
    Plugin* p = *i;
    if(string(p->meta->feature) == feature)
      return p;
    ++i;
  }

  return 0;
}

PluginBase* PluginFactoryImpl::create(const char* feature)
{
  Plugin* p = find(feature);
  if(p)
  {
    PluginBase* addr = p->meta->create();
    ++p->refCount;

    m_pinst[addr] = p;
    return addr;
  }

  return 0;
}

void PluginFactoryImpl::destroy(PluginBase* pluginInst)
{
  Plugin* p = m_pinst[pluginInst];
  if(p)
  {
    p->meta->destroy(pluginInst);
    --p->refCount;

    m_pinst.erase(pluginInst);
  }
}

bool PluginFactoryImpl::provides(const char* feature) const
{
  Plugin* p = find(feature);
  return (p) ? (true) : (false);
}

}
