/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2002  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/pxml.h"
#include <libxml/xmlversion.h>
#include <libxml/parser.h>
#include <libxml/parserInternals.h>
#include <libxml/xmlIO.h>
#include <sstream>
#include <stdarg.h>

#ifdef WIN32
  #define vsnprintf _vsnprintf
#endif

namespace P {

using namespace std;

extern "C" {

static void saxCharacters(P::XMLParser* xml, const char *text, int unsigned len)
{
  xml->characters(text, len);
}

static void saxComment(XMLParser* xml, const char *text)
{
  xml->comment(text);
}

static void saxStartDocument(XMLParser* xml)
{
  xml->documentStart();
}

static void saxEndDocument(XMLParser* xml)
{
  xml->documentEnd();
}

static void saxStartElement(XMLParser* xml, const char *name, const char **attributes)
{
  map<string, string> attr_map;
  
  if(attributes)
  {
    while(*attributes)
    {
      string attr_name = *attributes;
      ++attributes;
      
      if(*attributes)
        attr_map[attr_name] = *attributes;
      else
        attr_map[attr_name] = "";
     
      ++attributes;
    }
  }
  
  xml->elementStart(name, attr_map);
}

static void saxEndElement(XMLParser* xml, const char *name)
{
  xml->elementEnd(name);
}

static void saxWarning(XMLParser* xml, const char* msg, ...)
{
  char buffer[1024];
  va_list args;
  va_start(args, msg);
  vsnprintf(buffer, 1024, msg, args);
  va_end(args);
  xml->warning(buffer);
}

static void saxError(XMLParser* xml, const char* msg, ...)
{
  char buffer[1024];
  va_list args;
  va_start(args, msg);
  vsnprintf(buffer, 1024, msg, args);
  va_end(args);
  xml->error(buffer);
}

static void saxFatalError(XMLParser* xml, const char* msg, ...)
{
  char buffer[1024];
  va_list args;
  va_start(args, msg);
  vsnprintf(buffer, 1024, msg, args);
  va_end(args);
  xml->fatal(buffer);
}

};

#define INITIAL_CHUNK_SIZE  1024
#define MAX_CHUNK_SIZE      8192

struct XMLParser::parser_context {
  parser_context(XMLParser* _parser)
  {
    memset(&sax, 0, sizeof(xmlSAXHandler));
    sax.startDocument = (startDocumentSAXFunc)&saxStartDocument;
    sax.endDocument   = (endDocumentSAXFunc)&saxEndDocument;
    sax.startElement  = (startElementSAXFunc)&saxStartElement;
    sax.endElement    = (endElementSAXFunc)&saxEndElement;
    sax.characters    = (charactersSAXFunc)&saxCharacters;
    sax.comment       = (commentSAXFunc)&saxComment;
    sax.warning       = (warningSAXFunc)&saxWarning;
    sax.error         = (errorSAXFunc)&saxError;
    sax.fatalError    = (fatalErrorSAXFunc)&saxFatalError;
    
    parser = _parser;
    xml    = 0;
  }
  
  void parse(const char* buffer, int len)
  {
    if(!xml)
    {
      /*
        xmlCreatePushParserCtxt seems to have problems with initial chunks
        that are larger than 1024 byte :(
      */
      if(len >= INITIAL_CHUNK_SIZE)
      {
        xml = xmlCreatePushParserCtxt(&sax, parser, buffer, INITIAL_CHUNK_SIZE, "");
        buffer += INITIAL_CHUNK_SIZE;
        len    -= INITIAL_CHUNK_SIZE;
      }
      else
      {
        xml = xmlCreatePushParserCtxt(&sax, parser, buffer, len, "");
        len = 0;
      }
    }

    while(len > 0)
    {
      int bytes = (len > MAX_CHUNK_SIZE) ? (MAX_CHUNK_SIZE) : (len);
      xmlParseChunk(xml, buffer, bytes, 0);
      
      buffer += bytes;
      len    -= bytes;
    }
  }
  
  ~parser_context()
  {
    if(xml)
    {
      if(xml->myDoc)
        xmlFreeDoc(xml->myDoc);
        
      xmlFreeParserCtxt(xml);
    }
  }
  
  xmlSAXHandler    sax;
  xmlParserCtxtPtr xml;
  XMLParser*       parser;
};

XMLParser::XMLParser()
: m_context(new parser_context(this))
{
}

XMLParser::~XMLParser()
{
  delete m_context;
}

void XMLParser::reset()
{
  if(m_context->xml)
  {
    if(m_context->xml->myDoc)
      xmlFreeDoc(m_context->xml->myDoc);
      
    xmlFreeParserCtxt(m_context->xml);
    m_context->xml = 0;
  }
}

bool XMLParser::isWellFormed() const
{
  return (m_context->xml && m_context->xml->wellFormed) ? true : false;
}

void XMLParser::parse(const char* buffer, int len)
{
  m_context->parse(buffer, len);
}

void XMLParser::finish()
{
  if(m_context->xml)
  {
    char tmp[] = "";
    xmlParseChunk(m_context->xml, tmp, 0, 1);
  }
}

}
