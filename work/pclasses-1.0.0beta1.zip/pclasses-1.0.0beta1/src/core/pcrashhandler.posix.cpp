/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/config.h"
#include "pclasses/pcrashhandler.h"
#include "pclasses/pexception.h"
#include <stdexcept>

#ifdef HAVE_CXX_ABI_H
  #include <cxxabi.h>
#endif

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <fcntl.h>
#include <errno.h>
#include <stdarg.h>

namespace P {

using namespace std;

bool CrashHandler::m_enableDebug =
#ifdef _DEBUG
  true;
#else
  false;
#endif

class CrashHandlerInit {
  public:
    CrashHandlerInit()
    {
      set_terminate(CrashHandler::terminate);
      set_unexpected(CrashHandler::unexpected);
      signal(SIGSEGV, CrashHandler::SEGV_handler);
    }

    ~CrashHandlerInit()
    {}
};

static CrashHandlerInit _crashHandlerInit;
static int debug_dumpfd = -1;

static void debug_start_dump()
{
  pid_t pid = getpid();
  char dump_name[1024];
  sprintf(dump_name, "/tmp/crash-dump.%ld", (long)pid);
  debug_dumpfd = open(dump_name, O_WRONLY | O_CREAT | O_TRUNC, 0770);

  printf("Crash info dumped to: %s.\n", dump_name);
}

static void debug_printf(const char* msg, ...)
{
  char tmp[1024];
  va_list al;
  va_start(al, msg);
  vsnprintf(tmp, 1024, msg, al);
  write(debug_dumpfd, tmp, strlen(tmp));
  va_end(al);
}

static void debug_finish_dump()
{
  close(debug_dumpfd);
}

static bool exception_active()
{
  #if defined(HAVE_CXX_ABI_H)
  {
    return abi::__cxa_current_exception_type() != 0 ? true : false;
  }
  #else
  {
    return false;
  }
  #endif
}

static bool debug_print_active_exception()
{
  #if defined(HAVE_CXX_ABI_H)
  {
    type_info* t = abi::__cxa_current_exception_type();
    if(t)
    {
      char const* name = t->name();
      {
        int status = -1;
        char *dem = 0;
        dem = abi::__cxa_demangle(name, 0, 0, &status);
        debug_printf("%s", status == 0 ? dem : name);
        if(status == 0)
          free(dem);
      }
      return true;
    }
    return false;
  }
  #else
  {
    return false;
  }
  #endif
}

#ifndef __throw_exception_again
#define __throw_exception_again throw
#endif

static void debug_catch_active_exception()
{
  debug_printf("Exception info:\n");

  try { __throw_exception_again; }
  catch(SystemError& e)
  {
    const SourceInfo& si = e.sourceInfo();
    debug_printf("what: %s, system err#: %ld\n", e.what(), e.errnum());
    debug_printf("file: %s(%u), in '%s'\n", si.file(), si.line(), si.func());
  }
  catch(BaseError& e)
  {
    const SourceInfo& si = e.sourceInfo();
    debug_printf("what: %s\n", e.what());
    debug_printf("file: %s(%u), in '%s'\n", si.file(), si.line(), si.func());
  }
  catch(exception& e)
  {
    debug_printf("what: %s\n", e.what());
  }
  catch(const char* e)
  {
    debug_printf("what: %s\n", e);
  }
  catch (...) { }
}

static void debug_dump_backtrace()
{
  debug_printf("gdb dump:\n");

  pid_t parent_pid = getpid();

  char parent_pids[16];
  sprintf(parent_pids, "%ld", (long)parent_pid);

  // create a gdb script for dumping backtrace...
  const char* gdb_script = "info threads\nbt\nquit\n";

  char script_name[64];
  sprintf(script_name, "/tmp/gdb-script.%s", parent_pids);

  int fd = open(script_name, O_WRONLY | O_CREAT | O_TRUNC, 0770);
  write(fd, gdb_script, strlen(gdb_script));
  close(fd);

  // fork and execute the debugger ...
  pid_t child = fork();
  if(child == 0)
  {
    // redirect stdout to dump-filedescriptor
    dup2(debug_dumpfd, 1);
    close(debug_dumpfd);

    char* argv[8];
    argv[0] = "gdb";
    argv[1] = "--quiet";
    argv[2] = "--batch";
    argv[3] = "-x";
    argv[4] = script_name;
    argv[5] = "--pid";
    argv[6] = parent_pids;
    argv[7] = 0;

    execvp("gdb", argv);
    debug_printf("could not start debugger: %s.\n", strerror(errno));
    exit(1);
  }
  else if(child != -1)
  {
    int status = 0;
    waitpid(child, &status, 0);
  }
  else
  {
    debug_printf("could not fork to start debugger.\n");
  }

  unlink(script_name);
}

RETSIGTYPE CrashHandler::SEGV_handler(int sig) throw()
{
  signal(SIGSEGV, SIG_DFL);

  if(m_enableDebug)
  {
    debug_start_dump();
    debug_printf("Segmentation fault.\n");
    debug_dump_backtrace();
    debug_finish_dump();
  }

  raise(SIGSEGV);
}

void CrashHandler::terminate() throw()
{
  if(m_enableDebug)
  {
    debug_start_dump();

    if(exception_active())
    {
      debug_printf("termiated after throwing: ");
      debug_print_active_exception();
      debug_printf("\n");
      debug_catch_active_exception();
    }
    else
    {
      debug_printf("terminated with no active exception.\n");
    }

    debug_dump_backtrace();
    debug_finish_dump();
  }

  abort();
}

void CrashHandler::unexpected() throw()
{
  if(m_enableDebug)
  {
    debug_start_dump();

    if(exception_active())
    {
      debug_printf("unexpected exception caught: ");
      debug_print_active_exception();
      debug_printf("\n");
      debug_catch_active_exception();
    }
    else
    {
      debug_printf("unexpected exception caught.");
    }

    debug_dump_backtrace();
    debug_finish_dump();
  }

  abort();
}

void CrashHandler::enableDebugDump() throw()
{
  m_enableDebug = true;
}

void CrashHandler::disableDebugDump() throw()
{
  m_enableDebug = false;
}

bool CrashHandler::isDebugDumpEnabled() throw()
{
  return m_enableDebug;
}

}
