/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2002  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "private.h"

#ifdef WIN32
  #include <winsock2.h>
#else
  #include <sys/time.h>
  #ifdef HAVE_PTHREAD_GET_EXPIRATION_NP
    #include <pthread.h>
  #elif defined(HAVE_CLOCK_GETTIME)
    #include <time.h>
  #endif
#endif

namespace P {

#ifndef WIN32
timespec* get_timeout(struct timespec *spec, unsigned int timer, timeout_mode mode)
{
  static struct timespec myspec;
  if(!spec)
    spec = &myspec;

  if(mode == TIMEOUT_RELATIVE)
  {
    spec->tv_sec  = timer / 1000;
    spec->tv_nsec = (timer % 1000) * 1000000;
    return spec;
  }
    
  #ifdef HAVE_PTHREAD_GET_EXPIRATION_NP
  {
    struct timespec offset;
    offset.tv_sec = timer / 1000;
    offset.tv_nsec = (timer % 1000) * 1000000;
    pthread_get_expiration_np(&offset, spec);
  }
  #elif defined(HAVE_CLOCK_GETTIME)
  {
    clock_gettime(CLOCK_REALTIME, spec);
    spec->tv_sec += timer / 1000;
    spec->tv_nsec += (timer % 1000) * 1000000;
  }
  #else
  {
    struct timeval current;
    gettimeofday(&current, 0);
  
    spec->tv_sec = current.tv_sec + timer / 1000;
    spec->tv_nsec = (current.tv_usec + (timer % 1000) * 1000) * 1000;
  }
  #endif

  return spec;
}
#endif

#ifdef WIN32
void gettimeofday(struct timeval* val, void*)
{
  DWORD ticks = GetTickCount();
  val->tv_sec = ticks / 1000;
  val->tv_usec = (ticks % 1000) * 1000;
}
#endif

timeval* get_timeout(struct timeval *val, unsigned int timer, timeout_mode mode)
{
  if(mode == TIMEOUT_RELATIVE)
  {
    val->tv_sec  = timer / 1000;
    val->tv_usec = (timer % 1000) * 1000;
    return val;
  }

  struct timeval current;
  gettimeofday(&current, 0);

  val->tv_sec = current.tv_sec + timer / 1000;
  val->tv_usec = (current.tv_usec + (timer % 1000) * 1000);

  return val;
}

bool timeout_elapsed(struct timeval* val)
{
  struct timeval current;
  gettimeofday(&current, 0);
  if(current.tv_sec > val->tv_sec || (current.tv_sec == val->tv_sec && current.tv_usec > val->tv_usec))
    return true;
  return false;
}

}
