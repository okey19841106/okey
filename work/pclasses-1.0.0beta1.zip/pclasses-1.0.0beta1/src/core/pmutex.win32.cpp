/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/pmutex.h"
#include <windows.h>

namespace P {

struct Mutex::mutex_handle_t
{
  HANDLE handle;
};

Mutex::Mutex(const char* name /*=0*/) throw(SyncError)
{
  HANDLE handle = CreateMutex(NULL, FALSE, name);
  if(!handle)
    throw SyncError(GetLastError(), "Could not create mutex", P_SOURCEINFO);

  m_handle = new mutex_handle_t;
  m_handle->handle = handle;
}

Mutex::~Mutex() throw()
{
  CloseHandle(m_handle->handle);
  delete m_handle;
}

void Mutex::lock() throw(SyncError)
{
  DWORD ret = WaitForSingleObjectEx(m_handle->handle, INFINITE, FALSE);
  if(ret == 0xFFFFFFFF)
    throw SyncError(GetLastError(), "Could not wait for mutex", P_SOURCEINFO);
}

bool Mutex::tryLock(unsigned int timeout) throw(SyncError)
{
  DWORD ret = WaitForSingleObjectEx(m_handle->handle, timeout, FALSE);
  if(ret == 0xFFFFFFFF)
    throw SyncError(GetLastError(), "Could not wait for mutex", P_SOURCEINFO);
  else if(ret == WAIT_OBJECT_0)
    return true;
  return false;
}

void Mutex::unlock() throw(SyncError)
{
  if(!ReleaseMutex(m_handle->handle))
    throw SyncError(GetLastError(), "Could not release mutex", P_SOURCEINFO);
}

}
