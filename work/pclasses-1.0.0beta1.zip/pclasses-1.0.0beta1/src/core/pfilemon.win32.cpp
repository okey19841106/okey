/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/pfilemon.h"
#include "pclasses/pfile.h"

#include <windows.h>
#include <map>

namespace P {

using namespace std;

struct FileMonitor::file_monitor_handle_t {
  map<string, HANDLE> dirs;
};

FileMonitor::FileMonitor()
: m_handle(new file_monitor_handle_t)
{
}

FileMonitor::~FileMonitor()
{
  map<string,HANDLE>::const_iterator i = m_handle->dirs.begin();
  while(i != m_handle->dirs.end())
  {
    HANDLE handle = i->second;
    FindCloseChangeNotification(handle);
    ++i;
  }

  m_handle->dirs.clear();
  delete m_handle;
}

void FileMonitor::addDir(const char* path)
{
  // make sure name is a directory...
  if(File::stat(path).type() != FileInfo::Directory)
    throw LogicError("Path is not a directory", P_SOURCEINFO);

  if(isMonitored(path))
    return;

  HANDLE handle = FindFirstChangeNotification(path, FALSE, FILE_NOTIFY_CHANGE_FILE_NAME |
                                                          FILE_NOTIFY_CHANGE_DIR_NAME |
                                                          FILE_NOTIFY_CHANGE_ATTRIBUTES |
                                                          FILE_NOTIFY_CHANGE_SIZE |
                                                          FILE_NOTIFY_CHANGE_LAST_WRITE |
                                                          FILE_NOTIFY_CHANGE_SECURITY);
                                                          
  if(handle == INVALID_HANDLE_VALUE)
    throw IOError(GetLastError(), "Could not register for file change notification", P_SOURCEINFO);

  m_handle->dirs[path] = handle;
}

void FileMonitor::removeDir(const char* path)
{
  map<string,HANDLE>::iterator i = m_handle->dirs.find(path);
  if(i != m_handle->dirs.end())
  {
    HANDLE handle = i->second;
    FindCloseChangeNotification(handle);
    m_handle->dirs.erase(i);
  }
}

bool FileMonitor::isMonitored(const char* path) const
{
  return (m_handle->dirs.find(path) != m_handle->dirs.end() ? true : false);
}

bool FileMonitor::wait(Event& evt, unsigned int timeout)
{
  int i = 0;
  int hcount = m_handle->dirs.size();
  HANDLE* handles = new HANDLE[hcount];

  map<string,HANDLE>::const_iterator ci = m_handle->dirs.begin();
  for(i = 0; i < hcount; i++, ci++)
    handles[i] = ci->second;

  DWORD ret = WaitForMultipleObjectsEx(hcount, handles, FALSE, timeout, FALSE);
  delete[] handles;

  switch(ret)
  {
    case WAIT_FAILED:
      throw IOError(GetLastError(), "Could not wait for change event", P_SOURCEINFO);
    
    case WAIT_TIMEOUT:
      return false;
        
    default:
      break;
  }

  for(ci = m_handle->dirs.begin(); ci != m_handle->dirs.end(); ci++)
  {
    BOOL notified = FindNextChangeNotification(ci->second);
    if(notified)
    {
      string path = ci->first;
      cout << path << " changed." << endl;
    }
  }

  return true;
}

}
