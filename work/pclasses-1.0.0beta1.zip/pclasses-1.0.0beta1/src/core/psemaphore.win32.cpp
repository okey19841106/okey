/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/psemaphore.h"
#include <windows.h>

#define MAX_SEM_VALUE  LONG_MAX

namespace P {

struct Semaphore::sem_handle_t {
  HANDLE handle;
};

Semaphore::Semaphore(const char* name, unsigned int initial) throw(SyncError)
{
  HANDLE handle = CreateSemaphore(NULL, initial, MAX_SEM_VALUE, name);
  if(!handle)
    throw SyncError(GetLastError(), "Could not create semaphore", P_SOURCEINFO);

  m_handle = new sem_handle_t;
  m_handle->handle = handle;
}

Semaphore::~Semaphore() throw(SyncError)
{
  CloseHandle(m_handle->handle);
  delete m_handle;
}

void Semaphore::wait() throw(SyncError)
{
  DWORD ret = WaitForSingleObjectEx(m_handle->handle, INFINITE, FALSE);
  if(ret == 0xFFFFFFFF)
    throw SyncError(GetLastError(), "Could not decrease semaphore count", P_SOURCEINFO);
}

bool Semaphore::tryWait() throw(SyncError)
{
  DWORD ret = WaitForSingleObjectEx(m_handle->handle, 0, FALSE);
  if(ret == 0xFFFFFFFF)
    throw SyncError(GetLastError(), "Could not decrease semaphore count", P_SOURCEINFO);
  else if(ret == WAIT_OBJECT_0)
    return true;
  return false;
}

void Semaphore::post() throw(SyncError)
{
  if(!ReleaseSemaphore(m_handle->handle, 1, NULL))
    throw SyncError(GetLastError(), "Could not increase semaphore count", P_SOURCEINFO);
}

}
