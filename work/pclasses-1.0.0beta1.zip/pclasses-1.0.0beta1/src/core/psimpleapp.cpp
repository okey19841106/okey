/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/psimpleapp.h"

#ifdef WIN32
  #include <windows.h>
  #include <signal.h>
#else
  #include <signal.h>
  #include <errno.h>
#endif

namespace P {

SimpleApp* SimpleApp::m_theApp = 0;

SimpleApp::SimpleApp(const AboutData& about)
: m_exitCode(0), m_about(about)
{
  m_theApp = this;
}
 
SimpleApp::~SimpleApp()
{
  m_theApp = 0;
}

int SimpleApp::run(int argc, char* argv[])
{
  int ret = init(argc, argv);
  if(!ret)
  {
    ret = main();
    cleanup();
  }
  
  return ret;
} 

int SimpleApp::init(int argc, char* argv[])
{
  #ifdef WIN32
  {
    //SetConsoleCtrlHandler((PHANDLER_ROUTINE)SIGTERM_handler, TRUE);
    signal(SIGTERM, &SIGTERM_handler);
    signal(SIGINT, &SIGTERM_handler);
  }
  #else
  {
    signal(SIGTERM, &SIGTERM_handler);
    signal(SIGQUIT, &SIGTERM_handler);
    signal(SIGINT, &SIGTERM_handler);
  }
  #endif
  return 0;
}

int SimpleApp::main()
{
  m_exitSem.wait();
  return m_exitCode;
}

void SimpleApp::stop(int code)
{
  m_exitCode = code;
  m_exitSem.post();
}

void SimpleApp::terminate(int signal)
{
  stop(1);
}

RETSIGTYPE SimpleApp::SIGTERM_handler(int sig)
{
  #ifdef WIN32
  {
    m_theApp->terminate(sig);
  }
  #else
  {
    if(sig == SIGTERM || sig == SIGQUIT || sig == SIGINT)
    {
      signal(sig, SIG_IGN);
      m_theApp->terminate(sig);
      signal(sig, &SIGTERM_handler);
    }
  }
  #endif
}

SimpleApp* theApp() throw()
{
  return SimpleApp::m_theApp;
}

}
