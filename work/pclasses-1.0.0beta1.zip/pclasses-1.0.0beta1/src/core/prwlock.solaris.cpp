/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/config.h"
#include "pclasses/prwlock.h"
#include "pclasses/pthread_.h"
#include "private.h"

#include <errno.h>
#include <synch.h>

#ifdef HAVE_SYSV_SHAREDMEM
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#endif

namespace P {

struct RWLock::rwlock_handle_t
{
  rwlock_t      rwlock;
  int           shmid;
  unsigned int  refcount;
};

RWLock::RWLock(const char* name /*=0*/) throw(SyncError)
{
  int type = 0;

  if(name)
  {
    #if defined(HAVE_SYSV_SHAREDMEM)
    key_t shmkey = ftok(name, 0);

    int shmid = shmget(shmkey, sizeof(rwlock_handle_t), IPC_CREAT);
    if(shmid == -1)
      throw SyncError(errno, "Could not get shared memory segment", P_SOURCEINFO);

    m_handle = (rwlock_handle_t*)shmat(shmid, 0, 0);
    m_handle->shmid    = shmid;
    m_handle->refcount = 1;
    #else
    throw SyncError(0, "Process shared rwlock's not supported", P_SOURCEINFO);
    #endif

    type = USYNC_PROCESS;
  }
  else
  {
    m_handle = new rwlock_handle_t;
    m_handle->shmid    = -1;
    m_handle->refcount = 1;

    type = USYNC_THREAD;
  }

  int ret = rwlock_init(&m_handle->rwlock, type, 0);
  if(ret != 0)
    throw SyncError(ret, "Could not init read-write lock", P_SOURCEINFO);
}

RWLock::~RWLock() throw()
{
  if((--m_handle->refcount) == 0)
    rwlock_destroy(&m_handle->rwlock);

  #ifdef HAVE_SYSV_SHAREDMEM
  if(m_handle->shmid != -1)
  {
    if(!m_handle->refcount)
      shmctl(m_handle->shmid,IPC_RMID,0);

    shmdt((void*)m_handle);
  }
  else
  #endif
    delete m_handle;
}

void RWLock::readLock() throw(SyncError)
{
  int ret = rw_rdlock(&m_handle->rwlock);
  if(ret != 0)
    throw SyncError(ret, "Could not read-lock read-write lock", P_SOURCEINFO);
}

bool RWLock::tryReadLock(unsigned int timeout) throw(SyncError)
{
  int ret;
  if(!timeout)
  {
    ret = rw_tryrdlock(&m_handle->rwlock);
  }
  else
  {
    struct timeval tv;
    get_timeout(&tv, timeout, TIMEOUT_ABSOLUTE);
    while(1)
    {
      ret = rw_tryrdlock(&m_handle->rwlock);
      if((ret != EBUSY && ret != ETIMEDOUT) || timeout_elapsed(&tv))
        break;

      Thread::yield();
    }
  }

  switch(ret)
  {
    case 0:
      break;

    case EBUSY:
    case ETIMEDOUT:
      return false;

    default:
      throw SyncError(ret, "Could not read-lock read-write lock", P_SOURCEINFO);
  }

  return true;
}

void RWLock::writeLock() throw(SyncError)
{
  int ret = rw_wrlock(&m_handle->rwlock);
  if(ret != 0)
    throw SyncError(ret, "Could not write-lock read-write lock", P_SOURCEINFO);
}

bool RWLock::tryWriteLock(unsigned int timeout) throw(SyncError)
{
  int ret;
  if(!timeout)
  {
    ret = rw_trywrlock(&m_handle->rwlock);
  }
  else
  {
    struct timeval tv;
    get_timeout(&tv, timeout, TIMEOUT_ABSOLUTE);
    while(1)
    {
      ret = rw_trywrlock(&m_handle->rwlock);
      if((ret != EBUSY && ret != ETIMEDOUT) || timeout_elapsed(&tv))
        break;

      Thread::yield();
    }
  }

  switch(ret)
  {
    case 0:
      break;

    case EBUSY:
    case ETIMEDOUT:
      return false;

    default:
      throw SyncError(ret, "Could not write-lock read-write lock", P_SOURCEINFO);
  }

  return true;
}

void RWLock::unlock() throw(SyncError)
{
  int ret = rw_unlock(&m_handle->rwlock);
  if(ret != 0)
    throw SyncError(ret, "Could not unlock read-write lock", P_SOURCEINFO);
}

}
