/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/config.h"
#include "pclasses/psemaphore.h"
#include <errno.h>

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <synch.h>

#if !defined(HAVE_SYSV_SEMUN)
/* according to X/OPEN we have to define it ourselves */
union semun {
      int val;                  /* value for SETVAL */
      struct semid_ds *buf;     /* buffer for IPC_STAT, IPC_SET */
      unsigned short *array;    /* array for GETALL, SETALL */
                                /* Linux specific part: */
      struct seminfo *__buf;    /* buffer for IPC_INFO */
};
#endif

namespace P {

enum sem_handle_type {
  SEM_HANDLE_SOLARIS,
  SEM_HANDLE_SYSV
};

struct Semaphore::sem_handle_t {
  sem_handle_type type;
  union {
    int semid;
    sema_t semaphore;
  };
};

Semaphore::Semaphore(const char* name, unsigned int initial) throw(SyncError)
{
  union semun arg;
  int semid, ret;

  if(!name)
  {
    /* we preffer process local solaris semaphores when using
      unnamed semaphores */
    m_handle = new sem_handle_t;
    m_handle->type = SEM_HANDLE_SOLARIS;

    ret = sema_init(&m_handle->semaphore, initial, USYNC_THREAD, 0);
    if(ret != 0)
    {
      delete m_handle;
      throw SyncError(ret, "Could not create semaphore", P_SOURCEINFO);
    }
  }
  else
  {
    key_t semkey = ftok(name, 0);

    semid = semget(semkey, 1, IPC_CREAT | IPC_EXCL);
    if(semid != -1)
    {
      arg.val = initial;
      if(semctl(semid, 0, SETVAL, arg) == -1)
      {
        semctl(semid, 0, IPC_RMID, arg);
        throw SyncError(errno, "Could not control semaphore", P_SOURCEINFO);
      }
    }
    else
    {
      if((semid = semget(semkey, 1, IPC_CREAT)) == -1)
        throw SyncError(errno, "Could not get semaphore", P_SOURCEINFO);
    }

    m_handle = new sem_handle_t;
    m_handle->type  = SEM_HANDLE_SYSV;
    m_handle->semid = semid;
  }
}

Semaphore::~Semaphore() throw(SyncError)
{
  switch(m_handle->type)
  {
    case SEM_HANDLE_SYSV:
      union semun arg;
      semctl(m_handle->semid, 0, IPC_RMID, arg);
      break;

    case SEM_HANDLE_SOLARIS:
      {
        int ret = sem_destroy(&m_handle->semaphore);
        if(ret != 0)
          throw SyncError(ret, "Could not destroy semaphore", P_SOURCEINFO);
      }
      break;
  }

  delete m_handle;
}

void Semaphore::wait() throw(SyncError)
{
  switch(m_handle->type)
  {
    case SEM_HANDLE_SYSV:
      {
        struct sembuf ops[] = {{0, -1, 0}};
        _semwait_sysv:
        if(semop(m_handle->semid, ops, 1) == -1)
        {
          if(errno == EINTR)
            goto _semwait_sysv;
          throw SyncError(errno, "Could not decrease semaphore count", P_SOURCEINFO);
        }
      }
      break;

    case SEM_HANDLE_SOLARIS:
      {
        int ret;
        _semwait_solaris:
        ret = sema_wait(&m_handle->semaphore);
        if(ret == EINTR)
          goto _semwait_solaris;
        else if(ret != 0)
          throw SyncError(ret, "Could not decrease semaphore count", P_SOURCEINFO);
      }
      break;
  }
}

bool Semaphore::tryWait() throw(SyncError)
{
  bool ret;

  switch(m_handle->type)
  {
    case SEM_HANDLE_SYSV:
      {
        struct sembuf ops[] = {{0, -1, IPC_NOWAIT}};
        _semtrywait:

        int semret = semop(m_handle->semid, ops, 1);
        switch(semret)
        {
          case 0:
            ret = true;
            break;

          case EAGAIN:
            ret = false;
            break;

          case EINTR:
            goto _semtrywait;
        }

        throw SyncError(errno, "Could not decrease semaphore count", P_SOURCEINFO);
      }
      break;

    case SEM_HANDLE_SOLARIS:
      {
        int sret = sema_trywait(&m_handle->semaphore);
        switch(sret)
        {
          case 0:
            ret = true;
            break;

          case EBUSY:
            ret = false;
            break;

          default:
            throw SyncError(sret, "Could not decrease semaphore count", P_SOURCEINFO);
        }
      }
      break;
  }

  return ret;
}

void Semaphore::post() throw(SyncError)
{
  switch(m_handle->type)
  {
    case SEM_HANDLE_SYSV:
      {
        struct sembuf ops[] = {{0, 1, 0}};
        _sempost_sysv:
        if(semop(m_handle->semid, ops, 1) == -1)
        {
          if(errno == EINTR)
            goto _sempost_sysv;
          throw SyncError(errno, "Could not increase semaphore count", P_SOURCEINFO);
        }
      }
      break;

    case SEM_HANDLE_SOLARIS:
      {
        int semret;
        _sempost_solaris:
        semret = sema_post(&m_handle->semaphore);
        if(semret != 0)
        {
          if(semret == EINTR)
            goto _sempost_solaris;
          throw SyncError(semret, "Could not increase semaphore count", P_SOURCEINFO);
        }
      }
      break;
  }
}

}
