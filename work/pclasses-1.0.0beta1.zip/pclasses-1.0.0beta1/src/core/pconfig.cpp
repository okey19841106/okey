/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/pconfig.h"
#include "pclasses/pconfigstore.h"

namespace P {

using namespace std;

Config::Config(ConfigStore& store)
: m_modified(false), m_store(store), m_root(Key(this, ""))
{
  store.read(m_root);
  m_modified = false;
}

Config::~Config()
{
  save();
}

void Config::reload()
{
  m_store.read(m_root);
  m_modified = false;
}

void Config::save()
{
  if(m_modified)
  {
    m_store.update(m_root);
    m_modified = false;
  }
}

Config::Key::~Key()
{
  for(key_map::const_iterator i = m_keys.begin();
      i != m_keys.end(); i++)
  {
    delete i->second;
  }
}
        
Config::Key::Key(Config* cfg, const string& name)
: m_cfg(cfg), m_name(name) 
{}

const string& Config::Key::value(const string& name, const string& def)
{
  value_map::const_iterator i = m_values.find(name);
  if(i != m_values.end())
    return i->second;
    
  return def;
}

void Config::Key::setValue(const string& name, const string& value)
{
  m_values.insert(make_pair(name, value));
  m_cfg->m_modified = true;
}

void Config::Key::removeValue(const string& name)
{
  m_values.erase(name);
  m_cfg->m_modified = true;
}

Config::Key* Config::Key::key(const string& name)
{
  key_map::const_iterator i = m_keys.find(name);
  if(i != m_keys.end())
    return i->second;
    
  return 0;
}

Config::Key* Config::Key::addKey(const string& name)
{
  Key* k = new Key(m_cfg, name);
  m_keys.insert(make_pair(name, k));
  m_cfg->m_modified = true;
  return k;
}

void Config::Key::removeKey(const string& name)
{
  pair<key_map::iterator, key_map::iterator> mi = m_keys.equal_range(name);
  for(key_map::iterator i = mi.first; i != mi.second; ++i)
    delete i->second;

  if(distance(mi.first, mi.second) > 0)
  {
    m_keys.erase(mi.first, mi.second);
    m_cfg->m_modified = true;
  }
}

}
