/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/config.h"
#include "pclasses/pexception.h"
#include "pclasses/pcriticalsection.h"

#include <string.h>

namespace P {

using namespace std;

string SystemError::text() const throw()
{
  #ifdef HAVE_STRERROR_R
  //@todo need autoconf check for char* rettype from strerror_r
  char buffer[4096];
  char* ret = strerror_r(m_errnum, buffer, sizeof(buffer));
  return string(ret);
  #else
  static CriticalSection errcs;
  CriticalSection::Lock l(errcs);
  return string(strerror(m_errnum));
  #endif
}

}
