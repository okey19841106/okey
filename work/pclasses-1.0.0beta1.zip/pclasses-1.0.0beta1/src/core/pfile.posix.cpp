/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/config.h"
#include "pclasses/pfile.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>

#if defined(HAVE_LARGEFILE64) && !defined(HAVE_OPEN64)
  #define open64       open
  #define ftruncate64  ftruncate
  #define fstat64      fstat
  #define stat64       stat
#endif

namespace P {

using namespace std;

void File::open(const char* path, accessMode_t amode, openMode_t omode, 
                createMode_t cmode, shareMode_t smode) throw(IOError)
{
  if(isValid())
    close();

  int flags = 0;
  switch(amode)
  {
    case Write:
      flags |= O_WRONLY;
      break;

    case ReadWrite:
      flags |= O_RDWR;
      break;

    case Read:
    default:
      flags |= O_RDONLY;
      break;
  }

  switch(omode)
  {
    case Append:
      flags |= O_APPEND;
      break;

    case Truncate:
      flags |= O_TRUNC;
      break;

    case Normal:
    default:
      break;
  }

  switch(cmode)
  {
    case OpenCreate:
      flags |= O_CREAT;
      break;

    case CreateFail:
      flags |= O_CREAT | O_EXCL;
      break;

    case OpenExisting:
    default:
      break;
  }

  io_handle_t handle = 
  #ifndef HAVE_OPEN64
    ::open(path, flags, 0644);
  #else
    ::open64(path, flags, 0644);
  #endif
  
  if(handle != -1)
  {
    m_path       = path;
    m_accessMode = amode;
    m_openMode   = omode;
    m_createMode = cmode;
    m_shareMode  = smode;
    setHandle(handle);
    return;
  }

  throw IOError(errno, "Could not open file", P_SOURCEINFO);
}

#ifndef HAVE_LARGEFILE64

void File::truncate(off_t offset) throw(IOError)
{
  int ret = ftruncate(handle(), offset);
  if(ret == 0)
  {
    seek(offset, seekSet);
    return;
  }

  throw IOError(errno, "Could not truncate file", P_SOURCEINFO);
}

off_t File::size() throw(IOError)
{
  struct stat stb;
  int ret = fstat(handle(), &stb);
  if(ret == 0)
    return stb.st_size;

  throw IOError(errno, "Could not stat file descriptor", P_SOURCEINFO);
}

#else /* HAVE_LARGEFILE64 */

void File::truncate(off64_t offset) throw(IOError)
{
  int ret = ftruncate64(handle(), offset);
  if(ret == 0)
  {
    seek(offset, seekSet);
    return;
  }

  throw IOError(errno, "Could not truncate file", P_SOURCEINFO);
}

off64_t File::size() throw(IOError)
{
  struct stat64 stb;
  int ret = fstat64(handle(), &stb);
  if(ret == 0)
    return stb.st_size;

  throw IOError(errno, "Could not stat file descriptor", P_SOURCEINFO);
}

#endif /* HAVE_LARGEFILE64 */

void File::unlink(const char* path) throw(IOError)
{
  if(::unlink(path) == -1)
    throw IOError(errno, "Could not unlink file", P_SOURCEINFO);
}

bool File::exists(const char* path) throw()
{
  return ::access(path, F_OK) ? false : true;
}

File File::mktemp(const char* prefix) throw(IOError)
{
  int len = strlen(prefix);
  char* tempnam = new char[len+7];

  strcpy(tempnam, prefix);
  strcpy(tempnam + len, "XXXXXX");

  io_handle_t handle = ::mkstemp(tempnam);
  delete[] tempnam;

  if(handle == -1)
    throw IOError(errno, "Could not create temporary file", P_SOURCEINFO);

  File f;
  f.setHandle(handle);

  return f;
}

}
