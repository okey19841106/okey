/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/config.h"
#include "pclasses/psemaphore.h"
#include <errno.h>

#ifdef HAVE_SYSV_SEMAPHORES
  #include <sys/types.h>
  #include <sys/ipc.h>
  #include <sys/sem.h>
#endif

#ifdef HAVE_POSIX_SEMAPHORES
  #include <semaphore.h>
#endif

#if !defined(HAVE_SYSV_SEMUN)
/* according to X/OPEN we have to define it ourselves */
union semun {
      int val;                  /* value for SETVAL */
      struct semid_ds *buf;     /* buffer for IPC_STAT, IPC_SET */
      unsigned short *array;    /* array for GETALL, SETALL */
                                /* Linux specific part: */
      struct seminfo *__buf;    /* buffer for IPC_INFO */
};
#endif

namespace P {

enum sem_handle_type {
  SEM_HANDLE_POSIX,
  SEM_HANDLE_SYSV
};

struct Semaphore::sem_handle_t {
  sem_handle_type type;
  union {
    #ifdef HAVE_SYSV_SEMAPHORES
    int semid;
    #endif
    #ifdef HAVE_POSIX_SEMAPHORES
    sem_t semaphore;
    #endif
  };
};

Semaphore::Semaphore(const char* name, unsigned int initial) throw(SyncError)
{
  #ifdef HAVE_SYSV_SEMAPHORES
  {
    union semun arg;
    int semid;

    if(!name)
    {
      /* we preffer process local posix semaphores when using 
        unnamed semaphores */
      #ifdef HAVE_POSIX_SEMAPHORES
      {
        m_handle = new sem_handle_t;
        m_handle->type = SEM_HANDLE_POSIX;

        if(sem_init(&m_handle->semaphore, 0, initial) == -1)
        {
          delete m_handle;
          throw SyncError(errno, "Could not create semaphore", P_SOURCEINFO);
        }
      }
      /* otherwise we create a private SYSV semaphore */
      #else
      {
        if((semid = semget(IPC_PRIVATE, 1, 0644 | IPC_CREAT)) == -1)
          throw SyncError(errno, "Could not get semaphore", P_SOURCEINFO);

        arg.val = initial;
        if(semctl(semid, 0, SETVAL, arg) == -1)
        {
          semctl(semid, 0, IPC_RMID, arg);
          throw SyncError(errno, "Could not control semaphore", P_SOURCEINFO);
        }
        
        m_handle = new sem_handle_t;
        m_handle->type  = SEM_HANDLE_SYSV;
        m_handle->semid = semid;
      }
      #endif
    }
    else
    {
      key_t semkey = ftok(name, 0);
      
      semid = semget(semkey, 1, IPC_CREAT | IPC_EXCL);
      if(semid != -1)
      {
        arg.val = initial;
        if(semctl(semid, 0, SETVAL, arg) == -1)
        {
          semctl(semid, 0, IPC_RMID, arg);
          throw SyncError(errno, "Could not control semaphore", P_SOURCEINFO);
        }
      }
      else
      {
        if((semid = semget(semkey, 1, IPC_CREAT)) == -1)
          throw SyncError(errno, "Could not get semaphore", P_SOURCEINFO);
      }

      m_handle = new sem_handle_t;
      m_handle->type  = SEM_HANDLE_SYSV;
      m_handle->semid = semid;
    }
  }
  #elif defined(HAVE_POSIX_SEMAPHORES)
  {
    if(name)
      throw SyncError(errno, "Process-shared semaphores are not supported", P_SOURCEINFO);

    m_handle = new sem_handle_t;
    m_handle->type = SEM_HANDLE_POSIX;
    
    if(sem_init(&m_handle->semaphore, 0, initial) == -1)
    {
      delete m_handle;
      throw SyncError(errno, "Could not create semaphore", P_SOURCEINFO);
    }
  }
  #else
    #error no sempahore support available
  #endif
}

Semaphore::~Semaphore() throw(SyncError)
{
  switch(m_handle->type)
  {
    #ifdef HAVE_SYSV_SEMAPHORES
    case SEM_HANDLE_SYSV:
      union semun arg;
      semctl(m_handle->semid, 0, IPC_RMID, arg);
      break;
    #endif

    #ifdef HAVE_POSIX_SEMAPHORES
    case SEM_HANDLE_POSIX:
      if(sem_destroy(&m_handle->semaphore) == -1)
        throw SyncError(errno, "Could not destroy semaphore", P_SOURCEINFO);
      break;
    #endif
  }

  delete m_handle;
}

void Semaphore::wait() throw(SyncError)
{
  switch(m_handle->type)
  {
    #ifdef HAVE_SYSV_SEMAPHORES
    case SEM_HANDLE_SYSV:
      {
        struct sembuf ops[] = {{0, -1, 0}};
        _semwait:
        if(semop(m_handle->semid, ops, 1) == -1)
        {
          if(errno == EINTR)
            goto _semwait;
          throw SyncError(errno, "Could not decrease semaphore count", P_SOURCEINFO);
        }
      }
      break;
    #endif

    #ifdef HAVE_POSIX_SEMAPHORES
    case SEM_HANDLE_POSIX:
      sem_wait(&m_handle->semaphore);
      break;
    #endif
  }
}

bool Semaphore::tryWait() throw(SyncError)
{
  bool ret;

  switch(m_handle->type)
  {
    #ifdef HAVE_SYSV_SEMAPHORES
    case SEM_HANDLE_SYSV:
      {
        struct sembuf ops[] = {{0, -1, IPC_NOWAIT}};
        _semtrywait:

        int semret = semop(m_handle->semid, ops, 1);
        switch(semret)
        {
          case 0:
            ret = true;
            break;

          case EAGAIN:
            ret = true;
            break;

          case EINTR:
            goto _semtrywait;
        }

        throw SyncError(errno, "Could not decrease semaphore count", P_SOURCEINFO);
      }
      break;
    #endif

    #ifdef HAVE_POSIX_SEMAPHORES
    case SEM_HANDLE_POSIX:
      ret = (sem_trywait(&m_handle->semaphore) == 0) ? true : false;
      break;
    #endif
  }

  return ret;
}

void Semaphore::post() throw(SyncError)
{
  switch(m_handle->type)
  {
    #ifdef HAVE_SYSV_SEMAPHORES
    case SEM_HANDLE_SYSV:
      {
        struct sembuf ops[] = {{0, 1, 0}};
        _sempost_sysv:
        if(semop(m_handle->semid, ops, 1) == -1)
        {
          if(errno == EINTR)
            goto _sempost_sysv;
          throw SyncError(errno, "Could not increase semaphore count", P_SOURCEINFO);
        }
      }
      break;
    #endif

    #ifdef HAVE_POSIX_SEMAPHORES
    case SEM_HANDLE_POSIX:
      {
        _sempost_posix:
        if(sem_post(&m_handle->semaphore) == -1)
        {
          if(errno == EINTR)
            goto _sempost_posix;
          throw SyncError(errno, "Could not increase semaphore count", P_SOURCEINFO);
        }
      }
      break;
    #endif
  }
}

}
