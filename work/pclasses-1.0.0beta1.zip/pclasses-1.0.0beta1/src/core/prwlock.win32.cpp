/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/prwlock.h"
#include "pclasses/pthread_.h"
#include <windows.h>

namespace P {

struct RWLock::rwlock_handle_t
{
  HANDLE handle;
};


RWLock::RWLock(const char* name /*=0*/) throw(SyncError)
{
  HANDLE handle = CreateMutex(NULL, FALSE, name);
  if(!handle)
    throw SyncError(GetLastError(), "Could not create read-write lock mutex", P_SOURCEINFO);

  m_handle = new rwlock_handle_t;
  m_handle->handle = handle;
}

RWLock::~RWLock() throw()
{
  CloseHandle(m_handle->handle);
  delete m_handle;
}

void RWLock::readLock() throw(SyncError)
{
  DWORD ret = WaitForSingleObjectEx(m_handle->handle, INFINITE, FALSE);
  if(ret == 0xFFFFFFFF)
    throw SyncError(GetLastError(), "Could not read-lock read-write lock", P_SOURCEINFO);
}

bool RWLock::tryReadLock(unsigned int timeout) throw(SyncError)
{
  DWORD ret = WaitForSingleObjectEx(m_handle->handle, timeout, FALSE);
  if(ret == 0xFFFFFFFF)
    throw SyncError(GetLastError(), "Could not read-lock read-write lock", P_SOURCEINFO);
  else if(ret == WAIT_OBJECT_0)
    return true;
  return false;
}

void RWLock::writeLock() throw(SyncError)
{
  DWORD ret = WaitForSingleObjectEx(m_handle->handle, INFINITE, FALSE);
  if(ret == 0xFFFFFFFF)
    throw SyncError(GetLastError(), "Could not write-lock read-write lock", P_SOURCEINFO);
}

bool RWLock::tryWriteLock(unsigned int timeout) throw(SyncError)
{
  DWORD ret = WaitForSingleObjectEx(m_handle->handle, timeout, FALSE);
  if(ret == 0xFFFFFFFF)
    throw SyncError(GetLastError(), "Could not write-lock read-write lock", P_SOURCEINFO);
  else if(ret == WAIT_OBJECT_0)
    return true;
  return false;
}

void RWLock::unlock() throw(SyncError)
{
  if(!ReleaseMutex(m_handle->handle))
    throw SyncError(GetLastError(), "Could not unlock read-write lock", P_SOURCEINFO);
}

}
