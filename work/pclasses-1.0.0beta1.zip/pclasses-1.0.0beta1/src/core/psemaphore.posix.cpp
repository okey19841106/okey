/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/config.h"
#include "pclasses/psemaphore.h"
#include <fcntl.h>
#include <semaphore.h>
#include <string.h>
#include <errno.h>

namespace P {

struct Semaphore::sem_handle_t
{
  sem_t* semaphore;
  char* name;
  bool creator;
};

Semaphore::Semaphore(const char* name, unsigned int initial) throw(SyncError)
{
  m_handle = new sem_handle_t;

  if(name)
  {
    #ifndef HAVE_SEM_OPEN
    delete m_handle;
    throw SyncError(errno, "Named semaphores are not supported", P_SOURCEINFO);
    #endif

    sem_t* sem;
    int flags = O_CREAT|O_EXCL;

    _sem_open:
    sem = sem_open(name, flags, 0, initial);
    if(sem == SEM_FAILED)
    {
      if(errno != EEXIST)
      {
        delete m_handle;
        throw SyncError(errno, "Could not open named semaphore", P_SOURCEINFO);
      }

      if(!flags)
        flags = O_CREAT|O_EXCL;
      else
        flags = 0;

      goto _sem_open;
    }

    m_handle->semaphore = sem;
    m_handle->name      = strdup(name);
    m_handle->creator   = (flags == O_CREAT|O_EXCL);
  }
  else
  {
    m_handle->name = 0;
    m_handle->semaphore = new sem_t;

    if(sem_init(m_handle->semaphore, 0, initial) == -1)
    {
      delete m_handle->semaphore;
      delete m_handle;

      throw SyncError(errno, "Could not create semaphore", P_SOURCEINFO);
    }
  }
}

Semaphore::~Semaphore() throw(SyncError)
{
  if(m_handle->name)
  {
    if(sem_close(m_handle->semaphore) == -1)
      throw SyncError(errno, "Could not close semaphore", P_SOURCEINFO);

    // if we have created the semaphore, unlink it
    if(m_handle->creator)
      sem_unlink(m_handle->name);

    free(m_handle->name);
  }
  else
  {
    if(sem_destroy(m_handle->semaphore) == -1)
      throw SyncError(errno, "Could not destroy semaphore", P_SOURCEINFO);

    delete m_handle->semaphore;
  }

  delete m_handle;
}

void Semaphore::wait() throw(SyncError)
{
  sem_wait(m_handle->semaphore);
}

bool Semaphore::tryWait() throw(SyncError)
{
  return (sem_trywait(m_handle->semaphore) == 0) ? true : false;
}

void Semaphore::post() throw(SyncError)
{
  _sempost_posix:
  if(sem_post(m_handle->semaphore) == -1)
  {
    if(errno == EINTR)
      goto _sempost_posix;

    throw SyncError(errno, "Could not increase semaphore count", P_SOURCEINFO);
  }
}

}
