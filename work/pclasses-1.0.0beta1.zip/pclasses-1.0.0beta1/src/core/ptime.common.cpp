/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/ptime.h"
#include <iomanip>
#include <string.h>

namespace P {

using namespace std;

#define CHECK_OVERFLOW(num, add) \
  { \
    if(add > (2 ^ (sizeof(num) * 8) - num)) \
      throw OverflowError(P_SOURCEINFO); \
  }

TimeSpan::TimeSpan(unsigned int days, unsigned int hours, unsigned int minutes,
                   unsigned int seconds, unsigned int usecs) throw(OverflowError)
: m_days(days), m_hours(hours), m_minutes(minutes), m_seconds(seconds), m_usecs(usecs)
{
  normalize();
}
    
TimeSpan::~TimeSpan() throw()
{
}

void TimeSpan::setDays(unsigned int days) throw(OverflowError)
{
  m_days = days;
}

unsigned int TimeSpan::days() const throw()
{
  return m_days;
}
    
void TimeSpan::setHours(unsigned int hours) throw(OverflowError)
{
  m_hours = hours;
  if(hours > 23)
    normalize();
}

unsigned int TimeSpan::hours() const throw()
{
  return m_hours;
}

void TimeSpan::setMinutes(unsigned int minutes) throw(OverflowError)
{
  m_minutes = minutes;
  if(minutes > 59)
    normalize();
}

unsigned int TimeSpan::minutes() const throw()
{
  return m_minutes;
}

void TimeSpan::setSeconds(unsigned int seconds) throw(OverflowError)
{
  m_seconds = seconds;
  if(seconds > 59)
    normalize();
}

unsigned int TimeSpan::seconds() const throw()
{
  return m_seconds;
}

void TimeSpan::setUsecs(unsigned int usec) throw(OverflowError)
{
  m_usecs = usec;
  if(usec > ((1000 * 1000) - 1))
    normalize();
}

unsigned int TimeSpan::usecs() const throw()
{
  return m_usecs;
}

void TimeSpan::normalize() throw(OverflowError)
{
  if(m_usecs > (1000 * 1000) - 1)
  {
    unsigned int secs = m_usecs / (1000 * 1000);
    CHECK_OVERFLOW(m_seconds, secs);
    m_seconds += secs;
    m_usecs -= secs * (1000 * 1000);
  }
  
  if(m_seconds > 59)
  {
    unsigned int mins = m_seconds / 60;
    CHECK_OVERFLOW(m_minutes, mins);
    m_minutes += mins;
    m_seconds -= mins * 60;
  }

  if(m_minutes > 59)
  {
    unsigned int hours = m_minutes / 60;
    CHECK_OVERFLOW(m_hours, hours);
    m_hours   += hours;
    m_minutes -= hours * 60;
  }
    
  if(m_hours > 23)
  {
    unsigned int days = m_hours / 24;
    CHECK_OVERFLOW(m_days, days);
    m_days  += days;
    m_hours -= days * 24;
  }
}

bool TimeSpan::operator>(const TimeSpan& sp) const throw()
{
  return (m_days > sp.m_days ||
          (m_days == sp.m_days && m_hours > sp.m_hours) ||
          (m_hours == sp.m_hours && m_minutes > sp.m_minutes) ||
          (m_minutes == sp.m_minutes && m_seconds > sp.m_seconds) ||
          (m_seconds == sp.m_seconds && m_usecs > sp.m_usecs));
}

bool TimeSpan::operator<(const TimeSpan& sp) const throw()
{
  return (m_days < sp.m_days ||
          (m_days == sp.m_days && m_hours < sp.m_hours) ||
          (m_hours == sp.m_hours && m_minutes < sp.m_minutes) ||
          (m_minutes == sp.m_minutes && m_seconds < sp.m_seconds) ||
          (m_seconds == sp.m_seconds && m_usecs < sp.m_usecs));
}

bool TimeSpan::operator>=(const TimeSpan& sp) const throw()
{
  return (operator>(sp) || operator==(sp));
}

bool TimeSpan::operator<=(const TimeSpan& sp) const throw()
{
  return (operator<(sp) || operator==(sp));
}

bool TimeSpan::operator==(const TimeSpan& sp) const throw()
{
  return (m_days == sp.m_days && 
          m_hours == sp.m_hours && 
          m_minutes == sp.m_minutes && 
          m_seconds == sp.m_seconds && 
          m_usecs == sp.m_usecs);
}

bool TimeSpan::operator!=(const TimeSpan& sp) const throw()
{
  return (!operator==(sp));
}

TimeSpan& TimeSpan::operator+=(const TimeSpan& sp) throw(OverflowError)
{
  CHECK_OVERFLOW(m_days, sp.m_days);
  CHECK_OVERFLOW(m_hours, sp.m_hours);
  CHECK_OVERFLOW(m_minutes, sp.m_minutes);
  CHECK_OVERFLOW(m_seconds, sp.m_seconds);
  CHECK_OVERFLOW(m_usecs, sp.m_usecs);
  
  m_days    += sp.m_days;
  m_hours   += sp.m_hours;
  m_minutes += sp.m_minutes;
  m_seconds += sp.m_seconds;
  m_usecs   += sp.m_usecs;
  
  normalize();
  return *this;
}

TimeSpan& TimeSpan::operator-=(const TimeSpan& sp) throw()
{
  if(sp.m_days > m_days)
    m_days = 0;
  else
    m_days -= sp.m_days;
    
  if(sp.m_hours > m_hours)
    m_hours = 0;
  else
    m_hours -= sp.m_hours;
    
  if(sp.m_minutes > m_minutes)
    m_minutes = 0;
  else
    m_minutes -= sp.m_minutes;
        
  if(sp.m_seconds > m_seconds)
    m_seconds = 0;
  else
    m_seconds -= sp.m_seconds;
    
  if(sp.m_usecs > m_usecs)
    m_usecs = 0;
  else
    m_usecs -= sp.m_usecs;
    
  normalize();
  return *this;
}
    
TimeSpan operator+(const TimeSpan& sp1, const TimeSpan& sp2) throw(OverflowError)
{
  TimeSpan ret = sp1;
  ret += sp2;
  return ret;
}

TimeSpan operator-(const TimeSpan& sp1, const TimeSpan& sp2) throw()
{
  TimeSpan ret = sp1;
  ret -= sp2;
  return ret;
}


Date::Date(unsigned short year, unsigned char month, unsigned char day) throw(InvalidDate)
: m_year(year), m_month(month), m_day(day)
{
  if(month > 12 || day > daysInMonth(month, year))
    throw InvalidDate("Invalid date", P_SOURCEINFO);
}

Date::~Date() throw()
{
}

void Date::setYear(unsigned short year)
{
  m_year = year;
}

unsigned short Date::year() const throw()
{
  return m_year;
}

void Date::setMonth(unsigned char month) throw(InvalidDate)
{
  if(month > 12)
    throw InvalidDate("Invalid month", P_SOURCEINFO);
  m_month = month;
}

unsigned char Date::month() const throw()
{
  return m_month;
}

unsigned char Date::daysInMonth() throw()
{
  return daysInMonth(m_month, m_year);
}

void Date::setDay(unsigned char day) throw(InvalidDate)
{
  unsigned char dim = daysInMonth(m_month, m_year);
  if(day <= dim)
  {
    m_day = day;
    return;
  }
  
  throw InvalidDate("Invalid day in month", P_SOURCEINFO);
}

unsigned char Date::day() const throw()
{
  return m_day;
}

double Date::julianDayNumber() const throw()
{
  int a = (14 - m_month) / 12;
  int y = m_year + 4800 - a;
  int m = m_month + 12 * a - 3;
  return (m_day + ((153 * m + 2) / 5) + (365 * y) + (y/4) - (y/100) + (y/400) - 32045);
}

static int _daysInMonth[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
static int _daysOfYear[]  = { 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334 };

unsigned short Date::dayOfYear() const throw()
{
  unsigned short doy = _daysOfYear[m_month - 1] + m_day;
  if(isLeapYear(m_year) && m_month > 1)
    return doy + 1;
    
  return doy;
}

unsigned char Date::dayOfWeek() const throw()
{
  return ((m_year + dayOfYear() + (m_year - 1) / 4 - (m_year - 1) / 100 + (m_year - 1) / 400) % 7);
}

bool Date::isInLeapYear() const throw()
{
  return isLeapYear(m_year);
}

bool Date::isLeapYear(unsigned short year) throw()
{
  return (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
}

unsigned char Date::daysInMonth(unsigned char month, unsigned short year) throw(InvalidDate)
{
  unsigned short dim = _daysInMonth[month - 1];
  if(isLeapYear(year) && month > 1)
    return dim + 1;
    
  return dim;
}

bool Date::operator>(const Date& d) const throw()
{
  return (m_year > d.m_year ||
          (m_year == d.m_year && m_month > d.m_month) ||
          (m_month == d.m_month && m_day > d.m_day));
}

bool Date::operator<(const Date& d) const throw()
{
  return (m_year < d.m_year ||
          (m_year == d.m_year && m_month < d.m_month) ||
          (m_month == d.m_month && m_day < d.m_day));
}

bool Date::operator>=(const Date& d) const throw()
{
  return (operator>(d) || operator==(d));
}

bool Date::operator<=(const Date& d) const throw()
{
  return (operator<(d) || operator==(d));
}

bool Date::operator==(const Date& d) const throw()
{
  return (m_year == d.m_year &&
          m_month == d.m_month &&
          m_day == d.m_day);
}

bool Date::operator!=(const Date& d) const throw()
{
  return (!operator==(d));
}

ostream& operator << (ostream& os, const Date& d)
{
  int oldw = os.width();
  char oldf = os.fill();
  
  os << setfill('0') << setw(4) << (int)d.year() << '-' 
     << setw(2) << (int)d.month() << '-' 
     << setw(2) << (int)d.day()
     << setfill(oldf) << setw(oldw);
  return os;
}

Time::Time(unsigned char hour, unsigned char minute, 
           unsigned char second, unsigned int usec) throw(InvalidTime)
: m_hour(hour), m_minute(minute), m_second(second), m_usec(usec)
{
  if(hour > 23 || minute > 59 || second > 59 || usec > ((1000*1000)-1))
    throw InvalidTime("Invalid time", P_SOURCEINFO);
}

Time::~Time() throw()
{
}
         
void Time::setHour(unsigned char hour)
{
  if(hour > 23)
    throw InvalidTime("Invalid hour", P_SOURCEINFO);
    
  m_hour = hour;
}

unsigned char Time::hour() const throw()
{
  return m_hour;
}

void Time::setMinute(unsigned char minute)
{
  if(minute > 59)
    throw InvalidTime("Invalid minute", P_SOURCEINFO);
    
  m_minute = minute;
}

unsigned char Time::minute() const throw()
{
  return m_minute;
}

void Time::setSecond(unsigned char second)
{
  if(second > 59)
    throw InvalidTime("Invalid second", P_SOURCEINFO);
    
  m_second = second;
}

unsigned char Time::second() const throw()
{
  return m_second;
}

void Time::setUsec(unsigned int usec)
{
  if(usec > (1000 * 1000) - 1)
    throw InvalidTime("Invalid hour", P_SOURCEINFO);
  
  m_usec = usec;
}

unsigned int Time::usec() const throw()
{
  return m_usec;
}

bool Time::operator>(const Time& t) const throw()
{
  return (m_hour > t.m_hour ||
          (m_hour == t.m_hour && m_minute > t.m_minute) ||
          (m_hour == t.m_hour && m_minute == t.m_minute && m_second > t.m_second) ||
          (m_hour == t.m_hour && m_minute == t.m_minute && m_second == t.m_second && m_usec > t.m_usec));
}

bool Time::operator<(const Time& t) const throw()
{
  return (m_hour < t.m_hour ||
          (m_hour == t.m_hour && m_minute < t.m_minute) ||
          (m_hour == t.m_hour && m_minute == t.m_minute && m_second < t.m_second) ||
          (m_hour == t.m_hour && m_minute == t.m_minute && m_second == t.m_second && m_usec < t.m_usec));
}

bool Time::operator>=(const Time& t) const throw()
{
  return (operator>(t) || operator==(t));
}

bool Time::operator<=(const Time& t) const throw()
{
  return (operator<(t) || operator==(t));
}

bool Time::operator==(const Time& t) const throw()
{
  return (m_hour == t.m_hour && m_minute == t.m_minute &&
          m_second == t.m_second && m_usec == t.m_usec);
}

bool Time::operator!=(const Time& t) const throw()
{
  return (!operator==(t));
}

ostream& operator << (ostream& os, const Time& t)
{
  int oldw = os.width();
  char oldf = os.fill();
  
  os << setfill('0') 
     << setw(2) << (int)t.hour() << ':' 
     << setw(2) << (int)t.minute() << ':' 
     << setw(2) << (int)t.second() 
     << setfill(oldf) << setw(oldw);
  return os;
}


DateTime::DateTime()
: Date(), Time(), m_tzname(currentTimeZone())
{
}

DateTime::DateTime(const Date& d, const Time& t)
: Date(d), Time(t), m_tzname(currentTimeZone())
{
}

DateTime::DateTime(const Date& d)
: Date(d), Time(), m_tzname(currentTimeZone())
{
}
    
DateTime::DateTime(const Time& t)
: Date(), Time(t), m_tzname(currentTimeZone())
{
}

DateTime::DateTime(const Date& d, const Time& t, const string& tzname)
: Date(d), Time(t), m_tzname(tzname)
{
}

DateTime::~DateTime()
{
}

DateTime DateTime::toLocalTime() const
{
  return toTimeZone(currentTimeZone());
}
    
DateTime DateTime::toTimeZone(const string& tzname) const
{
  if(m_tzname == tzname)
    return *this;
    
  //@todo convert the date/time value to given timezone
  return *this;
}

bool DateTime::operator>(const DateTime& dt) const throw()
{
  return (Date::operator>(dt) || (Date::operator==(dt) && Time::operator>(dt)));
}

bool DateTime::operator<(const DateTime& dt) const throw()
{
  return (Date::operator<(dt) || (Date::operator==(dt) && Time::operator<(dt)));
}

bool DateTime::operator>=(const DateTime& dt) const throw()
{
  return (operator>(dt) || operator==(dt));
}

bool DateTime::operator<=(const DateTime& dt) const throw()
{
  return (operator<(dt) || operator==(dt));
}

bool DateTime::operator==(const DateTime& dt) const throw()
{
  return (Date::operator==(dt) && Time::operator==(dt));
}

bool DateTime::operator!=(const DateTime& dt) const throw()
{
  return (!operator==(dt));
}

ostream& operator << (ostream& os, const DateTime& dt)
{
  os << (Date&)dt << ' ' << (Time&)dt << ' ' << dt.timeZone();
  return os;
}


}
