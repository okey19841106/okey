/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/pfile.h"

namespace P {

using namespace std;

File::File() throw()
: IODevice()
{}

File::File(const File& f) throw(IOError)
: IODevice(f), m_path(f.m_path),
  m_accessMode(f.m_accessMode), m_openMode(f.m_openMode),
  m_createMode(f.m_createMode), m_shareMode(f.m_shareMode)
{}

File::File(const char* path, accessMode_t amode, openMode_t omode,
           createMode_t cmode, shareMode_t smode) throw(IOError)
: IODevice()
{
  open(path, amode, omode, cmode, smode);
}

File::~File() throw()
{
  try
  {
    close();
  }
  catch(...)
  {
  }
}

size_t File::peek(char* buffer, size_t count) throw(IOError)
{
  size_t ret = read(buffer, count);
  if(ret > 0)
    seek(-((off_t)ret), seekCurrent);

  return ret;
}

void File::reopen() throw(IOError)
{
  #ifdef HAVE_LARGEFILE64
  off64_t
  #else
  off_t
  #endif
    pos = seek(0, seekCurrent);

  close();
  open(m_path.c_str(), m_accessMode, m_openMode, m_createMode, m_shareMode);

  seek(pos, seekSet);
}

FileInfo File::stat(const char* path) throw(IOError)
{
  return FileInfo(path);
}

File& File::operator=(const File& f) throw(IOError)
{
  close();
  IODevice::operator=(f);

  m_path       = f.m_path;
  m_accessMode = f.m_accessMode;
  m_openMode   = f.m_openMode;
  m_createMode = f.m_createMode;
  m_shareMode  = f.m_shareMode;

  return *this;
}


}
