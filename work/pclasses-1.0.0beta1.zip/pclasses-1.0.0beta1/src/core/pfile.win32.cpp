/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/pfile.h"
#include <windows.h>
#include <shlwapi.h>
#include <string.h>

namespace P {

using namespace std;

void File::open(const char* path, accessMode_t amode, openMode_t omode, 
                createMode_t cmode, shareMode_t smode) throw(IOError)
{
  if(isValid())
    close();

  DWORD acc;
  switch(amode)
  {
    case Write:
      acc = GENERIC_WRITE;
      break;

    case ReadWrite:
      acc = GENERIC_READ | GENERIC_WRITE;
      break;

    case Read:
    default:
      acc = GENERIC_READ;
      break;
  }

  DWORD create;
  switch(cmode)
  {
    case OpenCreate:
      create = OPEN_ALWAYS;
      break;

    case CreateFail:
      create = CREATE_NEW;
      break;

    case OpenExisting:
    default:
      create = OPEN_EXISTING;
      break;
  }

  DWORD share;
  switch(smode)
  {
    case AllowNone:
      share = 0;
      break;
    
    case AllowRead:
      share = FILE_SHARE_READ;
      break;
    
    case AllowWrite:
      share = FILE_SHARE_WRITE;
      break;
      
    case AllowReadWrite:
      share = FILE_SHARE_READ|FILE_SHARE_WRITE;
      break;
  }
  
  io_handle_t handle = CreateFile(path, acc, share, NULL, create, 0, NULL);
  if(handle != INVALID_HANDLE_VALUE)
  {
    m_path       = path;
    m_accessMode = amode;
    m_openMode   = omode;
    m_createMode = cmode;
    m_shareMode  = smode;
    setHandle(handle);

    try {
      if(omode == Append)
        seek(0, seekEnd);
      else if(omode == Truncate)
        truncate(0);
    }
    catch(...)
    {
      close();
      throw;
    }

    return;
  }

  throw IOError(GetLastError(), "Could not open/create file", P_SOURCEINFO);
}

#ifndef HAVE_LARGEFILE64

void File::truncate(off_t offset) throw(IOError)
{
  off_t pos = seek(0, seekCurrent);
  seek(offset, seekSet);

  if(!SetEndOfFile(handle()))
  {
    DWORD err = GetLastError();
    seek(pos, seekSet);
    throw IOError(err, "Could not truncate file", P_SOURCEINFO);
  }
}

off_t File::size() throw(IOError)
{
  DWORD sz = GetFileSize(handle(), NULL);
  if(sz == INVALID_FILE_SIZE)
    throw IOError(GetLastError(), "Could not get file size", P_SOURCEINFO);

  return sz;
}

#else /* HAVE_LARGEFILE64 */

void File::truncate(off64_t offset) throw(IOError)
{
  off64_t pos = seek(0, seekCurrent);
  seek(offset, seekSet);

  if(!SetEndOfFile(handle()))
  {
    DWORD err = GetLastError();
    seek(pos, seekSet);
    throw IOError(err, "Could not truncate file", P_SOURCEINFO);
  }
}

off64_t File::size() throw(IOError)
{
  LARGE_INTEGER li;
  li.LowPart = GetFileSize(handle(), (LPDWORD)&li.HighPart) ;

  if(li.LowPart == INVALID_FILE_SIZE && GetLastError() != NO_ERROR)
    throw IOError(GetLastError(), "Could not get file size", P_SOURCEINFO);

  return li.QuadPart;
}

#endif /* HAVE_LARGEFILE64 */

void File::unlink(const char* path) throw(IOError)
{
  if(!DeleteFile(path))
    throw IOError(GetLastError(), "Could not delete file", P_SOURCEINFO);
}

bool File::exists(const char* path) throw()
{
  return PathFileExists(path) ? true : false;
}

File File::mktemp(const char* prefix) throw(IOError)
{
  char tmpdir[MAX_PATH+1];
  char tmpname[MAX_PATH+1];
  
  GetTempPath(MAX_PATH, tmpdir);
  UINT ret = GetTempFileName(tmpdir, prefix, 0, tmpname);
  if(ret == 0)
    throw IOError(GetLastError(), "Could not get temporary filename", P_SOURCEINFO);

  io_handle_t handle = CreateFile(tmpname, GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING,
                                  FILE_ATTRIBUTE_TEMPORARY|FILE_FLAG_DELETE_ON_CLOSE, NULL);
                                  
  if(handle == INVALID_HANDLE_VALUE)
  {
    DWORD err = GetLastError();
    File::unlink(tmpname);
    throw IOError(err, "Could not open temporary file", P_SOURCEINFO);
  }
  
  File f;
  f.setHandle(handle);
  return f;
}

}
