/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/piodevice.h"
#include <windows.h>

namespace P {

IODevice::IODevice(io_handle_t handle) throw(IOError)
{
  BOOL ret = DuplicateHandle(GetCurrentProcess(), handle,
                            GetCurrentProcess(), &m_handle,
                            DUPLICATE_SAME_ACCESS, TRUE, 0);
  if(!ret)
    throw IOError(GetLastError(), "Could not duplicate handle", P_SOURCEINFO);
}

IODevice::IODevice(const IODevice& dev) throw(IOError)
{
  BOOL ret = DuplicateHandle(GetCurrentProcess(), dev.m_handle,
                            GetCurrentProcess(), &m_handle,
                            DUPLICATE_SAME_ACCESS, TRUE, 0);
  if(!ret)
    throw IOError(GetLastError(), "Could not duplicate handle", P_SOURCEINFO);
}

IODevice& IODevice::operator=(const IODevice& dev) throw(IOError)
{
  close();

  BOOL ret = DuplicateHandle(GetCurrentProcess(), dev.m_handle,
                            GetCurrentProcess(), &m_handle,
                            DUPLICATE_SAME_ACCESS, TRUE, 0);
  if(!ret)
    throw IOError(GetLastError(), "Could not duplicate handle", P_SOURCEINFO);

  return *this;
}

IODevice::~IODevice() throw()
{
  try
  {
    if(isValid())
      close();
  }
  catch(...)
  {
  }
}

void IODevice::close() throw(IOError)
{
  if(isValid())
  {
    if(!CloseHandle(m_handle))
      throw IOError(GetLastError(), "Could not close handle", P_SOURCEINFO);

    m_handle = INVALID_HANDLE_VALUE;
  }
}

size_t IODevice::write(const char* buffer, size_t count) throw(IOError)
{
  DWORD written = 0;

  if(!WriteFile(m_handle, (void*)buffer, count, &written, NULL))
    throw IOError(GetLastError(), "Could not write to handle", P_SOURCEINFO);

  return written;
}

size_t IODevice::read(char* buffer, size_t count) throw(IOError)
{
  DWORD read;
  if(!ReadFile(m_handle, (void*)buffer, count, &read, NULL))
    throw IOError(GetLastError(), "Could not read from handle", P_SOURCEINFO);

  return read;
}

void IODevice::commit() throw(IOError)
{
  if(!FlushFileBuffers(m_handle))
    throw IOError(GetLastError(), "Could not flush buffers", P_SOURCEINFO);
}


bool IODevice::isSeekable() const throw()
{
  try {
    const_cast<IODevice*>(this)->seek(0, seekCurrent);
  }
  catch(...)
  {
    return false;
  }

  return true;
}

#ifndef HAVE_LARGEFILE64

off_t IODevice::seek(off_t offset, seekMode_t mode) throw(IOError)
{
  DWORD whence;
  switch(mode)
  {
    case seekSet:
      whence = FILE_BEGIN;
      break;

    case seekCurrent:
      whence = FILE_CURRENT;
      break;

    case seekEnd:
      whence = FILE_END;
      break;
  }

  DWORD ret = SetFilePointer(m_handle, offset, NULL, whence);

  if(ret == INVALID_SET_FILE_POINTER)
    throw IOError(GetLastError(), "Could not set file pointer", P_SOURCEINFO);

  return ret;
}

#else

off64_t IODevice::seek(off64_t offset, seekMode_t mode) throw(IOError)
{
  DWORD whence = FILE_BEGIN;
  switch(mode)
  {
    case seekSet:
      whence = FILE_BEGIN;
      break;

    case seekCurrent:
      whence = FILE_CURRENT;
      break;

    case seekEnd:
      whence = FILE_END;
      break;
  }

  LARGE_INTEGER li;
  li.QuadPart = offset;
  li.LowPart  = SetFilePointer(m_handle, li.LowPart, &li.HighPart, whence);

  if(li.LowPart == INVALID_SET_FILE_POINTER && GetLastError() != NO_ERROR)
    throw IOError(GetLastError(), "Could not set file pointer", P_SOURCEINFO);

  return li.QuadPart;
}

#endif

}
