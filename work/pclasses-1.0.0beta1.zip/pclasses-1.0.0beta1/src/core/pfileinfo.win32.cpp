/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/pfileinfo.h"
#include <windows.h>
#include <shlwapi.h>
#include <string.h>

namespace P {

using namespace std;

void FileTimeToPDateTime(FILETIME* ft, DateTime& dt)
{
  TIME_ZONE_INFORMATION tzi;
  ULARGE_INTEGER uli;
  SYSTEMTIME stLocal;

  GetTimeZoneInformation(&tzi);
  uli.LowPart  = ft->dwLowDateTime;
  uli.HighPart = ft->dwHighDateTime;
  uli.QuadPart = uli.QuadPart - (tzi.Bias * 60 * 1000 * 100);

  FileTimeToSystemTime(ft, &stLocal);
  dt = DateTime(Date(stLocal.wYear, stLocal.wMonth, stLocal.wDay),
                Time(stLocal.wHour, stLocal.wMinute, stLocal.wSecond, stLocal.wMilliseconds * 1000));
}

FileInfo::FileInfo(const char* path) throw(IOError)
{
  string mypath = path;

  if(mypath.at(mypath.length()-1) == '\\')
    mypath.erase(mypath.length()-1,1);

  string::size_type namepos = mypath.find_last_of("\\");
  if(namepos == string::npos)
  {
    m_dirName = "\\";
    m_name    = path;
  }
  else
  {
    m_dirName = mypath.substr(0,namepos+1);
    m_name    = mypath.substr(namepos+1);
  }

  HANDLE hFile = CreateFile(mypath.c_str(), FILE_LIST_DIRECTORY, FILE_SHARE_READ|FILE_SHARE_DELETE,
                            NULL, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, NULL);
  if(hFile == INVALID_HANDLE_VALUE)
    throw IOError(GetLastError(), "Could not open file for stat", P_SOURCEINFO);

  BY_HANDLE_FILE_INFORMATION hFileInfo;
  if(!GetFileInformationByHandle(hFile, &hFileInfo))
  {
    CloseHandle(hFile);
    throw IOError(GetLastError(),"Could not get file information", P_SOURCEINFO);
  }

  LARGE_INTEGER fsli;
  fsli.LowPart  = hFileInfo.nFileSizeLow;
  fsli.HighPart = hFileInfo.nFileSizeHigh;
  m_size = fsli.QuadPart;

  if(hFileInfo.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
  {
    m_type = Directory;
  }
  else
  {
    switch(GetFileType(hFile))
    {
      case FILE_TYPE_DISK:
        m_type = File;
        break;

      case FILE_TYPE_CHAR:
        m_type = CharDevice;
        break;

      case FILE_TYPE_PIPE:
        m_type = Pipe;
        break;

      case FILE_TYPE_UNKNOWN:
      default:
        m_type = Unknown;
    }
  }

  CloseHandle(hFile);

  FileTimeToPDateTime(&hFileInfo.ftCreationTime, m_ctime);
  FileTimeToPDateTime(&hFileInfo.ftLastWriteTime, m_mtime);
  FileTimeToPDateTime(&hFileInfo.ftLastAccessTime, m_atime);
}

string FileInfo::absDirName() const throw(SystemError)
{
  char abspath[MAX_PATH+1];
  LPTSTR filePart = 0;

  DWORD ret = GetFullPathName(m_dirName.c_str(), MAX_PATH, abspath, &filePart);
  if(!ret)
    throw SystemError(GetLastError(), "Could not resolve absolute path", P_SOURCEINFO);

  return string(abspath);
}

}
