/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/piodevice.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>

#if defined(HAVE_LARGEFILE64) && !defined(HAVE_OPEN64)
  #define lseek64      lseek
#endif


namespace P {

IODevice::IODevice(io_handle_t handle) throw(IOError)
{
  m_handle = dup(handle);
  if(m_handle == -1)
    throw IOError(errno, "Could not duplicate file descriptor", P_SOURCEINFO);
}

IODevice::IODevice(const IODevice& dev) throw(IOError)
{
  m_handle = dup(dev.m_handle);
  if(m_handle == -1)
    throw IOError(errno, "Could not duplicate file descriptor", P_SOURCEINFO);
}

IODevice& IODevice::operator=(const IODevice& dev) throw(IOError)
{
  close();

  m_handle = dup(dev.m_handle);
  if(m_handle == -1)
    throw IOError(errno, "Could not duplicate file descriptor", P_SOURCEINFO);

  return *this;
}

IODevice::~IODevice() throw()
{
  try
  {
    close();
  }
  catch(...)
  {
  }
}

void IODevice::close() throw(IOError)
{
  if(isValid())
  {
    if(::close(m_handle) != 0)
      throw IOError(errno, "Could not close file descriptor", P_SOURCEINFO);

    m_handle = INVALID_HANDLE_VALUE;
  }
}

size_t IODevice::write(const char* buffer, size_t count) throw(IOError)
{
  _write:
  ssize_t ret = ::write(m_handle, buffer, count);
  if(ret != -1)
    return ret;

  if(errno == EAGAIN)
    return 0;
  else if(errno == EINTR)
    goto _write;

  throw IOError(errno, "Could not write to file descriptor", P_SOURCEINFO);
}

size_t IODevice::read(char* buffer, size_t count) throw(IOError)
{
  _read:
  ssize_t ret = ::read(m_handle, buffer, count);
  if(ret != -1)
    return ret;

  if(errno == EAGAIN)
    return 0;
  else if(errno == EINTR)
    goto _read;

  throw IOError(errno, "Could not read from file descriptor", P_SOURCEINFO);
}

void IODevice::commit() throw(IOError)
{
  int ret = fsync(m_handle);
  if(ret != -1)
    return;

  if(errno == EINVAL)
    return;

  throw IOError(errno, "Could not sync device", P_SOURCEINFO);
}


bool IODevice::isSeekable() const throw()
{
  try {
    const_cast<IODevice*>(this)->seek(0, seekCurrent);
  }
  catch(...)
  {
    return false;
  }

  return true;
}

#ifndef HAVE_LARGEFILE64

off_t IODevice::seek(off_t offset, seekMode_t mode) throw(IOError)
{
  int whence;
  switch(mode)
  {
    case seekSet:
      whence = SEEK_SET;
      break;

    case seekCurrent:
      whence = SEEK_CUR;
      break;

    case seekEnd:
      whence = SEEK_END;
      break;
  }

  _seek:
  off_t ret = lseek(m_handle, offset, whence);
  if(ret != -1)
    return ret;

  if(errno == EINTR)
    goto _seek;

  throw IOError(errno, "Could not seek on file descriptor", P_SOURCEINFO);
}

#else

off64_t IODevice::seek(off64_t offset, seekMode_t mode) throw(IOError)
{
  int whence;
  switch(mode)
  {
    case seekSet:
      whence = SEEK_SET;
      break;

    case seekCurrent:
      whence = SEEK_CUR;
      break;

    case seekEnd:
      whence = SEEK_END;
      break;
  }

  _seek:
  off64_t ret = lseek64(m_handle, offset, whence);
  if(ret != -1)
    return ret;

  if(errno == EINTR)
    goto _seek;

  throw IOError(errno, "Could not seek on file descriptor", P_SOURCEINFO);
}

#endif

}
