/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/psimpleconfigstore.h"
#include "pclasses/pfile.h"
#include "pclasses/ptokenizer.h"

#include <sstream>
#include <iostream>

namespace P {

using namespace std;

static void trim(string& str)
{
  string::size_type pos = str.find_first_not_of(" ");
  if(pos != string::npos)
    str.erase(0, pos);

  pos = str.find_last_not_of(" ");
  if(pos != string::npos)
    str.erase(pos+1);
}

class SimpleConfigFileParser {
  public:
    enum state_t
    {
      None,
      Comment,
      Section,
      ValueName,
      Value
    };

    SimpleConfigFileParser()
    : m_state(None) {}
    virtual ~SimpleConfigFileParser() {}

  protected:
    void parseChunk(const char* buffer, size_t count);

    virtual void onWhiteSpace(const string& str) {}
    virtual void onComment(const string& str) {}
    virtual void onSection(const string& str) {}
    virtual void onValueName(const string& str) {}
    virtual void onValueAssign() {}
    virtual void onValue(const string& str) {}

  private:
    void eatWhiteSpace(const char* buffer, size_t count, size_t& i, ostringstream& os);
    bool eatComment(const char* buffer, size_t count, size_t& i, ostringstream& os);

    bool parseSection(const char* buffer, size_t count, size_t& i, ostringstream& os);
    bool parseValueName(const char* buffer, size_t count, size_t& i, ostringstream& os);
    bool parseValue(const char* buffer, size_t count, size_t& i, ostringstream& os);

    state_t m_state;

};

void SimpleConfigFileParser::eatWhiteSpace(const char* buffer, size_t count, size_t& i, ostringstream& os)
{
  while(i < count)
  {
    switch(buffer[i])
    {
      case '\r':
      case '\n':
      case '\t':
      case ' ':
        os << buffer[i++];
        break;

      default:
        return;
    }
  }
}

bool SimpleConfigFileParser::eatComment(const char* buffer, size_t count, size_t& i, ostringstream& os)
{
  while(i < count)
  {
    // newline finishes the comment line
    if(buffer[i] == '\n')
    {
      ++i;
      return true;
    }

    os << buffer[i++];
  }

  return false;
}

bool SimpleConfigFileParser::parseSection(const char* buffer, size_t count, size_t& i, ostringstream& os)
{
  while(i < count)
  {
    // newline, linefeed or ']' finishes the section identifier
    switch(buffer[i])
    {
      case ']':
        ++i;

      case '\r':
      case '\n':
        return true;

      default:
        os << buffer[i++];
        break;
    }
  }

  return false;
}

bool SimpleConfigFileParser::parseValueName(const char* buffer, size_t count, size_t& i, ostringstream& os)
{
  while(i < count)
  {
    switch(buffer[i])
    {
      case '=':
        return true;

      default:
        os << buffer[i++];
        break;
    }
  }

  return false;
}

bool SimpleConfigFileParser::parseValue(const char* buffer, size_t count, size_t& i, ostringstream& os)
{
  while(i < count)
  {
    switch(buffer[i])
    {
      case '\r':
      case '\n':
      case ';':
      case '#':
        return true;

      default:
        os << buffer[i++];
        break;
    }
  }

  return false;
}

void SimpleConfigFileParser::parseChunk(const char* buffer, size_t count)
{
  size_t i = 0;
  ostringstream tmpStrm;

  while(i < count)
  {
    switch(m_state)
    {
      case None:
        {
          eatWhiteSpace(buffer, count, i, tmpStrm);
          string ws = tmpStrm.str();
          if(ws.size() > 0)
          {
            onWhiteSpace(ws);
            tmpStrm.str("");
          }

          if(i < count)
          {
            switch(buffer[i])
            {
              case '#':
              case ';':
                tmpStrm << buffer[i++];
                m_state = Comment;
                break;

              case '[':
                ++i;
                m_state = Section;
                break;

              case '=':
                ++i;
                onValueAssign();
                m_state = Value;
                break;

              default:
                m_state = ValueName;
                break;
            }
          }
        }
        break;

      case Comment:
        if(eatComment(buffer, count, i, tmpStrm))
        {
          string comment = tmpStrm.str();
          if(comment.size() > 0)
          {
            onComment(comment);
            tmpStrm.str("");
          }
          m_state = None;
        }
        break;

      case Section:
        if(parseSection(buffer, count, i, tmpStrm))
        {
          string section = tmpStrm.str();
          if(section.size() > 0)
          {
            onSection(section);
            tmpStrm.str("");
          }
          m_state = None;
        }
        break;

      case ValueName:
        if(parseValueName(buffer, count, i, tmpStrm))
        {
          string valueName = tmpStrm.str();
          if(valueName.size() > 0)
          {
            onValueName(valueName);
            tmpStrm.str("");
          }
          m_state = Value;
        }
        break;

      case Value:
        if(buffer[i] == '=')
        {
          onValueAssign();
          ++i;
        }

        if(parseValue(buffer, count, i, tmpStrm))
        {
          string value = tmpStrm.str();
          if(value.size() > 0)
          {
            onValue(value);
            tmpStrm.str("");
          }
          m_state = None;
        }
        break;
    }
  }
}


class SimpleConfigFileReader: public SimpleConfigFileParser {
  public:
    SimpleConfigFileReader(const string& path)
    : m_path(path), m_currKey(0), m_root(0) { }

    ~SimpleConfigFileReader() { }

    void read(Config::Key& root);

    void onSection(const string& str);
    void onValueName(const string& str);
    void onValue(const string& str);

  protected:
    string        m_path;
    string        m_section;
    string        m_valueName;
    Config::Key*  m_currKey;
    Config::Key*  m_root;
};

void SimpleConfigFileReader::read(Config::Key& root)
{
  File f(m_path.c_str(), File::Read, File::Normal, File::OpenExisting);

  char buffer[4096];
  size_t ret;

  m_currKey = &root;
  m_root = &root;

  while(1)
  {
    ret = f.read(buffer, 4096);
    if(!ret)
      break;

    parseChunk(buffer, ret);
  }
}

void SimpleConfigFileReader::onSection(const string& str)
{
  m_section = str;
  trim(m_section);

  Config::Key* sectionKey = m_root;
  string tmp;

  StringTokenizer tokens(m_section, "\\");
  while(tokens)
  {
    tokens >> tmp;

    Config::Key* nextKey = sectionKey->key(tmp);
    if(!nextKey)
      nextKey = sectionKey->addKey(tmp);

    sectionKey = nextKey;
  }

  m_currKey = sectionKey;
}

void SimpleConfigFileReader::onValueName(const string& str)
{
  m_valueName = str;
  trim(m_valueName);
}

void SimpleConfigFileReader::onValue(const string& str)
{
  m_currKey->setValue(m_valueName, str);
}


class SimpleConfigFileUpdater: public SimpleConfigFileParser {
  public:
    SimpleConfigFileUpdater(const string& path)
    : m_path(path), m_currKey(0), m_root(0) { }

    ~SimpleConfigFileUpdater() { }

    void update(Config::Key& root);

    void onWhiteSpace(const string& str);
    void onComment(const string& str);
    void onSection(const string& str);
    void onValueName(const string& str);
    void onValueAssign();
    void onValue(const string& str);

  protected:
    string        m_path;
    string        m_section;
    string        m_valueName;
    Config::Key*  m_currKey;
    Config::Key*  m_root;
};

void SimpleConfigFileUpdater::update(Config::Key& root)
{
  File origFile(m_path.c_str(), File::Read, File::Normal, File::OpenExisting);

  char buffer[4096];
  size_t ret;

  m_currKey = &root;
  m_root = &root;

  while(1)
  {
    ret = origFile.read(buffer, 4096);
    if(!ret)
      break;

    parseChunk(buffer, ret);
  }
}

void SimpleConfigFileUpdater::onWhiteSpace(const string& str)
{
  cout << str;
}

void SimpleConfigFileUpdater::onComment(const string& str)
{
  cout << str;
}

void SimpleConfigFileUpdater::onSection(const string& str)
{
  m_section = str;
  trim(m_section);

  Config::Key* sectionKey = m_root;
  string tmp;

  StringTokenizer tokens(m_section, "\\");
  while(tokens)
  {
    tokens >> tmp;

    Config::Key* nextKey = sectionKey->key(tmp);
    if(!nextKey)
      nextKey = sectionKey->addKey(tmp);

    sectionKey = nextKey;
  }

  m_currKey = sectionKey;

  cout << "[" << str << "]";
}

void SimpleConfigFileUpdater::onValueName(const string& str)
{
  m_valueName = str;
  trim(m_valueName);
  cout << str;
}

void SimpleConfigFileUpdater::onValueAssign()
{
  cout << "=";
}

void SimpleConfigFileUpdater::onValue(const string& str)
{
  cout << m_currKey->value(m_valueName, "");
}


SimpleConfigStore::SimpleConfigStore(const string& path)
: ConfigStore(path)
{
}

SimpleConfigStore::~SimpleConfigStore()
{
}

void SimpleConfigStore::read(Config::Key& root)
{
  SimpleConfigFileReader fileReader(path());
  fileReader.read(root);
}

void SimpleConfigStore::update(Config::Key& root)
{
  SimpleConfigFileUpdater fileUpdater(path());
  fileUpdater.update(root);
}

}
