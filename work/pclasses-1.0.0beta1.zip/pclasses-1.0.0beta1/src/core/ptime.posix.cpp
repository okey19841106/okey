/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/config.h"
#include "pclasses/ptime.h"
#include "pclasses/pcriticalsection.h"

#ifdef HAVE_GETTIMEOFDAY
#include <sys/time.h>
#endif

namespace P {

using namespace std;

#ifndef HAVE_LOCALTIME_R
static CriticalSection localtimeCs;
#endif

#ifndef HAVE_GMTIME_R
static CriticalSection gmtimeCs;
#endif

DateTime DateTime::current(currentMode_t mode)
{
  time_t secs = 0;
  unsigned int usecs = 0;
  string tz_name;

  tzset();

  #ifdef HAVE_CLOCK_GETTIME
  {
    struct timespec tp;
    clock_gettime(CLOCK_REALTIME, &tp);
    secs  = tp.tv_sec;
    usecs = tp.tv_nsec / 1000;
  }
  #elif defined(HAVE_GETTIMEOFDAY)
  {
    struct timeval tv;
    gettimeofday(&tv, 0);
    secs  = tv.tv_sec;
    usecs = tv.tv_usec;
  }
  #else
  {
    secs  = time(0);
    usecs = 0;
  }
  #endif

  struct tm* currtmp;
  struct tm currtm;

  switch(mode)
  {
    case Local:
      #ifdef HAVE_LOCALTIME_R
      {
        currtmp = localtime_r(&secs, &currtm);
        if(!currtmp)
          return DateTime();
      }
      #else
      {
        CriticalSection::Lock l(localtimeCs);
        currtmp = localtime(&secs);
        if(!currtmp)
          return DateTime();

        currtm = *currtmp;
        currtmp = &currtm;
      }
      #endif

      if(currtmp && currtmp->tm_isdst > 0)
        tz_name = tzname[1];
      else
        tz_name = tzname[0];
      break;

    case UTC:
      #ifdef HAVE_GMTIME_R
      {
        currtmp = gmtime_r(&secs, &currtm);
        if(!currtmp)
          return DateTime();
      }
      #else
      {
        CriticalSection::Lock l(gmtimeCs);
        currtmp = gmtime(&secs);
        if(!currtmp)
          return DateTime();

        currtm = *currtmp;
        currtmp = &currtm;
      }
      #endif

      tz_name = "UTC";
      break;

    default:
      throw; //@todo throw InvalidArgument
  }

  return DateTime(Date(currtmp->tm_year + 1900, currtmp->tm_mon + 1, currtmp->tm_mday),
                  Time(currtmp->tm_hour, currtmp->tm_min, currtmp->tm_sec, usecs), tz_name);
}

string DateTime::currentTimeZone()
{
  tzset();

  time_t timet = time(0);

  struct tm currtm;
  struct tm* currtmp;

  #ifdef HAVE_LOCALTIME_R
  {
    currtmp = localtime_r(&timet, &currtm);
  }
  #else
  {
    CriticalSection::Lock l(localtimeCs);
    currtmp = localtime(&timet);
  }
  #endif

  string tz_name;
  if(currtmp && currtmp->tm_isdst > 0)
    tz_name = tzname[1];
  else
    tz_name = tzname[0];

  return tz_name;
}

}
