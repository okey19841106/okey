/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/pfileinfo.h"
#include "pclasses/pdirectory.h"

namespace P {

using namespace std;

FileInfo::FileInfo(const FileInfo& fi)
: m_size(fi.m_size), m_type(fi.type()), m_dirName(fi.m_dirName), m_name(fi.m_name),
  m_ctime(fi.m_ctime), m_mtime(fi.m_mtime), m_atime(fi.m_atime)
{
}

FileInfo::~FileInfo()
{
}

string FileInfo::path() const throw()
{
  return m_dirName + Directory::separator() + m_name;
}

string FileInfo::absPath() const throw(SystemError)
{
  return absDirName() + Directory::separator() + m_name;
}

FileInfo& FileInfo::operator=(const FileInfo& fi) throw()
{
  m_size    = fi.m_size;
  m_type    = fi.m_type;
  m_dirName = fi.m_dirName;
  m_name    = fi.m_name;
  m_ctime   = fi.m_ctime;
  m_mtime   = fi.m_mtime;
  m_atime   = fi.m_atime;
  return *this;
}


}
