/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/psharedlib.h"
#include <mach-o/dyld.h>

namespace P {

using namespace std;

struct SharedLib::dso_handle_t {};

SharedLib::SharedLib(const string& name, ldmode_t mode) throw(SystemError)
{
  int flags = 0;
  switch(mode)
  {
    case bindLazy:
      break;
    case bindNow:
      flags = NSLINKMODULE_OPTION_BINDNOW;
      break;
  }
  flags |= NSLINKMODULE_OPTION_RETURN_ON_ERROR;

  NSObjectFileImage file;
  NSObjectFileImageReturnCode ret;
  ret = NSCreateObjectFileImageFromFile(name.c_str(), &file);
  if(ret != NSObjectFileImageSuccess)
    throw SystemError(0, "Could not load shared library", P_SOURCEINFO);

  NSModule out = NSLinkModule(file, name.c_str(), flags);
  m_handle = (dso_handle_t*)out;
}

SharedLib::~SharedLib() throw()
{
  NSUnLinkModule((NSModule)m_handle, NSUNLINKMODULE_OPTION_NONE);
}

void* SharedLib::operator[](const char* symbol) throw()
{
  NSSymbol sym = NSLookupSymbolInModule((NSModule)m_handle, symbol);
  return (void*)sym;
}

}
