/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/pdirectory.h"
#include <windows.h>

namespace P {

using namespace std;

struct Directory::dir_handle_t {
  HANDLE handle;
  WIN32_FIND_DATA current;
  bool first, eof;
};

Directory::Directory(const char* path) throw(IOError)
{
  m_handle = new dir_handle_t;
  m_handle->handle = FindFirstFile((string(path) + "\\*").c_str(), &m_handle->current);
  if(m_handle->handle == INVALID_HANDLE_VALUE)
  {
    delete m_handle;
    throw IOError(GetLastError(), "Could not open directory", P_SOURCEINFO);
  }
  m_handle->first = true;
  m_handle->eof   = false;
  m_path = path;
}

Directory::~Directory() throw()
{
  FindClose(m_handle->handle);
  delete m_handle;
}

const char* Directory::operator++() throw(IOError)
{
  if(m_handle->first)
  {
    m_handle->first = false;
    return m_handle->current.cFileName;
  }

  if(!FindNextFile(m_handle->handle, &m_handle->current))
  {
    if(GetLastError() == ERROR_NO_MORE_FILES)
      return 0;
    throw IOError(GetLastError(), "Could not read directory entry", P_SOURCEINFO);
  }

  return m_handle->current.cFileName;
}

const char* Directory::operator*() const throw()
{
  if(!m_handle->eof)
    return m_handle->current.cFileName;

  return 0;
}

void Directory::rewind() throw()
{
  FindClose(m_handle->handle);
  m_handle->handle = FindFirstFile((m_path + "\\*").c_str(), &m_handle->current);
  m_handle->first  = true;
  m_handle->eof    = false;
}

void Directory::create(const char* path) throw(IOError)
{
  if(!CreateDirectory(path, NULL))
    throw IOError(GetLastError(), "Could not create directory", P_SOURCEINFO);
}

void Directory::remove(const char* path) throw(IOError)
{
  if(!RemoveDirectory(path))
    throw IOError(GetLastError(), "Could not remove directory", P_SOURCEINFO);
}

void Directory::change(const char* path) throw(IOError)
{
  if(!SetCurrentDirectory(path))
    throw IOError(GetLastError(), "Could not change working directory", P_SOURCEINFO);
}

string Directory::current() throw(IOError)
{
  char path[4096];
  if(!GetCurrentDirectory(sizeof(path), path))
    throw IOError(GetLastError(), "Could not get working directory", P_SOURCEINFO);
  return path;
}

string Directory::separator() throw()
{
  return "\\";
}

string Directory::homeDir() throw()
{
  //@todo
  return string("");
}

void Directory::getDriveList(list<string>& dl) throw()
{
  dl.clear();
  //@todo
}

}
