/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/pthread_.h"
#include "pclasses/pmutex.h"
#include "pclasses/psemaphore.h"
#include "pclasses/pcriticalsection.h"
#include "pclasses/pthreadkey.h"

#include <list>
#include <windows.h>

namespace P {

using namespace std;

struct Thread::thread_handle_t {
  HANDLE handle;
  DWORD threadId;
  state_t state;
  Mutex running_mutex;
  Mutex notsuspended_mutex;
  Semaphore resume_sem;
  bool should_exit;
  bool should_suspend;

  // common members
  static list<Thread::thread_handle_t*> threadHandlePool;
  static CriticalSection threadHandlePoolCs;
};

#include "pthread.common.i"

class Thread::Private {
  public:
    static DWORD WINAPI thread_entry(void* param)
    {
      thread_start_param* start_param = (thread_start_param*)param;
      Thread* thread = start_param->thread;
      thread_handle_t* handle = thread->handle();

      g_currentThread = thread;

      handle->notsuspended_mutex.lock();
      handle->running_mutex.lock();

      handle->state = Running;

      if(start_param->sem)
        start_param->sem->post();

      delete start_param;

      if(!thread->initial())
      {
        handle->notsuspended_mutex.unlock();
        handle->running_mutex.unlock();
        Thread::destroyHandle(handle);
        return 0;
      }

      thread->main();
      thread->final();

      handle->state = Stopped;
      handle->notsuspended_mutex.unlock();
      handle->running_mutex.unlock();
      Thread::destroyHandle(handle);
      return 0;
    }
};

void Thread::start(Semaphore* sem, int prio) throw(LogicError, ThreadError)
{
  if(!m_handle)
    m_handle = createHandle();

  if(m_handle->state != Stopped)
    throw LogicError("Thread is already running", P_SOURCEINFO);

  thread_start_param* start_param = new thread_start_param;
  start_param->thread = this;
  start_param->sem    = sem;

  m_handle->should_exit    = false;
  m_handle->should_suspend = false;

  m_handle->handle = CreateThread(NULL, 0, Private::thread_entry, (void*)start_param, 0, &m_handle->threadId);
  if(!m_handle->handle)
  {
    delete start_param;
    throw ThreadError(GetLastError(), "Could not create thread", P_SOURCEINFO);
  }
}

void Thread::kill() throw(LogicError, SystemError)
{
  if(!m_handle)
    return;

  if(current() == this)
    throw LogicError("Cannot kill own thread", P_SOURCEINFO);

  if(!TerminateThread(m_handle->handle, 0))
    throw SystemError(GetLastError(), "Could not kill thread", P_SOURCEINFO);

  Thread::destroyHandle(m_handle);
  m_handle = 0;
}

void Thread::yield() throw()
{
  Thread::sleep(1);
}

void Thread::sleep(unsigned int timeout) throw()
{
  SleepEx(timeout, FALSE);
}

void Thread::exit() throw()
{
  Thread* thread = current();

  thread->final();

  thread_handle_t* handle = thread->handle();

  handle->state = Stopped;
  handle->notsuspended_mutex.unlock();
  handle->running_mutex.unlock();

  Thread::destroyHandle(handle);
  thread->m_handle = 0;

  ExitThread(0);
}

}
