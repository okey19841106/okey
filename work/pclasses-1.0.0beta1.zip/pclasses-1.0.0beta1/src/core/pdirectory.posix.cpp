/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/pdirectory.h"
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <dirent.h>
#include <stdlib.h>
#include <errno.h>

namespace P {

using namespace std;

struct Directory::dir_handle_t {
  DIR* handle;
  dirent* current;
};

Directory::Directory(const char* path) throw(IOError)
{
  DIR* handle = opendir(path);
  if(!handle)
    throw IOError(errno, "Could not open directory", P_SOURCEINFO);

  m_handle = new dir_handle_t;
  m_handle->handle  = handle;
  m_handle->current = 0;
  m_path = path;
}

Directory::~Directory() throw()
{
  closedir(m_handle->handle);
  delete m_handle;
}

const char* Directory::operator++() throw(IOError)
{
  m_handle->current = readdir(m_handle->handle);
  if(m_handle->current)
    return m_handle->current->d_name;

  return 0;
}

const char* Directory::operator*() const throw()
{
  if(m_handle->current)
    return m_handle->current->d_name;

  return 0;
}

void Directory::rewind() throw()
{
  rewinddir(m_handle->handle);
  m_handle->current = 0;
}

void Directory::create(const char* path) throw(IOError)
{
  if(mkdir(path, 0440) == -1)
    throw IOError(errno, "Could not create directory", P_SOURCEINFO);
}

void Directory::remove(const char* path) throw(IOError)
{
  if(rmdir(path) == -1)
    throw IOError(errno, "Could not remove directory", P_SOURCEINFO);
}

void Directory::change(const char* path) throw(IOError)
{
  if(chdir(path) == -1)
    throw IOError(errno, "Could not change working directory", P_SOURCEINFO);
}

string Directory::current() throw(IOError)
{
  char path[4096];
  if(!getcwd(path, sizeof(path)))
    throw IOError(errno, "Could not get working directory", P_SOURCEINFO);
  return path;
}

string Directory::separator() throw()
{
  return "/";
}

string Directory::homeDir() throw()
{
  char* homeVar = getenv("HOME");
  return string(homeVar);
}

void Directory::getDriveList(list<string>& dl) throw()
{
  dl.clear();
  dl.push_back(string("/"));
}

}
