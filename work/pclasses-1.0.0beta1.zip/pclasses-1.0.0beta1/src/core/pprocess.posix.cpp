/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/pprocess.h"
#include "pclasses/pfileinfo.h"
#include "pclasses/pfile.h"
#include "pclasses/pdirectory.h"

#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <errno.h>

#include <map>
#include <sstream>

extern char **environ;

namespace P {

using namespace std;

void ProcessEnv::set(const char* name, const char* value)
{
  ostringstream os;
  os << name << "=" << value;
  ::putenv(const_cast<char*>(os.str().c_str()));
}

void ProcessEnv::unset(const char* name)
{
  ProcessEnv::set(name,"");
}

const char* ProcessEnv::get(const char* name)
{
  return ::getenv(name);
}


struct Process::process_handle_t {
  pid_t pid;
};

static map<pid_t, Process*> g_procs;

void Process::start(commMode_t mode) throw(SystemError,IOError,LogicError)
{
  if(m_state != Stopped)
    throw LogicError("Process is already running", P_SOURCEINFO);

  // test if file is existent
  FileInfo info = File::stat(m_program.c_str());

  int ret;
  int infds[2]  = { -1, -1 };
  int outfds[2] = { -1, -1 };
  int errfds[2] = { -1, -1 };

  // save program dir, name and args
  string dir        = m_dir;
  string program    = m_program;
  list<string> args = m_args;

  if(mode & StdIn)
  {
    ret = pipe(infds);
    if(ret == -1)
      throw IOError(errno, "Could not create pipe", P_SOURCEINFO);
  }

  if(mode & StdOut)
  {
    ret = pipe(outfds);
    if(ret == -1)
    {
      close(infds[0]); close(infds[1]);
      throw IOError(errno, "Could not create pipe", P_SOURCEINFO);
    }
  }

  if(mode & StdErr)
  {
    ret = pipe(errfds);
    if(ret == -1)
    {
      close(infds[0]); close(infds[1]);
      close(outfds[0]); close(outfds[1]);
      throw IOError(errno, "Could not create pipe", P_SOURCEINFO);
    }
  }

  pid_t child = fork();

  // fork failed
  if(child == -1)
  {
    close(infds[0]); close(infds[1]);
    close(outfds[0]); close(outfds[1]);
    close(errfds[0]); close(errfds[1]);
    throw SystemError(errno, "Could not start process", P_SOURCEINFO);
  }
  // child process
  else if(child == 0)
  {
    close(0); close(1); close(2);

    if(mode & StdIn)
    {
      close(infds[1]);
      ret = dup2(infds[0], 0);
      close(infds[0]);

      if(ret == -1)
        _exit(127);
    }

    if(mode & StdOut)
    {
      close(outfds[0]);
      ret = dup2(outfds[1], 1);
      close(outfds[1]);

      if(ret == -1)
        _exit(127);
    }

    if(mode & StdErr)
    {
      close(outfds[0]);
      ret = dup2(errfds[1], 2);
      close(errfds[1]);

      if(ret == -1)
        _exit(127);
    }

    if(!dir.empty())
      Directory::change(dir.c_str());

    const char* argv[256];
    int argc = 0;

    argv[argc++] = program.c_str();

    for(list<string>::const_iterator argi = args.begin(); argi != args.end() && argc < 256; argi++)
      argv[argc++] = (*argi).c_str();

    argv[argc] = 0;

    // exec binary, does not return except on error
    execve(m_program.c_str(), (char**)argv, environ);
    _exit(127);
  }

  if(mode & StdIn)
    close(infds[0]);

  if(mode & StdOut)
    close(outfds[1]);

  if(mode & StdErr)
    close(errfds[1]);

  g_procs[child] = this;

  m_handle = new process_handle_t;
  m_handle->pid = child;

  m_procIO = new ProcessIO(infds[1], outfds[0], errfds[0]);
  m_state = Running;
}

void Process::stop() throw(SystemError)
{
  if(m_state != Running && m_state != Stopping)
    throw LogicError("Process is not active", P_SOURCEINFO);

  int ret = ::kill(m_handle->pid, SIGTERM);
  if(ret == -1)
    throw SystemError(errno, "Could not stop process", P_SOURCEINFO);

  m_state = Stopping;
}

void Process::kill() throw(SystemError)
{
  if(m_state != Running && m_state != Stopping)
    throw LogicError("Process is not active", P_SOURCEINFO);

  int ret = ::kill(m_handle->pid, SIGKILL);
  if(ret == -1)
    throw SystemError(errno, "Could not kill process", P_SOURCEINFO);

  m_state = Stopping;
}

bool Process::tryWait(int& exitCode) throw(SystemError)
{
  int status = 0;

  pid_t pid = waitpid(m_handle->pid, &status, WNOHANG|WUNTRACED);
  if(pid == -1)
    throw SystemError(errno, "Could not wait for process", P_SOURCEINFO);
  else if(pid == 0)
    return false;

  if(WIFEXITED(status) || WIFSIGNALED(status))
  {
    exitCode = WIFEXITED(status) ? WEXITSTATUS(status) : 127;
    m_state = Stopped;

    delete m_handle;
    m_handle = 0;

    delete m_procIO;
    m_procIO = 0;

    g_procs.erase(pid);
    return true;
  }

  return false;
}

int Process::wait() throw(SystemError)
{
  int status = 0;

  pid_t pid = waitpid(m_handle->pid, &status, WUNTRACED);
  if(pid == -1)
    throw SystemError(errno, "Could not wait for process", P_SOURCEINFO);

  m_state = Stopped;

  delete m_handle;
  m_handle = 0;

  delete m_procIO;
  m_procIO = 0;

  g_procs.erase(pid);
  return WIFEXITED(status) ? WEXITSTATUS(status) : 127;
}

Process* Process::tryWaitAny(int& exitCode) throw(SystemError)
{
  int status = 0;

  pid_t pid = waitpid(-1, &status, WUNTRACED|WNOHANG);
  if(pid == -1)
    throw SystemError(errno, "Could not wait for process", P_SOURCEINFO);
  else if(pid == 0)
    return 0;

  if(WIFEXITED(status) || WIFSIGNALED(status))
  {
    map<pid_t, Process*>::iterator i = g_procs.find(pid);
    if(i != g_procs.end())
    {
      Process* proc = i->second;

      proc->m_state = Stopped;

      delete proc->m_handle;
      proc->m_handle = 0;

      delete proc->m_procIO;
      proc->m_procIO = 0;

      g_procs.erase(i);

      exitCode = WIFEXITED(status) ? WEXITSTATUS(status) : 127;
      return proc;
    }

    return 0;
  }

  return 0;
}

Process* Process::waitAny(int& exitCode) throw(SystemError)
{
  int status = 0;

  pid_t pid = waitpid(-1, &status, WUNTRACED);
  if(pid == -1)
    throw SystemError(errno, "Could not wait for process", P_SOURCEINFO);

  if(WIFEXITED(status) || WIFSIGNALED(status))
  {
    map<pid_t, Process*>::iterator i = g_procs.find(pid);
    if(i != g_procs.end())
    {
      Process* proc = i->second;

      proc->m_state = Stopped;

      delete proc->m_handle;
      proc->m_handle = 0;

      delete proc->m_procIO;
      proc->m_procIO = 0;

      g_procs.erase(i);

      exitCode = WIFEXITED(status) ? WEXITSTATUS(status) : 127;
      return proc;
    }

    return 0;
  }

  return 0;
}

}
