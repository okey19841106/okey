/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/config.h"
#include "pclasses/prwlock.h"
#include "pclasses/pthread_.h"
#include "private.h"

#include <errno.h>
#include <pthread.h>

#ifdef HAVE_SYSV_SHAREDMEM
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#endif

namespace P {

struct RWLock::rwlock_handle_t
{
  pthread_rwlock_t rwlock;
  int              shmid;
  unsigned int     refcount;
};

RWLock::RWLock(const char* name /*=0*/) throw(SyncError)
{
  pthread_rwlockattr_t attr;
  pthread_rwlockattr_init(&attr);

  if(name)
  {
    #if defined(HAVE_SYSV_SHAREDMEM) && defined(HAVE_PTHREAD_RWLOCKATTR_SETPSHARED)
    key_t shmkey = ftok(name, 0);

    int shmid = shmget(shmkey, sizeof(rwlock_handle_t), IPC_CREAT);
    if(shmid == -1)
      throw SyncError(errno, "Could not get shared memory segment", P_SOURCEINFO);

    m_handle = (rwlock_handle_t*)shmat(shmid, 0, 0);
    m_handle->shmid    = shmid;
    m_handle->refcount = 1;
    pthread_rwlockattr_setpshared(&attr,PTHREAD_PROCESS_SHARED);
    #else
    throw SyncError(0, "Process shared rwlock's not supported", P_SOURCEINFO);
    #endif
  }
  else
  {
    m_handle = new rwlock_handle_t;
    m_handle->shmid    = -1;
    m_handle->refcount = 1;
    #ifdef HAVE_PTHREAD_RWLOCKATTR_SETPSHARED
    pthread_rwlockattr_setpshared(&attr, PTHREAD_PROCESS_PRIVATE);
    #endif
  }

  pthread_rwlock_init(&m_handle->rwlock, &attr);
}

RWLock::~RWLock() throw()
{
  if((--m_handle->refcount) == 0)
    pthread_rwlock_destroy(&m_handle->rwlock);

  #ifdef HAVE_SYSV_SHAREDMEM
  if(m_handle->shmid != -1)
  {
    if(!m_handle->refcount)
      shmctl(m_handle->shmid,IPC_RMID,0);

    shmdt((void*)m_handle);
  }
  else
  #endif
    delete m_handle;
}

void RWLock::readLock() throw(SyncError)
{
  int ret = pthread_rwlock_rdlock(&m_handle->rwlock);
  if(ret != 0)
    throw SyncError(ret, "Could not read-lock read-write lock", P_SOURCEINFO);
}

bool RWLock::tryReadLock(unsigned int timeout) throw(SyncError)
{
  int ret;
  if(!timeout)
  {
    ret = pthread_rwlock_tryrdlock(&m_handle->rwlock);
  }
  else
  {
    #ifndef HAVE_PTHREAD_RWLOCK_TIMEDLOCK
    struct timeval tv;
    get_timeout(&tv, timeout, TIMEOUT_ABSOLUTE);
    while(1)
    {
      ret = pthread_rwlock_tryrdlock(&m_handle->rwlock);
      if((ret != EBUSY && ret != ETIMEDOUT) || timeout_elapsed(&tv))
        break;

      Thread::yield();
    }
    #else
    timespec ts;
    ret = pthread_rwlock_timedrdlock(&m_handle->rwlock, get_timeout(&ts, timeout, TIMEOUT_ABSOLUTE));
    #endif
  }

  switch(ret)
  {
    case 0:
      break;

    case EBUSY:
    case ETIMEDOUT:
      return false;

    default:
      throw SyncError(ret, "Could not read-lock read-write lock", P_SOURCEINFO);
  }

  return true;
}

void RWLock::writeLock() throw(SyncError)
{
  int ret = pthread_rwlock_wrlock(&m_handle->rwlock);
  if(ret != 0)
    throw SyncError(ret, "Could not write-lock read-write lock", P_SOURCEINFO);
}

bool RWLock::tryWriteLock(unsigned int timeout) throw(SyncError)
{
  int ret;
  if(!timeout)
    ret = pthread_rwlock_trywrlock(&m_handle->rwlock);
  else
  {
    #ifndef HAVE_PTHREAD_RWLOCK_TIMEDLOCK
    struct timeval tv;
    get_timeout(&tv, timeout, TIMEOUT_ABSOLUTE);
    while(1)
    {
      ret = pthread_rwlock_trywrlock(&m_handle->rwlock);
      if((ret != EBUSY && ret != ETIMEDOUT) || timeout_elapsed(&tv))
        break;

      Thread::yield();
    }
    #else
    timespec ts;
    ret = pthread_rwlock_timedwrlock(&m_handle->rwlock, get_timeout(&ts, timeout, TIMEOUT_RELATIVE));
    #endif
  }

  switch(ret)
  {
    case 0:
      break;

    case EBUSY:
    case ETIMEDOUT:
      return false;

    default:
      throw SyncError(ret, "Could not write-lock read-write lock", P_SOURCEINFO);
  }

  return true;
}

void RWLock::unlock() throw(SyncError)
{
  int ret = pthread_rwlock_unlock(&m_handle->rwlock);
  if(ret != 0)
    throw SyncError(ret, "Could not unlock read-write lock", P_SOURCEINFO);
}

}
