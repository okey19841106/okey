/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/config.h"
#include "pclasses/pmutex.h"
#include "pclasses/pthread_.h"
#include "private.h"

#include <errno.h>
#include <pthread.h>

#ifdef HAVE_SYSV_SHAREDMEM
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#endif

namespace P {

struct Mutex::mutex_handle_t
{
  pthread_mutex_t  mutex;
  int              shmid;
  unsigned int     refcount;
};

Mutex::Mutex(const char* name /*=0*/) throw(SyncError)
{
  pthread_mutexattr_t attr;
  pthread_mutexattr_init(&attr);
  pthread_mutexattr_settype(&attr,PTHREAD_MUTEX_RECURSIVE);

  if(name)
  {
    #if defined(HAVE_SYSV_SHAREDMEM) && defined(HAVE_PTHREAD_MUTEXATTR_SETPSHARED)
    key_t shmkey = ftok(name, 0);

    int shmid = shmget(shmkey, sizeof(mutex_handle_t), IPC_CREAT);
    if(shmid == -1)
      throw SyncError(errno, "Could not get shared memory segment", P_SOURCEINFO);

    m_handle = (mutex_handle_t*)shmat(shmid,0,0);
    m_handle->shmid    = shmid;
    m_handle->refcount = 1;
    pthread_mutexattr_setpshared(&attr,PTHREAD_PROCESS_SHARED);
    #else
    throw SyncError(0, "Process-shared mutexes are not supported", P_SOURCEINFO);
    #endif
  }
  else
  {
    m_handle = new mutex_handle_t;
    m_handle->shmid    = -1;
    m_handle->refcount = 1;

    #ifdef HAVE_PTHREAD_MUTEXATTR_SETPSHARED
    pthread_mutexattr_setpshared(&attr,PTHREAD_PROCESS_PRIVATE);
    #endif
  }

  pthread_mutex_init(&m_handle->mutex,&attr);
}

Mutex::~Mutex() throw()
{
  if((--m_handle->refcount) == 0)
    pthread_mutex_destroy(&m_handle->mutex);

  #ifdef HAVE_SYSV_SHAREDMEM
  if(m_handle->shmid != -1)
  {
    int shmid = m_handle->shmid;

    if(!m_handle->refcount)
      shmctl(shmid,IPC_RMID,0);

    shmdt((void*)m_handle);
  }
  else
  #endif
    delete m_handle;
}

void Mutex::lock() throw(SyncError)
{
  int ret = pthread_mutex_lock(&m_handle->mutex);
  if(ret != 0)
    throw SyncError(ret, "Could not lock mutex", P_SOURCEINFO);
}

bool Mutex::tryLock(unsigned int timeout) throw(SyncError)
{
  int ret;
  if(!timeout)
  {
    ret = pthread_mutex_trylock(&m_handle->mutex);
  }
  else
  {
    #ifndef HAVE_PTHREAD_MUTEX_TIMEDLOCK
    struct timeval tv;
    get_timeout(&tv, timeout, TIMEOUT_ABSOLUTE);
    while(1)
    {
      ret = pthread_mutex_trylock(&m_handle->mutex);
      if((ret != EBUSY && ret != ETIMEDOUT) || timeout_elapsed(&tv))
        break;

      Thread::yield();
    }
    #else
    timespec ts;
    ret = pthread_mutex_timedlock(&m_handle->mutex, get_timeout(&ts, timeout, TIMEOUT_ABSOLUTE));
    #endif
  }

  switch(ret)
  {
    case 0:
      break;

    case EBUSY:
    case ETIMEDOUT:
      return false;

    default:
      throw SyncError(ret, "Could not lock mutex", P_SOURCEINFO);
  }

  return true;
}

void Mutex::unlock() throw(SyncError)
{
  int ret = pthread_mutex_unlock(&m_handle->mutex);
  if(ret != 0)
    throw SyncError(ret, "Could not unlock mutex", P_SOURCEINFO);
}

}
