/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/pthreadkey.h"
#include <pthread.h>

namespace P {

struct ThreadKeyImpl::key_handle_t
{
  pthread_key_t key;
};

ThreadKeyImpl::ThreadKeyImpl()
: m_handle(new key_handle_t)
{
  pthread_key_create(&m_handle->key, 0);
}

ThreadKeyImpl::~ThreadKeyImpl()
{
  pthread_key_delete(m_handle->key);
  delete m_handle;
}

void ThreadKeyImpl::set(void* ptr) throw()
{
  pthread_setspecific(m_handle->key, ptr);
}

void* ThreadKeyImpl::get() throw()
{
  return pthread_getspecific(m_handle->key);
}

}
