/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/pprocess.h"
#include "pclasses/pfileinfo.h"
#include "pclasses/pfile.h"

#include <windows.h>
#include <stdlib.h>
#include <sstream>

namespace P {

using namespace std;

void ProcessEnv::set(const char* name, const char* value)
{
  ostringstream os;
  os << name << "=" << value;
  ::_putenv(os.str().c_str());
}

void ProcessEnv::unset(const char* name)
{
  ProcessEnv::set(name,"");
}

const char* ProcessEnv::get(const char* name)
{
  return ::getenv(name);
}


struct Process::process_handle_t {
};

void Process::start(commMode_t mode) throw(SystemError,IOError,LogicError)
{
  if(m_state != Stopped)
    throw LogicError("Process is already running", P_SOURCEINFO);

  // test if file is existent
  FileInfo info = File::stat(m_program.c_str());

  //@todo implement win32 process

  m_state = Running;
}

void Process::stop() throw(SystemError)
{
  if(m_state != Running && m_state != Stopping)
    throw LogicError("Process is not active", P_SOURCEINFO);

  m_state = Stopping;
}

void Process::kill() throw(SystemError)
{
  if(m_state != Running && m_state != Stopping)
    throw LogicError("Process is not active", P_SOURCEINFO);

}

bool Process::tryWait(int& exitCode) throw(SystemError)
{
  //@todo implement win32
  return false;
}

int Process::wait() throw(SystemError)
{
  //@todo implement win32
  return false;
}

Process* Process::tryWaitAny(int& exitCode) throw(SystemError)
{
  //@todo implement win32
  return 0;
}

Process* Process::waitAny(int& exitCode) throw(SystemError)
{
  //@todo implement win32
  return 0;
}

}
