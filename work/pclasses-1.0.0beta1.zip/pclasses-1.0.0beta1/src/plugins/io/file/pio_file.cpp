/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/pplugin.h"
#include "pclasses/piorequest.h"
#include "pclasses/piohandler.h"
#include "pclasses/pfile.h"
#include "pclasses/pdirectory.h"

namespace P {

using namespace std;

class File_IOHandler: public IOHandler, public PluginBase {
  public:
    File_IOHandler();
    ~File_IOHandler();

    IORequest_Get* get(const URL& url);

    IORequest_Put* put(const URL& url);

    IORequest_Unlink* unlink(const URL& url);

    IORequest_MakeDir* mkdir(const URL& url);

    IORequest_RemoveDir* rmdir(const URL& url);

    IORequest_ListDir* list(const URL& url);

    void finish(IORequest* job);

    static PluginBase* create()
    { return new File_IOHandler(); }

    static void destroy(PluginBase* handler)
    { delete handler; }

};

class IORequest_Get_File: public IORequest_Get {
  public:
    IORequest_Get_File(IOHandler* handler, const URL& url);
    ~IORequest_Get_File();

    void open();
    void close();
    size_t receive(char* buff, size_t count);

  private:
    File* m_file;
};

class IORequest_Put_File: public IORequest_Put {
  public:
    IORequest_Put_File(IOHandler* handler, const URL& url);
    ~IORequest_Put_File();

    void open();
    void close();
    size_t send(const char* buff, size_t count);

  private:
    File* m_file;
};

class IORequest_Unlink_File: public IORequest_Unlink {
  public:
    IORequest_Unlink_File(IOHandler* handler, const URL& url);
    ~IORequest_Unlink_File();

    void unlink();
};

class IORequest_MakeDir_File: public IORequest_MakeDir {
  public:
    IORequest_MakeDir_File(IOHandler* handler, const URL& url);
    ~IORequest_MakeDir_File();

    void mkdir();
};

class IORequest_RemoveDir_File: public IORequest_RemoveDir {
  public:
    IORequest_RemoveDir_File(IOHandler* handler, const URL& url);
    ~IORequest_RemoveDir_File();

    void rmdir();
};

class IORequest_ListDir_File: public IORequest_ListDir {
  public:
    IORequest_ListDir_File(IOHandler* handler, const URL& url);
    ~IORequest_ListDir_File();

    void list();
};


// export the handler object
P_PLUGINS_BEGIN
  P_PLUGIN(IOHandler, "file", File_IOHandler)
P_PLUGINS_END

File_IOHandler::File_IOHandler()
{
}

File_IOHandler::~File_IOHandler()
{
}

IORequest_Get* File_IOHandler::get(const URL& url)
{
  return new IORequest_Get_File(this, url);
}

IORequest_Put* File_IOHandler::put(const URL& url)
{
  return new IORequest_Put_File(this, url);
}

IORequest_Unlink* File_IOHandler::unlink(const URL& url)
{
  return new IORequest_Unlink_File(this, url);
}

IORequest_MakeDir* File_IOHandler::mkdir(const URL& url)
{
  return new IORequest_MakeDir_File(this, url);
}

IORequest_RemoveDir* File_IOHandler::rmdir(const URL& url)
{
  return new IORequest_RemoveDir_File(this, url);
}

IORequest_ListDir* File_IOHandler::list(const URL& url)
{
  return new IORequest_ListDir_File(this, url);
}

void File_IOHandler::finish(IORequest* job)
{
  delete job;
}


IORequest_Get_File::IORequest_Get_File(IOHandler* handler, const URL& url)
: IORequest_Get(handler, url), m_file(0)
{
}

IORequest_Get_File::~IORequest_Get_File()
{
  if(m_file)
    close();
}

void IORequest_Get_File::open()
{
  if(m_file)
    throw LogicError("Transfer has already been opened", P_SOURCEINFO);

  try
  {
    m_file = new File(url().path().c_str(), File::Read, File::Normal, File::OpenExisting);
  }
  catch(...)
  {
    setState(Failed);
    throw;
  }

  setState(Open);
}

void IORequest_Get_File::close()
{
  if(!m_file)
    throw LogicError("Transfer has not been opened", P_SOURCEINFO);

  setState(Finished);

  delete m_file;
  m_file = 0;
}

size_t IORequest_Get_File::receive(char* buff, size_t count)
{
  if(!m_file)
    throw LogicError("Transfer has not been opened", P_SOURCEINFO);

  size_t ret = 0;
  try
  {
    ret = m_file->read(buff, count);
  }
  catch(...)
  {
    setState(Failed);
    throw;

  }

  if(state() != Transfer)
    setState(Transfer);

  return ret;
}


IORequest_Put_File::IORequest_Put_File(IOHandler* handler, const URL& url)
: IORequest_Put(handler, url), m_file(0)
{
}

IORequest_Put_File::~IORequest_Put_File()
{
  if(m_file)
    close();
}

void IORequest_Put_File::open()
{
  if(m_file)
    throw LogicError("Transfer has already been opened", P_SOURCEINFO);

  try
  {
    m_file = new File(url().path().c_str(), File::Write, File::Normal, File::OpenCreate);
  }
  catch(...)
  {
    setState(Failed);
    throw;
  }

  setState(Open);
}

void IORequest_Put_File::close()
{
  if(!m_file)
    throw LogicError("Transfer has not been opened", P_SOURCEINFO);

  setState(Finished);

  delete m_file;
  m_file = 0;
}

size_t IORequest_Put_File::send(const char* buff, size_t count)
{
  if(!m_file)
    throw LogicError("Transfer has not been opened", P_SOURCEINFO);

  size_t ret = 0;
  try
  {
    ret = m_file->write(buff,count);
  }
  catch(...)
  {
    setState(Failed);
    throw;
  }

  if(state() != Transfer)
    setState(Transfer);

  return ret;
}


IORequest_Unlink_File::IORequest_Unlink_File(IOHandler* handler, const URL& url)
: IORequest_Unlink(handler,url)
{
}

IORequest_Unlink_File::~IORequest_Unlink_File()
{
}

void IORequest_Unlink_File::unlink()
{
  File::unlink(url().path().c_str());
  setState(Finished);
}


IORequest_MakeDir_File::IORequest_MakeDir_File(IOHandler* handler, const URL& url)
: IORequest_MakeDir(handler,url)
{
}

IORequest_MakeDir_File::~IORequest_MakeDir_File()
{
}

void IORequest_MakeDir_File::mkdir()
{
  Directory::create(url().path().c_str());
  setState(Finished);
}


IORequest_RemoveDir_File::IORequest_RemoveDir_File(IOHandler* handler, const URL& url)
: IORequest_RemoveDir(handler,url)
{
}

IORequest_RemoveDir_File::~IORequest_RemoveDir_File()
{
}

void IORequest_RemoveDir_File::rmdir()
{
  Directory::remove(url().path().c_str());
  setState(Finished);
}


IORequest_ListDir_File::IORequest_ListDir_File(IOHandler* handler, const URL& url)
: IORequest_ListDir(handler,url)
{
}

IORequest_ListDir_File::~IORequest_ListDir_File()
{
}

void IORequest_ListDir_File::list()
{
  setState(Finished);
}

}
