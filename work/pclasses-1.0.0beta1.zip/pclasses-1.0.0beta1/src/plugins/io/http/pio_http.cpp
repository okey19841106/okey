/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/pplugin.h"
#include "pclasses/piorequest.h"
#include "pclasses/piohandler.h"
#include "pclasses/pnetdb.h"
#include "pclasses/phttpclient.h"
#include <memory>

namespace P {

using namespace std;

class HTTP_IOHandler: public PluginBase, public IOHandler {
  public:
    HTTP_IOHandler();
    ~HTTP_IOHandler();

    IORequest_Get* get(const URL& url);

    IORequest_Put* put(const URL& url);

    IORequest_Unlink* unlink(const URL& url);

    IORequest_MakeDir* mkdir(const URL& url);

    IORequest_RemoveDir* rmdir(const URL& url);

    IORequest_ListDir* list(const URL& url);

    void finish(IORequest* job);

    static PluginBase* create()
    { return new HTTP_IOHandler(); }

    static void destroy(PluginBase* handler)
    { delete handler; }

};

class IORequest_Get_HTTP: public IORequest_Get {
  public:
    IORequest_Get_HTTP(IOHandler* handler, const URL& url);
    ~IORequest_Get_HTTP();

    void open();
    void close();
    size_t receive(char* buff, size_t count);

  private:
    HTTPClient*   m_client;
    auto_ptr<
     HTTPResponse>  m_resp;
};

class IORequest_Put_HTTP: public IORequest_Put {
  public:
    IORequest_Put_HTTP(IOHandler* handler, const URL& url);
    ~IORequest_Put_HTTP();

    void open();
    void close();
    size_t send(const char* buff, size_t count);

  private:
    HTTPClient* m_client;
};

class IORequest_Unlink_HTTP: public IORequest_Unlink {
  public:
    IORequest_Unlink_HTTP(IOHandler* handler, const URL& url);
    ~IORequest_Unlink_HTTP();

    void unlink();
};

class IORequest_MakeDir_HTTP: public IORequest_MakeDir {
  public:
    IORequest_MakeDir_HTTP(IOHandler* handler, const URL& url);
    ~IORequest_MakeDir_HTTP();

    void mkdir();
};

class IORequest_RemoveDir_HTTP: public IORequest_RemoveDir {
  public:
    IORequest_RemoveDir_HTTP(IOHandler* handler, const URL& url);
    ~IORequest_RemoveDir_HTTP();

    void rmdir();
};

class IORequest_ListDir_HTTP: public IORequest_ListDir {
  public:
    IORequest_ListDir_HTTP(IOHandler* handler, const URL& url);
    ~IORequest_ListDir_HTTP();

    void list();
};


// export the handler object
P_PLUGINS_BEGIN
  P_PLUGIN(IOHandler, "http", HTTP_IOHandler)
P_PLUGINS_END

HTTP_IOHandler::HTTP_IOHandler()
{
}

HTTP_IOHandler::~HTTP_IOHandler()
{
}

IORequest_Get* HTTP_IOHandler::get(const URL& url)
{
  return new IORequest_Get_HTTP(this, url);
}

IORequest_Put* HTTP_IOHandler::put(const URL& url)
{
  return new IORequest_Put_HTTP(this, url);
}

IORequest_Unlink* HTTP_IOHandler::unlink(const URL& url)
{
  return new IORequest_Unlink_HTTP(this, url);
}

IORequest_MakeDir* HTTP_IOHandler::mkdir(const URL& url)
{
  return new IORequest_MakeDir_HTTP(this, url);
}

IORequest_RemoveDir* HTTP_IOHandler::rmdir(const URL& url)
{
  return new IORequest_RemoveDir_HTTP(this, url);
}

IORequest_ListDir* HTTP_IOHandler::list(const URL& url)
{
  return new IORequest_ListDir_HTTP(this, url);
}

void HTTP_IOHandler::finish(IORequest* job)
{
  delete job;
}


IORequest_Get_HTTP::IORequest_Get_HTTP(IOHandler* handler, const URL& url)
: IORequest_Get(handler, url), m_client(0)
{
}

IORequest_Get_HTTP::~IORequest_Get_HTTP()
{
  if(m_client)
    close();
}

void IORequest_Get_HTTP::open()
{
  if(m_client)
    throw LogicError("Transfer has already been opened", P_SOURCEINFO);

  try
  {
    NetDb::HostEntry he = NetDb::hostByName(url().host(), AF_INET);

    m_client = new HTTPClient(AF_INET);
    m_client->connect(he.addr(0), url().port());

    HTTPRequest req(HTTPRequest::METHOD_GET, url());
    req.header().setConnection("close");
    m_client->sendRequest(req);

    auto_ptr<HTTPResponse> resp = m_client->readResponse();
  }
  catch(...)
  {
    if(m_client)
    {
      delete m_client;
      m_client = 0;
    }

    setState(Failed);
    throw;
  }

  setState(Open);
}

void IORequest_Get_HTTP::close()
{
  if(!m_client)
    throw LogicError("Transfer has not been opened", P_SOURCEINFO);

  delete m_client;
  m_client = 0;

  setState(Finished);
}

size_t IORequest_Get_HTTP::receive(char* buff, size_t count)
{
  if(!m_client)
    throw LogicError("Transfer has not been opened", P_SOURCEINFO);

  size_t ret = 0;
  try
  {
    ret = m_client->readBody(*m_resp, buff, count);
  }
  catch(...)
  {
    setState(Failed);
    throw;
  }

  if(state() != Transfer)
    setState(Transfer);

  return ret;
}


IORequest_Put_HTTP::IORequest_Put_HTTP(IOHandler* handler, const URL& url)
: IORequest_Put(handler, url), m_client(0)
{
}

IORequest_Put_HTTP::~IORequest_Put_HTTP()
{
  if(m_client)
    close();
}

void IORequest_Put_HTTP::open()
{
  if(m_client)
    throw LogicError("Transfer has already been opened", P_SOURCEINFO);

  try
  {
    NetDb::HostEntry he = NetDb::hostByName(url().host(), AF_INET);

    m_client = new HTTPClient(AF_INET);
    m_client->connect(he.addr(0), url().port());

    HTTPRequest req(HTTPRequest::METHOD_PUT, url());
    req.header().setConnection("close");
    m_client->sendRequest(req);

    auto_ptr<HTTPResponse> resp = m_client->readResponse();

    if(resp->code() != 200 || resp->code() != 201 || resp->code() != 204)
      throw RuntimeError("Invalid server response", P_SOURCEINFO);
  }
  catch(...)
  {
    if(m_client)
    {
      delete m_client;
      m_client = 0;
    }

    setState(Failed);
    throw;
  }

  setState(Open);
}

void IORequest_Put_HTTP::close()
{
  if(!m_client)
    throw LogicError("Transfer has not been opened", P_SOURCEINFO);

  delete m_client;
  m_client = 0;

  setState(Finished);
}

size_t IORequest_Put_HTTP::send(const char* buff, size_t count)
{
  //@todo
  setState(Failed);
  throw RuntimeError("Unimplemented I/O method", P_SOURCEINFO);

  return 0;
}


IORequest_Unlink_HTTP::IORequest_Unlink_HTTP(IOHandler* handler, const URL& url)
: IORequest_Unlink(handler,url)
{
}

IORequest_Unlink_HTTP::~IORequest_Unlink_HTTP()
{
}

void IORequest_Unlink_HTTP::unlink()
{
  //@todo
  setState(Failed);
  throw RuntimeError("Unimplemented I/O method", P_SOURCEINFO);
}


IORequest_MakeDir_HTTP::IORequest_MakeDir_HTTP(IOHandler* handler, const URL& url)
: IORequest_MakeDir(handler,url)
{
}

IORequest_MakeDir_HTTP::~IORequest_MakeDir_HTTP()
{
}

void IORequest_MakeDir_HTTP::mkdir()
{
  //@todo
  setState(Failed);
  throw RuntimeError("Unimplemented I/O method", P_SOURCEINFO);
}


IORequest_RemoveDir_HTTP::IORequest_RemoveDir_HTTP(IOHandler* handler, const URL& url)
: IORequest_RemoveDir(handler,url)
{
}

IORequest_RemoveDir_HTTP::~IORequest_RemoveDir_HTTP()
{
}

void IORequest_RemoveDir_HTTP::rmdir()
{
  //@todo
  setState(Failed);
  throw RuntimeError("Unimplemented I/O method", P_SOURCEINFO);
}


IORequest_ListDir_HTTP::IORequest_ListDir_HTTP(IOHandler* handler, const URL& url)
: IORequest_ListDir(handler,url)
{
}

IORequest_ListDir_HTTP::~IORequest_ListDir_HTTP()
{
}

void IORequest_ListDir_HTTP::list()
{
  //@todo
  setState(Failed);
  throw RuntimeError("Unimplemented I/O method", P_SOURCEINFO);
}


}
