/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/pplugin.h"
#include "pclasses/piorequest.h"
#include "pclasses/piohandler.h"
#include "pclasses/pftpclient.h"
#include <memory>

namespace P {

using namespace std;

class FTP_IOHandler: public PluginBase, public IOHandler {
  public:
    FTP_IOHandler();
    ~FTP_IOHandler();

    IORequest_Get* get(const URL& url);

    IORequest_Put* put(const URL& url);

    IORequest_Unlink* unlink(const URL& url);

    IORequest_MakeDir* mkdir(const URL& url);

    IORequest_RemoveDir* rmdir(const URL& url);

    IORequest_ListDir* list(const URL& url);

    void finish(IORequest* job);

    static PluginBase* create()
    { return new FTP_IOHandler(); }

    static void destroy(PluginBase* handler)
    { delete handler; }

};

class IORequest_Get_FTP: public IORequest_Get {
  public:
    IORequest_Get_FTP(IOHandler* handler, const URL& url);
    ~IORequest_Get_FTP();

    void open();
    void close();
    size_t receive(char* buff, size_t count);

  private:
    FTPClient* m_client;
};

class IORequest_Put_FTP: public IORequest_Put {
  public:
    IORequest_Put_FTP(IOHandler* handler, const URL& url);
    ~IORequest_Put_FTP();

    void open();
    void close();
    size_t send(const char* buff, size_t count);

  private:
    FTPClient* m_client;
};

class IORequest_Unlink_FTP: public IORequest_Unlink {
  public:
    IORequest_Unlink_FTP(IOHandler* handler, const URL& url);
    ~IORequest_Unlink_FTP();

    void unlink();
};

class IORequest_MakeDir_FTP: public IORequest_MakeDir {
  public:
    IORequest_MakeDir_FTP(IOHandler* handler, const URL& url);
    ~IORequest_MakeDir_FTP();

    void mkdir();
};

class IORequest_RemoveDir_FTP: public IORequest_RemoveDir {
  public:
    IORequest_RemoveDir_FTP(IOHandler* handler, const URL& url);
    ~IORequest_RemoveDir_FTP();

    void rmdir();
};

class IORequest_ListDir_FTP: public IORequest_ListDir {
  public:
    IORequest_ListDir_FTP(IOHandler* handler, const URL& url);
    ~IORequest_ListDir_FTP();

    void list();
};


// export the handler object
P_PLUGINS_BEGIN
  P_PLUGIN(IOHandler, "ftp", FTP_IOHandler)
P_PLUGINS_END

FTP_IOHandler::FTP_IOHandler()
{
}

FTP_IOHandler::~FTP_IOHandler()
{
}

IORequest_Get* FTP_IOHandler::get(const URL& url)
{
  return new IORequest_Get_FTP(this, url);
}

IORequest_Put* FTP_IOHandler::put(const URL& url)
{
  return new IORequest_Put_FTP(this, url);
}

IORequest_Unlink* FTP_IOHandler::unlink(const URL& url)
{
  return new IORequest_Unlink_FTP(this, url);
}

IORequest_MakeDir* FTP_IOHandler::mkdir(const URL& url)
{
  return new IORequest_MakeDir_FTP(this, url);
}

IORequest_RemoveDir* FTP_IOHandler::rmdir(const URL& url)
{
  return new IORequest_RemoveDir_FTP(this, url);
}

IORequest_ListDir* FTP_IOHandler::list(const URL& url)
{
  return new IORequest_ListDir_FTP(this, url);
}

void FTP_IOHandler::finish(IORequest* job)
{
  delete job;
}


FTPClient* FTPOpen(const URL& url)
{
  FTPClient* cl = 0;

  try
  {
    /* resolve known addresses for given hostname */
    NetDb::HostEntry he = NetDb::hostByName(url.host(), AF_INET);

    /* try to connect to known addreses returned in HostEntry.
      if all addresses have failed, throw out last exception */
    int i = 0;
    while(i < he.addrCount())
    {
      try
      {
        cl = new FTPClient(he.addr(i).family());
        cl->connect(he.addr(i), url.port());
      }
      catch(...)
      {
        if(cl)
        {
          delete cl;
          cl = 0;
        }

        ++i;

        /* throw out if last address has failed */
        if(i == he.addrCount())
          throw;

        continue;
      }

      break;
    }

    if(url.user().empty())
      cl->login("anonymous", "user@", "");
    else
      cl->login(url.user(), url.password());
  }
  catch(...)
  {
    if(cl)
    {
      delete cl;
      cl = 0;
    }

    throw;
  }

  return cl;
}


IORequest_Get_FTP::IORequest_Get_FTP(IOHandler* handler, const URL& url)
: IORequest_Get(handler, url), m_client(0)
{
}

IORequest_Get_FTP::~IORequest_Get_FTP()
{
  if(m_client)
    delete m_client;
}

void IORequest_Get_FTP::open()
{
  if(m_client)
    throw LogicError("Transfer has already been opened", P_SOURCEINFO);

  try
  {
    m_client = FTPOpen(url());
    m_client->setType(FTPClient::TypeImage);
    m_client->retrieve(url().path());
  }
  catch(...)
  {
    setState(Failed);
    throw;
  }

  setState(Open);
}

void IORequest_Get_FTP::close()
{
  if(!m_client)
    throw LogicError("Transfer has not been opened", P_SOURCEINFO);

  try
  {
    m_client->logout();
    m_client->close();
  }
  catch(...)
  {
  }

  setState(Finished);

  delete m_client;
  m_client = 0;
}

size_t IORequest_Get_FTP::receive(char* buff, size_t count)
{
  if(!m_client)
    throw LogicError("Transfer has not been opened", P_SOURCEINFO);

  size_t ret = 0;
  try
  {
    ret = m_client->dataConn()->read(buff, count);
  }
  catch(...)
  {
    setState(Failed);
    throw;
  }

  if(state() != Transfer)
    setState(Transfer);

  return ret;
}


IORequest_Put_FTP::IORequest_Put_FTP(IOHandler* handler, const URL& url)
: IORequest_Put(handler, url), m_client(0)
{
}

IORequest_Put_FTP::~IORequest_Put_FTP()
{
  if(m_client)
    delete m_client;
}

void IORequest_Put_FTP::open()
{
  if(m_client)
    throw LogicError("Transfer has already been opened", P_SOURCEINFO);

  try
  {
    m_client = FTPOpen(url());
    m_client->setType(FTPClient::TypeImage);
    m_client->store(url().path());
  }
  catch(...)
  {
    setState(Failed);
    throw;
  }

  setState(Open);
}

void IORequest_Put_FTP::close()
{
  if(!m_client)
    throw LogicError("Transfer has not been opened", P_SOURCEINFO);

  try
  {
    m_client->logout();
    m_client->close();
  }
  catch(...)
  {
  }

  setState(Finished);

  delete m_client;
  m_client = 0;
}

size_t IORequest_Put_FTP::send(const char* buff, size_t count)
{
  if(!m_client)
    throw LogicError("Transfer has not been opened", P_SOURCEINFO);

  size_t ret = 0;
  try
  {
    ret = m_client->dataConn()->write(buff, count);
  }
  catch(...)
  {
    setState(Failed);
    throw;
  }

  if(state() != Transfer)
    setState(Transfer);

  return ret;
}


IORequest_Unlink_FTP::IORequest_Unlink_FTP(IOHandler* handler, const URL& url)
: IORequest_Unlink(handler,url)
{
}

IORequest_Unlink_FTP::~IORequest_Unlink_FTP()
{
}

void IORequest_Unlink_FTP::unlink()
{
  try
  {
    auto_ptr<FTPClient> client = auto_ptr<FTPClient>(FTPOpen(url()));
    client->remove(url().path());
  }
  catch(FTPError& e)
  {
    setState(Failed);
    throw Error(e.what(), e.text(), P_SOURCEINFO);
  }
  catch(...)
  {
    setState(Failed);
    throw;
  }

  setState(Finished);
}


IORequest_MakeDir_FTP::IORequest_MakeDir_FTP(IOHandler* handler, const URL& url)
: IORequest_MakeDir(handler,url)
{
}

IORequest_MakeDir_FTP::~IORequest_MakeDir_FTP()
{
}

void IORequest_MakeDir_FTP::mkdir()
{
  try
  {
    auto_ptr<FTPClient> client = auto_ptr<FTPClient>(FTPOpen(url()));
    client->mkdir(url().path());
  }
  catch(FTPError& e)
  {
    setState(Failed);
    throw Error(e.what(), e.text(), P_SOURCEINFO);
  }
  catch(...)
  {
    setState(Failed);
    throw;
  }

  setState(Finished);
}


IORequest_RemoveDir_FTP::IORequest_RemoveDir_FTP(IOHandler* handler, const URL& url)
: IORequest_RemoveDir(handler,url)
{
}

IORequest_RemoveDir_FTP::~IORequest_RemoveDir_FTP()
{
}

void IORequest_RemoveDir_FTP::rmdir()
{
  try
  {
    auto_ptr<FTPClient> client = auto_ptr<FTPClient>(FTPOpen(url()));
    client->rmdir(url().path());
  }
  catch(FTPError& e)
  {
    setState(Failed);
    throw Error(e.what(), e.text(), P_SOURCEINFO);
  }
  catch(...)
  {
    setState(Failed);
    throw;
  }

  setState(Finished);
}


IORequest_ListDir_FTP::IORequest_ListDir_FTP(IOHandler* handler, const URL& url)
: IORequest_ListDir(handler,url)
{
}

IORequest_ListDir_FTP::~IORequest_ListDir_FTP()
{
}

void IORequest_ListDir_FTP::list()
{
  try
  {
    auto_ptr<FTPClient> client = auto_ptr<FTPClient>(FTPOpen(url()));
    FTPData* data = client->dir(url().path());

    char buffer[4096];
    size_t ret = 0;

    do
    {
      ret = data->read(buffer, sizeof(buffer));
      //@todo what todo?
    } while(ret > 0);
  }
  catch(FTPError& e)
  {
    setState(Failed);
    throw Error(e.what(), e.text(), P_SOURCEINFO);
  }
  catch(...)
  {
    setState(Failed);
    throw;
  }

  setState(Finished);
}

}
