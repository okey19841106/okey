/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/config.h"
#include "pclasses/ptypes.h"
#include "pclasses/psqlplugin.h"

#include <map>
#include <sstream>
#include <my_global.h>
#include <mysql.h>
#include <errmsg.h>

#ifdef HAVE_STRTOLL
  /* we use strtoll()/strtoull() for converting from strings
  to 64bit integers by default. */
#elif defined(HAVE__STRTOI64)
  /* we use _strtoi64()/_strtoui64() on win32 platforms */
  #define strtoll   _strtoi64
  #define strtoull  _strtoui64
#else
  /* we use strtol()/strtoul() for non 64-bit platforms or
    on platforms where sizeof(long) == 8. */
  #define strtoll   strtol
  #define strtoull  strtoul
#endif

namespace P {

using namespace std;

class MySQL_Error: public SQLError {
  public:
    MySQL_Error(MYSQL* mysql, const char* _what, const SourceInfo& _si) throw()
      : SQLError(mysql ? mysql_errno(mysql) : 0, _what,_si), m_text(mysql_error(mysql)) {}

    ~MySQL_Error() throw()
    {}
      
    BaseError* clone() const
    { return new MySQL_Error(*this); }
    
    string text() const throw()
    { return m_text; } 

  private:
    string m_text;

};

class MySQL_ConnectionHandle;

class MySQL_ResultHandle: public SQLDriver::ResultHandle {
  public:
    MySQL_ResultHandle(MySQL_ConnectionHandle& conn, MYSQL_RES* res);
    ~MySQL_ResultHandle();

    unsigned int columnCount() const throw();
    string columnName(unsigned int pos) const;
    
    bool fetch();

    const SQLValue& value(const string& name);
    const SQLValue& value(unsigned int field);

  private:
    void clearValues();

    MYSQL_RES* m_res;
    MYSQL_ROW  m_row;

    MySQL_ConnectionHandle&       m_conn;
    map<string, SQLValue*>        m_valuesByName;
    map<unsigned int, SQLValue*>  m_valuesByPos;
};

class MySQL_StatementHandle;

class MySQL_ConnectionHandle: public SQLDriver::ConnectionHandle {
  public:
    MySQL_ConnectionHandle(const string& user, const string& passwd,
                           const string& db, const string& host);

    ~MySQL_ConnectionHandle();

    auto_ptr<SQLDriver::StatementHandle> createStmt();

    inline void setState(state_t st) throw()
    { ConnectionHandle::setState(st); }

    MYSQL* handle() const throw()
    { return m_mysql; }

    void commit();

    void rollback();

  private:
    MYSQL* m_mysql;

};

class MySQL_StatementHandle: public SQLDriver::StatementHandle {
  public:
    MySQL_StatementHandle(MySQL_ConnectionHandle& conn);
    ~MySQL_StatementHandle();

    void prepare(const string& stmt);
    void exec();

    auto_ptr<SQLDriver::ResultHandle> result();

    sqlcount_t affectedRows() const throw();

    string sqlstr(const SQLValue& val) const throw();

  private:
    MySQL_ConnectionHandle& m_conn;
    string        m_stmt;
    sqlcount_t    m_affRows;
    MYSQL_RES*    m_res;
    
};


class MySQL_SQLDriverPlugin: public SQLDriver, public PluginBase {
  public:
    MySQL_SQLDriverPlugin() {}
    ~MySQL_SQLDriverPlugin() {}

    ConnectionHandle* connect(const string& user, const string& passwd, 
                              const string& db, const string& host) throw(SQLError)
    { return new MySQL_ConnectionHandle(user, passwd, db, host); }
    
    void close(ConnectionHandle* handle) throw()
    { delete handle; }

    static PluginBase* create()
    { return new MySQL_SQLDriverPlugin(); }
    
    static void destroy(PluginBase* plugin)
    { delete plugin; }
            
};

/* export the plugin */
P_PLUGINS_BEGIN
  P_PLUGIN(SQLDriver, "mysql", MySQL_SQLDriverPlugin)
P_PLUGINS_END


MySQL_ConnectionHandle::MySQL_ConnectionHandle(const string& user, const string& passwd, 
                                               const string& db, const string& hostname)
{
  m_mysql = mysql_init(0);
  if(!mysql_real_connect(m_mysql, hostname.c_str(), user.c_str(), passwd.c_str(), 0, 0, 0, 0))
    throw MySQL_Error(m_mysql, "Could not connect to database", P_SOURCEINFO);

  if(mysql_select_db(m_mysql, db.c_str()))
  {
    mysql_close(m_mysql);
    throw MySQL_Error(m_mysql, "Could not select database", P_SOURCEINFO);
  }

  setState(Connected);
}

MySQL_ConnectionHandle::~MySQL_ConnectionHandle()
{
  mysql_close(m_mysql);
}

void MySQL_ConnectionHandle::commit()
{
}

void MySQL_ConnectionHandle::rollback()
{
}
    
auto_ptr<SQLDriver::StatementHandle> MySQL_ConnectionHandle::createStmt()
{
  return auto_ptr<SQLDriver::StatementHandle>(new MySQL_StatementHandle(*this));
}


MySQL_StatementHandle::MySQL_StatementHandle(MySQL_ConnectionHandle& conn)
: m_conn(conn), m_affRows(0), m_res(0)
{
}

MySQL_StatementHandle::~MySQL_StatementHandle()
{
  if(m_res)
    mysql_free_result(m_res);
}

void MySQL_StatementHandle::prepare(const string& stmt)
{
  m_affRows = 0;
  m_stmt    = stmt;
}

void MySQL_StatementHandle::exec()
{
  // free previous result
  if(m_res)
  {
    mysql_free_result(m_res);
    m_res = 0;
  }
  
  if(mysql_real_query(m_conn.handle(), m_stmt.c_str(), m_stmt.length()))
  {
    long err = mysql_errno(m_conn.handle());
    if(err == CR_SERVER_GONE_ERROR || err == CR_SERVER_LOST)
      m_conn.setState(SQLDriver::ConnectionHandle::Disconnected);
      
    m_affRows = 0;
    throw MySQL_Error(m_conn.handle(), "Statement execution failed", P_SOURCEINFO);
  }
  
  m_affRows = mysql_affected_rows(m_conn.handle());
  
  // store result for later use...
  m_res = mysql_store_result(m_conn.handle());
  if(!m_res)
  {
    long err = mysql_errno(m_conn.handle());
    
    if(err != 0)
    {
      if(err == CR_SERVER_GONE_ERROR || err == CR_SERVER_LOST)
        m_conn.setState(SQLDriver::ConnectionHandle::Disconnected);
        
      throw MySQL_Error(m_conn.handle(), "Error storing result set", P_SOURCEINFO);
    }
  }
}

sqlcount_t MySQL_StatementHandle::affectedRows() const throw()
{
  return m_affRows;  
}

string MySQL_StatementHandle::sqlstr(const SQLValue& val) const throw()
{
  if(val.isNull())
    return "NULL";

  const SQLString* valstr = dynamic_cast<const SQLString*>(&val);
  if(valstr)
  {
    ostringstream os;
    os << "'" << valstr->str() << "'";
    return os.str();
  }

  const SQLDateTime* valdt = dynamic_cast<const SQLDateTime*>(&val);
  if(valdt)
  {
    ostringstream os;
    os << "'" << (int)valdt->value().year() << "-" << (int)valdt->value().month() << "-" << (int)valdt->value().day()
       << " " << (int)valdt->value().hour() << ":" << (int)valdt->value().minute() << ":" << (int)valdt->value().second()
       << "'";
    return os.str();
  }

  const SQLDouble* valdbl = dynamic_cast<const SQLDouble*>(&val);
  if(valdbl)
    return val.str();

  const SQLInt* valint = dynamic_cast<const SQLInt*>(&val);
  if(valint)
    return val.str();

  #ifdef HAVE_64BIT_INT
  const SQLBigInt* valbint = dynamic_cast<const SQLBigInt*>(&val);
  if(valbint)
    return val.str();
  #endif

  return "NULL";
}

auto_ptr<SQLDriver::ResultHandle> MySQL_StatementHandle::result()
{
  auto_ptr<SQLDriver::ResultHandle> res 
    = auto_ptr<SQLDriver::ResultHandle>(new MySQL_ResultHandle(m_conn, m_res));
    
  m_res = 0;
  return res;
}

MySQL_ResultHandle::MySQL_ResultHandle(MySQL_ConnectionHandle& conn, MYSQL_RES* res)
: m_res(res), m_row(0), m_conn(conn)
{
}

MySQL_ResultHandle::~MySQL_ResultHandle()
{
  clearValues();

  if(m_res)
    mysql_free_result(m_res);
}

unsigned int MySQL_ResultHandle::columnCount() const throw()
{
  return mysql_num_fields(m_res);
}

string MySQL_ResultHandle::columnName(unsigned int pos) const
{
  if(pos+1 > columnCount())
    throw OutOfRangeError(P_SOURCEINFO);
  
  MYSQL_FIELD* field = mysql_fetch_field_direct(m_res, pos);
  return string(field->name);
}

bool MySQL_ResultHandle::fetch()
{
  if(m_res)
  {
    clearValues();
    m_row = mysql_fetch_row(m_res);
    
    if(m_row)
    {
      unsigned long* lengths = mysql_fetch_lengths(m_res);
      
      for(unsigned int i = 0; i < mysql_num_fields(m_res); ++i)
      {
        MYSQL_FIELD* field = mysql_fetch_field_direct(m_res, i);
        char* field_val = 0;
        SQLValue* val = 0;

        if(m_row[i])
        {
          field_val = new char[lengths[i]];
          memcpy(field_val, m_row[i], lengths[i]);
          field_val[lengths[i]] = 0;
        }

        switch(field->type)
        {
          case FIELD_TYPE_DOUBLE:
          case FIELD_TYPE_FLOAT:
          case FIELD_TYPE_DECIMAL:
            {
              if(field_val)
                val = new SQLDouble(atof(field_val));
              else
                val = new SQLDouble();
            }
            break;

          case FIELD_TYPE_TINY:
          case FIELD_TYPE_SHORT:
          case FIELD_TYPE_LONG:
          case FIELD_TYPE_INT24:
            {
              if(field_val)
                val = new SQLInt(atol(field_val));
              else
                val = new SQLInt();
            }
            break;

          #ifdef HAVE_64BIT_INT
          case FIELD_TYPE_LONGLONG:
            {
              if(field_val)
              {
                int64_t ival = strtoll(field_val, 0, 10);
                val = new SQLBigInt(ival);
              }
              else
                val = new SQLBigInt();
            }
          #endif

          case FIELD_TYPE_STRING:
          case FIELD_TYPE_VAR_STRING:
            {
              if(field_val)
                val = new SQLString(field_val);
              else
                val = new SQLString();
            }
            break;

          case FIELD_TYPE_TIMESTAMP:
          case FIELD_TYPE_DATE:
          case FIELD_TYPE_TIME:
          case FIELD_TYPE_DATETIME:
          case FIELD_TYPE_YEAR:
            //@todo fetch date/time value
            {
            }
            break;
        }
        
        delete[] field_val;
        m_valuesByName[field->name] = val;
        m_valuesByPos[i] = val;
      }
      
      return true;
    }
    
    long err = mysql_errno(m_conn.handle());
    
    mysql_free_result(m_res);
    m_res = 0;
    
    if(err != 0)
    {
      if(err == CR_SERVER_GONE_ERROR || err == CR_SERVER_LOST)
        m_conn.setState(SQLDriver::ConnectionHandle::Disconnected);
        
      throw MySQL_Error(m_conn.handle(), "Error fetching row", P_SOURCEINFO);
    }
  }
  
  return false;
}

void MySQL_ResultHandle::clearValues()
{
  for(map<string, SQLValue*>::const_iterator i = m_valuesByName.begin();
      i != m_valuesByName.end(); ++i)
  {
    delete i->second;
  }
  
  m_valuesByName.clear();
  m_valuesByPos.clear();
}

const SQLValue& MySQL_ResultHandle::value(const string& name)
{
  map<string, SQLValue*>::const_iterator i = m_valuesByName.find(name);
  if(i != m_valuesByName.end())
    return *i->second;

  throw OutOfRangeError(P_SOURCEINFO);
}

const SQLValue& MySQL_ResultHandle::value(unsigned int pos)
{
  if(pos+1 > columnCount())
  {
    map<unsigned int, SQLValue*>::const_iterator i = m_valuesByPos.find(pos);
    return *i->second;
  }
  
  throw OutOfRangeError(P_SOURCEINFO);
}

}
