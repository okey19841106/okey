/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/config.h"
#include "pclasses/ptypes.h"
#include "pclasses/psqlplugin.h"
#include <map>
#include <sstream>

#include <libpq-fe.h>
#include <postgres.h>

#undef DATA
#define DATA(x)  extern int __err
#undef DESCR
#define DESCR(x) extern int __err

#include <catalog/pg_type.h>

#ifdef HAVE_STRTOLL
  /* we use strtoll()/strtoull() for converting from strings 
  to 64bit integers by default. */
#elif defined(HAVE__STRTOI64)
  /* we use _strtoi64()/_strtoui64() on win32 platforms */
  #define strtoll   _strtoi64
  #define strtoull  _strtoui64
#else
  /* we use strtol()/strtoul() for non 64-bit platforms or 
    on platforms where sizeof(long) == 8. */
  #define strtoll   strtol
  #define strtoull  strtoul
#endif

namespace P {

using namespace std;

class PostgreSQL_Error: public SQLError {
  public:
    PostgreSQL_Error(PGconn* conn, const char* _what, const SourceInfo& _si) throw()
      : SQLError(0, _what,_si), m_text(PQerrorMessage(conn)) {}

    ~PostgreSQL_Error() throw()
    {}

    BaseError* clone() const
    { return new PostgreSQL_Error(*this); }

    string text() const throw()
    { return m_text; }

  private:
    string m_text;

};

class PostgreSQL_ConnectionHandle;

class PostgreSQL_ResultHandle: public SQLDriver::ResultHandle {
  public:
    PostgreSQL_ResultHandle(PostgreSQL_ConnectionHandle& conn, PGresult* res);
    ~PostgreSQL_ResultHandle();

    unsigned int columnCount() const throw();
    string columnName(unsigned int pos) const;

    bool fetch();

    const SQLValue& value(const string& name);
    const SQLValue& value(unsigned int field);

  private:
    void clearValues();

    PGresult*    m_res;
    unsigned int m_row;

    PostgreSQL_ConnectionHandle&  m_conn;
    map<string, SQLValue*>        m_valuesByName;
    map<unsigned int, SQLValue*>  m_valuesByPos;
};

class PostgreSQL_ConnectionHandle: public SQLDriver::ConnectionHandle {
  public:
    PostgreSQL_ConnectionHandle(const string& user, const string& passwd,
                                const string& db, const string& host);

    ~PostgreSQL_ConnectionHandle();

    auto_ptr<SQLDriver::StatementHandle> createStmt();

    inline void setState(state_t st) throw()
    { ConnectionHandle::setState(st); }

    PGconn* handle() const throw()
    { return m_pgconn; }

    void commit();

    void rollback();

  private:
    PGconn* m_pgconn;

};

class PostgreSQL_StatementHandle: public SQLDriver::StatementHandle {
  public:
    PostgreSQL_StatementHandle(PostgreSQL_ConnectionHandle& conn);
    ~PostgreSQL_StatementHandle();

    void prepare(const string& stmt);
    void exec();

    auto_ptr<SQLDriver::ResultHandle> result();

    sqlcount_t affectedRows() const throw();

    string sqlstr(const SQLValue& val) const throw();

  private:
    PostgreSQL_ConnectionHandle& m_conn;
    string       m_stmt;
    sqlcount_t   m_affRows;
    PGresult*    m_res;

};

class PostgreSQL_SQLDriverPlugin: public SQLDriver, public PluginBase {
  public:
    PostgreSQL_SQLDriverPlugin() {}
    ~PostgreSQL_SQLDriverPlugin() {}

    ConnectionHandle* connect(const string& user, const string& passwd,
                              const string& db, const string& host) throw(SQLError)
    { return new PostgreSQL_ConnectionHandle(user, passwd, db, host); }

    void close(ConnectionHandle* handle) throw()
    { delete handle; }

    static PluginBase* create()
    { return new PostgreSQL_SQLDriverPlugin(); }

    static void destroy(PluginBase* plugin)
    { delete plugin; }

};

/* export the plugin */
P_PLUGINS_BEGIN
  P_PLUGIN(SQLDriver, "pgsql", PostgreSQL_SQLDriverPlugin)
P_PLUGINS_END


PostgreSQL_ConnectionHandle::
  PostgreSQL_ConnectionHandle(const string& user, const string& passwd,
                              const string& db, const string& hostname)
{
  m_pgconn = PQsetdbLogin(hostname.c_str(), "", "", "", db.c_str(), user.c_str(), passwd.c_str());
  if(!m_pgconn)
    throw PostgreSQL_Error(m_pgconn, "Could not connect to database", P_SOURCEINFO);

  if(PQstatus(m_pgconn) == CONNECTION_BAD)
  {
    PQfinish(m_pgconn);
    throw PostgreSQL_Error(m_pgconn, "Could not connect to database", P_SOURCEINFO);
  }

  setState(Connected);
}

PostgreSQL_ConnectionHandle::~PostgreSQL_ConnectionHandle()
{
  PQfinish(m_pgconn);
}

void PostgreSQL_ConnectionHandle::commit()
{
}

void PostgreSQL_ConnectionHandle::rollback()
{
}

auto_ptr<SQLDriver::StatementHandle> PostgreSQL_ConnectionHandle::createStmt()
{
  return auto_ptr<SQLDriver::StatementHandle>(new PostgreSQL_StatementHandle(*this));
}

PostgreSQL_StatementHandle::PostgreSQL_StatementHandle(PostgreSQL_ConnectionHandle& conn)
: m_conn(conn), m_affRows(0), m_res(0)
{
}

PostgreSQL_StatementHandle::~PostgreSQL_StatementHandle()
{
  if(m_res)
    PQclear(m_res);
}

void PostgreSQL_StatementHandle::prepare(const string& stmt)
{
  m_affRows = 0;
  m_stmt    = stmt;
}

void PostgreSQL_StatementHandle::exec()
{
  // free previous result
  if(m_res)
  {
    PQclear(m_res);
    m_res = 0;
  }

  PGresult* res = PQexec(m_conn.handle(), m_stmt.c_str());
  if(!res)
  {
    if(PQstatus(m_conn.handle()) != CONNECTION_OK)
      m_conn.setState(SQLDriver::ConnectionHandle::Disconnected);

    m_affRows = 0;
    throw PostgreSQL_Error(m_conn.handle(), "Statement execution failed", P_SOURCEINFO);
  }

  m_affRows = atoi(PQcmdTuples(res));
  m_res = res;
}

sqlcount_t PostgreSQL_StatementHandle::affectedRows() const throw()
{
  return m_affRows;
}

string PostgreSQL_StatementHandle::sqlstr(const SQLValue& val) const throw()
{
  if(val.isNull())
    return "NULL";

  const SQLString* valstr = dynamic_cast<const SQLString*>(&val);
  if(valstr)
  {
    ostringstream os;
    os << "'" << valstr->str() << "'";
    return os.str();
  }

  const SQLDateTime* valdt = dynamic_cast<const SQLDateTime*>(&val);
  if(valdt)
  {
    ostringstream os;
    os << "'" << (int)valdt->value().year() << "-" << (int)valdt->value().month() << "-" << (int)valdt->value().day()
       << " " << (int)valdt->value().hour() << ":" << (int)valdt->value().minute() << ":" << (int)valdt->value().second()
       << "'";
    return os.str();
  }

  const SQLDouble* valdbl = dynamic_cast<const SQLDouble*>(&val);
  if(valdbl)
    return val.str();

  const SQLInt* valint = dynamic_cast<const SQLInt*>(&val);
  if(valint)
    return val.str();

  #ifdef HAVE_64BIT_INT
  const SQLBigInt* valbint = dynamic_cast<const SQLBigInt*>(&val);
  if(valbint)
    return val.str();
  #endif

  return "NULL";
}

auto_ptr<SQLDriver::ResultHandle> PostgreSQL_StatementHandle::result()
{
  auto_ptr<SQLDriver::ResultHandle> res
    = auto_ptr<SQLDriver::ResultHandle>(new PostgreSQL_ResultHandle(m_conn, m_res));

  m_res = 0;
  return res;
}

PostgreSQL_ResultHandle::PostgreSQL_ResultHandle(PostgreSQL_ConnectionHandle& conn, PGresult* res)
: m_res(res), m_row(0), m_conn(conn)
{
}

PostgreSQL_ResultHandle::~PostgreSQL_ResultHandle()
{
  clearValues();

  if(m_res)
    PQclear(m_res);
}

unsigned int PostgreSQL_ResultHandle::columnCount() const throw()
{
  return PQnfields(m_res);
}

string PostgreSQL_ResultHandle::columnName(unsigned int pos) const
{
  if(pos+1 > columnCount())
    throw OutOfRangeError(P_SOURCEINFO);

  return string(PQfname(m_res, pos));
}

bool PostgreSQL_ResultHandle::fetch()
{
  if(m_res)
  {
    clearValues();

    if(m_row < PQntuples(m_res))
    {
      for(unsigned int i = 0; i < PQnfields(m_res); ++i)
      {
        SQLValue* val = 0;

        switch(PQftype(m_res, i))
        {
          case BYTEAOID:
          case CHAROID:
          case TEXTOID:
            {
              if(PQgetisnull(m_res, m_row, i))
                val = new SQLString();
              else
                val = new SQLString(PQgetvalue(m_res, m_row, i));
            }
            break;

          case INT2OID:
          case INT4OID:
            {
              if(PQgetisnull(m_res, m_row, i))
                val = new SQLInt();
              else
                val = new SQLInt(atoi(PQgetvalue(m_res, m_row, i)));
            }
            break;

          #ifdef HAVE_64BIT_INT
          case INT8OID:
            {
              if(PQgetisnull(m_res, m_row, i))
                val = new SQLBigInt();
              else
              {
                int64_t ival = strtoll(PQgetvalue(m_res, m_row, i), 0, 10);
                val = new SQLBigInt(ival);
              }
            }
            break;
          #endif

          case OIDOID:
            break;

          //@todo fetch date/time value
        }

        m_valuesByName[PQfname(m_res,i)] = val;
        m_valuesByPos[i] = val;
      }

      ++m_row;
      return true;
    }

    return false;
  }

  return false;
}

void PostgreSQL_ResultHandle::clearValues()
{
  for(map<string, SQLValue*>::const_iterator i = m_valuesByName.begin();
      i != m_valuesByName.end(); ++i)
  {
    delete i->second;
  }

  m_valuesByName.clear();
  m_valuesByPos.clear();
}

const SQLValue& PostgreSQL_ResultHandle::value(const string& name)
{
  map<string, SQLValue*>::const_iterator i = m_valuesByName.find(name);
  if(i != m_valuesByName.end())
    return *i->second;

  throw OutOfRangeError(P_SOURCEINFO);
}

const SQLValue& PostgreSQL_ResultHandle::value(unsigned int pos)
{
  if(pos+1 > columnCount())
  {
    map<unsigned int, SQLValue*>::const_iterator i = m_valuesByPos.find(pos);
    return *i->second;
  }

  throw OutOfRangeError(P_SOURCEINFO);
}


}
