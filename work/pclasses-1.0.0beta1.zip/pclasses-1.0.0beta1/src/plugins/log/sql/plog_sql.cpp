/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/plogplugin.h"
#include "pclasses/psqlplugin.h"
#include "pclasses/psqlconnection.h"
#include "pclasses/psqlstatement.h"
#include "pclasses/ptokenizer.h"

namespace P {

using namespace std;

class SQL_LoggerPlugin: public Logger, public PluginBase {
  public:
    SQL_LoggerPlugin();
    ~SQL_LoggerPlugin();

    void start(const string& path);
    void stop();
    void restart();

    bool isActive() const;

    void output(const DateTime& t, LogLevel l, const string& ident, const string& subsys, const char* msg);

    static PluginBase* create()
    { return new SQL_LoggerPlugin(); }

    static void destroy(PluginBase* plugin)
    { delete plugin; }

  private:
    string          m_path;
    SQLDriver*      m_driver;
    SQLConnection*  m_conn;
    string          m_stmtFmt;

    static SQLDriverPluginFactory m_factory;

};

/* export the plugin */
P_PLUGINS_BEGIN
  P_PLUGIN(Logger, "sql", SQL_LoggerPlugin)
P_PLUGINS_END

SQLDriverPluginFactory SQL_LoggerPlugin::m_factory;

SQL_LoggerPlugin::SQL_LoggerPlugin()
: m_driver(0), m_conn(0)
{
}

SQL_LoggerPlugin::~SQL_LoggerPlugin()
{
  stop();
}

void SQL_LoggerPlugin::start(const string& path)
{
  string tmp, name, value;

  if(isActive())
    stop();

  // parse given path into vars .. they should be seperated by ;
  map<string, string> vars;
  StringTokenizer st(path, ";");

  while(st)
  {
    st >> tmp;

    StringTokenizer st2(tmp, "=");
    st2 >> name;
    st2 >> value;

    vars[name] = value;
  }

  // finaly .. create the SQLDriver and connect to database ...
  m_driver = m_factory.create(vars["driver"].c_str());
  if(!m_driver)
    return;

  try
  {
    m_conn = new SQLConnection(m_driver, vars["user"], vars["passwd"], vars["dbname"], vars["host"]);
  }
  catch(...)
  {
    m_factory.destroy(m_driver);
    m_driver = 0;
  }

  m_path = path;

  // check if sql statement was given .. and use it if so; otherwise use standard statement...
  map<string,string>::const_iterator si = vars.find("sql");
  if(si != vars.end())
    m_stmtFmt = si->second;
  else
    m_stmtFmt = "INSERT INTO sqllog (when, severity, ident, subsys, msg) VALUES (:datetime,:loglevel,:ident,:subsys,:msg)";
}

void SQL_LoggerPlugin::stop()
{
  if(m_conn)
  {
    delete m_conn;
    m_conn = 0;

    m_factory.destroy(m_driver);
    m_driver = 0;
  }
}

void SQL_LoggerPlugin::restart()
{
  stop();
  start(m_path);
}

bool SQL_LoggerPlugin::isActive() const
{
  return m_conn ? true : false;
}

void SQL_LoggerPlugin::output(const DateTime& t, LogLevel l, const string& ident, const string& subsys, const char* msg)
{
  SQLStatement stmt(*m_conn);

  SQLDateTime sqlt(t);
  SQLString   sqll(logLevel2Str(l));
  SQLString   sqlident(ident);
  SQLString   sqlsubsys(subsys);
  SQLString   sqlmsg(msg);

  map<string, const SQLValue*> values;
  values.insert(make_pair(string("datetime"),&sqlt));
  values.insert(make_pair(string("loglevel"),&sqll));
  values.insert(make_pair(string("ident"),&sqlident));
  values.insert(make_pair(string("subsys"),&sqlsubsys));
  values.insert(make_pair(string("msg"),&sqlmsg));

  stmt.format(m_stmtFmt, values);

  try
  {
    stmt.exec();
  }
  catch(...)
  {
    stop();
  }
}

}
