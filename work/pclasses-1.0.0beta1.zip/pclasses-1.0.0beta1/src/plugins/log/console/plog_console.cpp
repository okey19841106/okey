/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/plogplugin.h"
#include <iostream>

namespace P {

using namespace std;

class Console_LoggerPlugin: public Logger, public PluginBase {
  public:
    Console_LoggerPlugin()
    : m_strm(0) {}

    ~Console_LoggerPlugin()
    {}

    void start(const string& path);
    void stop();
    void restart();

    bool isActive() const;

    void output(const DateTime& t, LogLevel l, const string& ident, const string& subsys, const char* msg);

    static PluginBase* create()
    { return new Console_LoggerPlugin(); }

    static void destroy(PluginBase* plugin)
    { delete plugin; }

  private:
    ostream* m_strm;
};

P_PLUGINS_BEGIN
  P_PLUGIN(Logger, "console", Console_LoggerPlugin)
P_PLUGINS_END

void Console_LoggerPlugin::start(const string& path)
{
  if(path == "stderr" || path == "cerr")
    m_strm = &cerr;
  else
    m_strm = &cout;
}

void Console_LoggerPlugin::stop()
{
  m_strm = 0;
}

void Console_LoggerPlugin::restart()
{
}

bool Console_LoggerPlugin::isActive() const
{
  return m_strm ? true : false;
}

void Console_LoggerPlugin::output(const DateTime& t, LogLevel l, const string& ident, const string& subsys, const char* msg)
{
  if(m_strm)
  {
    *m_strm << t << ' ' << ident;
    if(!subsys.empty())
      *m_strm << '(' << subsys << ')';
    *m_strm << ": [" << logLevel2Str(l) << "] " << msg << endl;
  }
}

}
