/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2002  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/plogplugin.h"
#include "pclasses/pfile.h"
#include <sstream>

namespace P {

using namespace std;

class File_LoggerPlugin: public Logger, public PluginBase {
  public:
    File_LoggerPlugin() 
    : m_file(0), m_safe(false) {}
    
    ~File_LoggerPlugin()
    {
      stop();
    }

    void start(const string& path);
    void stop();
    void restart();

    bool isActive() const;

    void output(const DateTime& t, LogLevel l, const string& ident, const string& subsys, const char* msg);

    static PluginBase* create()
    { return new File_LoggerPlugin(); }

    static void destroy(PluginBase* plugin)
    { delete plugin; }
    
  private:
    File*     m_file;
    bool      m_safe;
};

P_PLUGINS_BEGIN
  P_PLUGIN(Logger, "file", File_LoggerPlugin)
P_PLUGINS_END

void File_LoggerPlugin::start(const string& path)
{
  stop();
  m_file = new File(path.c_str(), File::Write, File::Append, File::OpenCreate, File::AllowRead);
}

void File_LoggerPlugin::stop()
{
  if(m_file)
  {
    delete m_file;
    m_file = 0;
  }
}

void File_LoggerPlugin::restart()
{
  if(m_file)
  {
    m_file->reopen();
  }
}

bool File_LoggerPlugin::isActive() const
{
  return m_file ? true : false;
}

void File_LoggerPlugin::output(const DateTime& t, LogLevel l, const string& ident, const string& subsys, const char* msg)
{
  if(m_file)
  {
    ostringstream os;
  
    os << t << ' ' << ident;
    if(!subsys.empty())
      os << '(' << subsys << ')';
    os << ": [" << logLevel2Str(l) << "] " << msg << pendl;

    try
    {
      m_file->write(os.str().c_str(), os.str().length());
      if(m_safe)
        m_file->commit();
    }
    catch(...)
    {
      stop();
    }
  }
}

}
