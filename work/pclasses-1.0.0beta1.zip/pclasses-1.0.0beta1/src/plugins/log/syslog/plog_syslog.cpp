/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/plogplugin.h"
#include <syslog.h>

/* this is pretty ugly.. but some of our loglevel constants
  conflict with them from syslog.h */
#undef LOG_EMERG
#undef LOG_ALERT
#undef LOG_CRIT
#undef LOG_ERR
#undef LOG_WARNING
#undef LOG_NOTICE
#undef LOG_INFO
#undef LOG_DEBUG

namespace P {

using namespace std;

class Syslog_LoggerPlugin: public Logger, public PluginBase {
  public:
    Syslog_LoggerPlugin()
    : m_started(false) {}

    ~Syslog_LoggerPlugin()
    {}

    void start(const string& path);
    void stop();
    void restart();

    bool isActive() const;

    void output(const DateTime& t, LogLevel l, const string& ident, const string& subsys, const char* msg);

    static PluginBase* create()
    { return new Syslog_LoggerPlugin(); }

    static void destroy(PluginBase* plugin)
    { delete plugin; }

  private:

    int strToFacility(const string& path);
    int logLevelToPriority(LogLevel l);

    bool    m_started;
    string  m_path;
    string  m_lastident;
};

/* export the plugin */
P_PLUGINS_BEGIN
  P_PLUGIN(Logger, "syslog", Syslog_LoggerPlugin)
P_PLUGINS_END

#ifndef LOG_AUTHPRIV
#define LOG_AUTHPRIV LOG_AUTH
#endif

#ifndef LOG_FTP
#define LOG_FTP LOG_DAEMON
#endif

int Syslog_LoggerPlugin::strToFacility(const string& path)
{
  int facility = LOG_USER;

  if(path == "auth")
    facility = LOG_AUTH;
  else if(path == "authpriv")
    facility = LOG_AUTHPRIV;
  else if(path == "cron")
    facility = LOG_CRON;
  else if(path == "daemon")
    facility = LOG_DAEMON;
  else if(path == "ftp")
    facility = LOG_FTP;
  else if(path == "kern")
    facility = LOG_KERN;
  else if(path == "local0")
    facility = LOG_LOCAL0;
  else if(path == "local1")
    facility = LOG_LOCAL1;
  else if(path == "local2")
    facility = LOG_LOCAL2;
  else if(path == "local3")
    facility = LOG_LOCAL3;
  else if(path == "local4")
    facility = LOG_LOCAL4;
  else if(path == "local5")
    facility = LOG_LOCAL5;
  else if(path == "local6")
    facility = LOG_LOCAL6;
  else if(path == "local7")
    facility = LOG_LOCAL7;
  else if(path == "lpr")
    facility = LOG_LPR;
  else if(path == "mail")
    facility = LOG_MAIL;
  else if(path == "news")
    facility = LOG_NEWS;
  else if(path == "syslog")
    facility = LOG_SYSLOG;
  else if(path == "uucp")
    facility = LOG_UUCP;

  return facility;
}

int Syslog_LoggerPlugin::logLevelToPriority(LogLevel l)
{
  int prio = LOG_INFO;

  switch(l)
  {
    case LOG_EMERGENCY:
        prio = 0;
        break;

    case LOG_CRITICAL:
        prio = 2;
        break;

    case LOG_ERROR:
        prio = 3;
        break;

    case LOG_WARNING:
        prio = 4;
        break;

    case LOG_NOTICE:
        prio = 5;
        break;

    case LOG_INFO:
        prio = 6;
        break;

    case LOG_DEBUG:
        prio = 7;
        break;
  }

  return prio;
}

void Syslog_LoggerPlugin::start(const string& path)
{
  openlog(m_lastident.c_str(), LOG_NDELAY, strToFacility(path));

  m_started = true;
  m_path    = path;
}

void Syslog_LoggerPlugin::stop()
{
  closelog();

  m_started = false;
}

void Syslog_LoggerPlugin::restart()
{
  stop();
  start(m_path);
}

bool Syslog_LoggerPlugin::isActive() const
{
  return m_started;
}

void Syslog_LoggerPlugin::output(const DateTime& t, LogLevel l, const string& ident, const string& subsys, const char* msg)
{
  if(m_started)
  {
    string myident = ident;

    if(!subsys.empty())
      myident += "(" + subsys + ")";

    if(m_lastident != myident)
    {
      m_lastident = myident;

      closelog();
      openlog(m_lastident.c_str(), LOG_NDELAY, strToFacility(m_path));
    }

    syslog(logLevelToPriority(l), msg);
  }
}

}
