/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/pconfig.h"
#include "pclasses/psocket.h"
#include "pclasses/pinetaddr.h"

#ifdef HAVE_IPV6
  #include "pclasses/pinet6addr.h"
#endif

#ifdef HAVE_IPX
  #include "pclasses/pipxaddr.h"
#endif

#ifdef HAVE_ATALK
  #include "pclasses/patalkaddr.h"
#endif

#include "../core/private.h"

#ifdef WIN32
  #include <windows.h>
  #define P_FD_ZERO(a)    FD_ZERO((int)a)
  #define P_FD_SET(a,b)   FD_SET((int)a, b)
  #define P_FD_ISSET(a,b) FD_ISSET((int)a, b)
  #define socket_errno    WSAGetLastError()
  #define SOCKET_HANDLE   SOCKET
  #define ETIMEDOUT       WSAETIMEDOUT
  #undef  EINTR
  #define EINTR           WSAEINTR
#else
  #include <netinet/in.h>
  #include <arpa/inet.h>
  #ifdef HAVE_ATALK
    #include <netatalk/at.h>
  #endif
  #ifdef HAVE_IPX
    #include <netipx/ipx.h>
  #endif
  #include <errno.h>
  #include <unistd.h>
  #define SOCKET_ERROR    -1
  #define INVALID_SOCKET  -1
  #define P_FD_ZERO(a)    FD_ZERO(a)
  #define P_FD_SET(a,b)   FD_SET(a, b)
  #define P_FD_ISSET(a,b) FD_ISSET(a, b)
  #define socket_errno    errno
  #define SOCKET_HANDLE   int
#endif

#include <string.h>

#ifndef MSG_NOSIGNAL
  #define MSG_NOSIGNAL 0
#endif

namespace P {

using namespace std;

static sockaddr* make_sockaddr(const NetworkAddress& addr, port_t port, socklen_t& salen)
{
  sockaddr* sa = 0;
  switch(addr.family())
  {
    case AF_INET:
    {
      sockaddr_in* sin = new sockaddr_in;
      memset((void*)sin, 0, sizeof(sockaddr_in));

      sin->sin_family = AF_INET;
      sin->sin_port   = htons(port);
      memcpy((void*)&sin->sin_addr, addr.addr(), addr.addrlen());

      sa = (sockaddr*)sin;
      salen = sizeof(sockaddr_in);
      break;
    }

    #ifdef HAVE_IPV6
    case AF_INET6:
    {
      sockaddr_in6* sin6 = new sockaddr_in6;
      memset((void*)sin6, 0, sizeof(sockaddr_in6));

      sin6->sin6_family = AF_INET6;
      sin6->sin6_port   = htons(port);
      memcpy((void*)&sin6->sin6_addr, addr.addr(), addr.addrlen());

      sa = (sockaddr*)sin6;
      salen = sizeof(sockaddr_in6);
      break;
    }
    #endif

    #ifdef HAVE_IPX
    case AF_IPX:
    {
      sockaddr_ipx* sipx = new sockaddr_ipx;
      memset((void*)sipx, 0, sizeof(sockaddr_ipx));

      sipx->sipx_family = AF_IPX;
      sipx->sipx_port   = htons(port);
      //TODO: memcpy((void*)&sipx->sipx_addr, addr.addr(), addr.addrlen());

      sa = (sockaddr*)sipx;
      salen = sizeof(sockaddr_ipx);
      break;
    }
    #endif

    #ifdef HAVE_ATALK
    case AF_APPLETALK:
    {
      sockaddr_at* sat = new sockaddr_at;
      memset((void*)sat, 0, sizeof(sockaddr_at));

      sat->sat_family = AF_APPLETALK;
      sat->sat_port   = htons(port);
      memcpy((void*)&sat->sat_addr, addr.addr(), addr.addrlen());

      sa = (sockaddr*)sat;
      salen = sizeof(sockaddr_at);
      break;
    }
    #endif

    default:
      throw;
  }

  return sa;
}

static sockaddr* create_sockaddr(int domain, socklen_t& salen)
{
  sockaddr* sa = 0;
  switch(domain)
  {
    case PF_INET:
      sa = (sockaddr*)new sockaddr_in;
      salen = sizeof(sockaddr_in);
      break;

    #ifdef HAVE_IPV6
    case PF_INET6:
      sa = (sockaddr*)new sockaddr_in6;
      salen = sizeof(sockaddr_in6);
      break;
    #endif

    #ifdef HAVE_IPX
    case PF_IPX:
      sa = (sockaddr*)new sockaddr_ipx;
      salen = sizeof(sockaddr_ipx);
      break;
    #endif

    #ifdef HAVE_ATALK
    case PF_APPLETALK:
      sa = (sockaddr*)new sockaddr_at;
      salen = sizeof(sockaddr_at);
      break;
    #endif

    default:
      throw;
  }

  return sa;
}

NetworkAddress* create_netaddr(int domain, const NetworkAddress* addr)
{
  switch(domain)
  {
    case PF_INET:
      if(addr)
        return new InetAddress(*addr);
      return new InetAddress();
      break;

    #ifdef HAVE_IPV6
    case PF_INET6:
      if(addr)
        return new Inet6Address(*addr);
      return new Inet6Address();
      break;
    #endif

    #ifdef HAVE_IPX
    case PF_IPX:
      if(addr)
        return new IpxAddress(*addr);
      return new IpxAddress();
      break;
    #endif

    #ifdef HAVE_ATALK
    case PF_APPLETALK:
      if(addr)
        return new ATalkAddress(*addr);
      return new ATalkAddress();
      break;
    #endif

    default:
      return 0;
  }
}

void retr_sockaddr(int domain, sockaddr* sa, NetworkAddress& addr, port_t& port)
{
  switch(domain)
  {
    case PF_INET:
      {
        sockaddr_in* sain = (sockaddr_in*)sa;
        (InetAddress&)addr = sain->sin_addr;
        port = ntohs(sain->sin_port);
      }
      break;

    #ifdef HAVE_IPV6
    case PF_INET6:
      (Inet6Address&)addr = ((sockaddr_in6*)sa)->sin6_addr;
      port = ntohs(((sockaddr_in6*)sa)->sin6_port);
      break;
    #endif

    #ifdef HAVE_IPX
    case PF_IPX:
      //TODO: *m_sender = ((sockaddr_ipx*)sa)->sipx_addr;
      port = ntohs(((sockaddr_ipx*)sa)->sipx_port);
      break;
    #endif

    #ifdef HAVE_ATALK
    case PF_APPLETALK:
      (ATalkAddress&)addr = ((sockaddr_at*)sa)->sat_addr;
      port = ntohs(((sockaddr_at*)sa)->sat_port);
      break;
    #endif

    default:
      throw;
  }
}

#ifdef WIN32

inline SOCKET socket_handle(const Socket* s)
{ return (SOCKET)s->handle(); }

class WSA_Init {
  public:
    WSA_Init()
    {
      WSADATA wsaData;
      WORD wsaVer = MAKEWORD(2,0);
      WSAStartup(wsaVer, &wsaData);
    }
};

WSA_Init SocketInit;

#else

inline int socket_handle(const Socket* s)
{ return s->handle(); }

#endif

Socket::Socket(int domain, int type, int proto) throw(IOError)
: IODevice(), m_domain(domain), m_type(type), m_protocol(proto)
{
  SOCKET_HANDLE handle = ::socket(domain, type, proto);
  if(handle == INVALID_SOCKET)
    throw IOError(socket_errno, "Could not create socket", P_SOURCEINFO);

  setHandle((io_handle_t)handle);
}

Socket::Socket(io_handle_t handle, int domain, int type, int proto) throw(IOError)
: IODevice(handle), m_domain(domain), m_type(type), m_protocol(proto)
{
}

Socket::~Socket() throw()
{
  try
  {
    close();
  }
  catch(...)
  {
  }
}

void Socket::close() throw(IOError)
{
  #ifdef WIN32
  closesocket(socket_handle(this));
  setHandle(INVALID_HANDLE_VALUE);
  #else
  IODevice::close();
  #endif
}

size_t Socket::write(const char* buffer, size_t count) throw(IOError)
{
  _write:
  ssize_t ret = ::send(socket_handle(this), buffer, count, MSG_NOSIGNAL);
  if(ret == SOCKET_ERROR)
  {
    if(socket_errno == EAGAIN)
      return 0;
    else if(socket_errno == EINTR)
      goto _write;

    throw IOError(socket_errno, "Could not write to file descriptor", P_SOURCEINFO);
  }

  return ret;
}

size_t Socket::read(char* buffer, size_t count) throw(IOError)
{
  _read:
  ssize_t ret = ::recv(socket_handle(this), buffer, count, MSG_NOSIGNAL);
  if(ret == SOCKET_ERROR)
  {
    if(socket_errno == EAGAIN)
      return 0;
    else if(socket_errno == EINTR)
      goto _read;

    throw IOError(socket_errno, "Could not read from file descriptor", P_SOURCEINFO);
  }

  return ret;
}

size_t Socket::peek(char* buffer, size_t count) throw(IOError)
{
  int ret;

  _peek:
  ret = ::recv(socket_handle(this), buffer, count, MSG_PEEK|MSG_NOSIGNAL);
  if(ret == SOCKET_ERROR)
  {
    if(socket_errno == EAGAIN)
      return 0;
    else if(socket_errno == EINTR)
      goto _peek;

    throw IOError(socket_errno, "Could not read from socket", P_SOURCEINFO);
  }

  return ret;
}

void Socket::setBroadcast(bool enable) throw(IOError)
{
  int opt = (enable ? 1 : 0);
  int ret = setsockopt(socket_handle(this), SOL_SOCKET, SO_BROADCAST, (char*)&opt, sizeof(opt));
  if(ret == SOCKET_ERROR)
    throw IOError(socket_errno, "Could not set socket broadcast option", P_SOURCEINFO);
}

void Socket::setRouting(bool enable) throw(IOError)
{
  int opt = (enable ? 1 : 0);

  #ifdef SO_DONTROUTE
  int ret = setsockopt(socket_handle(this), SOL_SOCKET, SO_DONTROUTE, (char*)&opt, sizeof(opt));
  if(ret == SOCKET_ERROR)
    throw IOError(socket_errno, "Could not set socket broadcast option", P_SOURCEINFO);
  #endif
}

int Socket::wait(int waitflags, unsigned int timeout) throw(IOError)
{
  fd_set rfds, *_rfds = 0;
  fd_set wfds, *_wfds = 0;

  if(waitflags & pendingInput)
  {
    P_FD_ZERO(&rfds);
    P_FD_SET(socket_handle(this), &rfds);
    _rfds = &rfds;
  }

  if(waitflags & pendingOutput)
  {
    P_FD_ZERO(&wfds);
    P_FD_SET(socket_handle(this), &wfds);
    _wfds = &wfds;
  }

  struct timeval tv;
  _select:
  int ret = select(socket_handle(this) + 1, _rfds, _wfds, 0, get_timeout(&tv, timeout, TIMEOUT_RELATIVE));
  if(ret == SOCKET_ERROR)
  {
    if(socket_errno == EINTR)
      goto _select;
    throw IOError(socket_errno, "Could not select on socket", P_SOURCEINFO);
  }
  else if(ret == 0)
    return 0;

  int waitret = 0;
  if(waitflags & pendingInput && P_FD_ISSET(handle(), &rfds))
    waitret |= pendingInput;

  if(waitflags & pendingOutput && P_FD_ISSET(handle(), &wfds))
    waitret |= pendingOutput;

  return waitret;
}

void Socket::bind(const NetworkAddress& addr, port_t port) throw(IOError)
{
  int ret;
  socklen_t salen;
  sockaddr* sa = make_sockaddr(addr,port,salen);

  ret = ::bind(socket_handle(this), sa, salen);
  delete sa;

  if(ret == SOCKET_ERROR)
    throw IOError(socket_errno, "Could not bind to address", P_SOURCEINFO);
}

void Socket::getName(NetworkAddress& addr, port_t& port) const throw(LogicError,IOError)
{
  if(addr.family() != domain())
    throw LogicError("Addressfamily does not match sockets protocol", P_SOURCEINFO);

  socklen_t salen = 0;
  sockaddr* sa = create_sockaddr(domain(), salen);

  int ret = getsockname(socket_handle(this), sa, &salen);
  if(ret == SOCKET_ERROR)
  {
    delete sa;
    throw IOError(socket_errno, "Could not get peername", P_SOURCEINFO);
  }

  retr_sockaddr(domain(), sa, addr, port);
  delete sa;
}

void Socket::getPeer(NetworkAddress& addr, port_t& port) const throw(LogicError,IOError)
{
  if(addr.family() != domain())
    throw LogicError("Addressfamily does not match sockets protocol", P_SOURCEINFO);

  socklen_t salen = 0;
  sockaddr* sa = create_sockaddr(domain(), salen);

  int ret = getpeername(socket_handle(this), sa, &salen);
  if(ret == SOCKET_ERROR)
  {
    delete sa;
    throw IOError(socket_errno, "Could not get peername", P_SOURCEINFO);
  }

  retr_sockaddr(domain(), sa, addr, port);
  delete sa;
}


StreamSocketServer::StreamSocketServer(int domain) throw(IOError)
: Socket(domain, SOCK_STREAM, 0), m_lastAcceptHandle((io_handle_t)INVALID_SOCKET)
{
}

StreamSocketServer::StreamSocketServer(const NetworkAddress& addr, port_t port) throw(IOError)
: Socket(addr.family(), SOCK_STREAM, 0), m_lastAcceptHandle((io_handle_t)INVALID_SOCKET)
{
  bind(addr, port);
  listen();
}

StreamSocketServer::~StreamSocketServer() throw()
{
  /* close handle of last accepted connection ... */
  if((SOCKET_HANDLE)m_lastAcceptHandle != INVALID_SOCKET)
  {
    #ifdef WIN32
    ::closesocket((SOCKET_HANDLE)m_lastAcceptHandle);
    #else
    ::close((SOCKET_HANDLE)m_lastAcceptHandle);
    #endif
  }

  try
  {
    Socket::close();
  }
  catch(...)
  {
  }
}

void StreamSocketServer::listen() throw(IOError)
{
  int ret = ::listen(socket_handle(this), 128);
  if(ret == SOCKET_ERROR)
    throw IOError(socket_errno, "Could not listen on socket", P_SOURCEINFO);
}

bool StreamSocketServer::waitClient(unsigned int timeout) throw(IOError)
{
  fd_set rfds;
  P_FD_ZERO(&rfds);
  P_FD_SET(socket_handle(this), &rfds);

  struct timeval tv;
  _select:
  int ret = select(socket_handle(this) + 1, &rfds, 0, 0, get_timeout(&tv, timeout, TIMEOUT_RELATIVE));
  if(ret == SOCKET_ERROR)
  {
    if(socket_errno == EINTR)
      goto _select;
    throw IOError(socket_errno, "Could not select on socket", P_SOURCEINFO);
  }

  if(ret == 1)
    return true;

  return false;
}

io_handle_t StreamSocketServer::accept() throw(IOError)
{
  socklen_t salen = 0;
  sockaddr* sa = create_sockaddr(domain(), salen);

  /* close handle of last accepted connection ... */
  if((SOCKET_HANDLE)m_lastAcceptHandle != INVALID_SOCKET)
  {
    #ifdef WIN32
    ::closesocket((SOCKET_HANDLE)m_lastAcceptHandle);
    #else
    ::close((SOCKET_HANDLE)m_lastAcceptHandle);
    #endif
  }

  m_lastAcceptHandle = (io_handle_t)::accept(socket_handle(this), sa, &salen);
  delete sa;

  if((SOCKET_HANDLE)m_lastAcceptHandle == INVALID_SOCKET)
    throw IOError(socket_errno, "Could not accept connection on socket", P_SOURCEINFO);

  return (io_handle_t)m_lastAcceptHandle;
}

StreamSocket::StreamSocket(const NetworkAddress& addr, port_t port) throw(IOError)
: Socket(addr.family(), SOCK_STREAM, 0)
{
  connect(addr, port);
}

StreamSocket::StreamSocket(int domain) throw(IOError)
: Socket(domain, SOCK_STREAM, 0)
{}

StreamSocket::StreamSocket(StreamSocketServer& srv) throw(IOError)
: Socket(srv.accept(), srv.domain(), srv.type(), srv.protocol())
{}

StreamSocket::~StreamSocket() throw()
{
  try
  {
    close();
  }
  catch(...)
  {
  }
}

void StreamSocket::close() throw(IOError)
{
  shutdown(disableBoth);
  Socket::close();
}

void StreamSocket::shutdown(sdmode_t mode)
{
  ::shutdown(socket_handle(this), (int)mode);
}

void StreamSocket::connect(const NetworkAddress& addr, port_t port) throw(IOError)
{
  int ret;
  socklen_t salen;
  sockaddr* sa = make_sockaddr(addr,port,salen);

_connect:
  ret = ::connect(socket_handle(this), sa, salen);
  if(ret == SOCKET_ERROR && socket_errno == EINTR)
    goto _connect;

  delete sa;

  if(ret == SOCKET_ERROR)
    throw IOError(socket_errno, "Could not connect to host", P_SOURCEINFO);
}

string StreamSocket::readLine(unsigned int timeout) throw(IOError)
{
  char buffer[8192];
  size_t count;

  struct timeval tv;
  get_timeout(&tv, timeout, TIMEOUT_ABSOLUTE);

  while(1)
  {
    if(!isValid())
      throw IOError(EPIPE, "Could not read from client", P_SOURCEINFO);

    if(wait(pendingInput, 250) & pendingInput)
    {
      count = peek(buffer, 8192);
      if(!count)
        throw IOError(EPIPE, "Could not peek incoming data", P_SOURCEINFO);

      for(size_t i = 0; i < count; ++i)
      {
        if(buffer[i] == '\n')
        {
          count = read(buffer, i+1);
          if(!count)
            throw IOError(EPIPE, "Could not read line", P_SOURCEINFO);

          string str(buffer, count);
          return str;
        }
      }
    }

    if(timeout_elapsed(&tv))
      throw IOError(ETIMEDOUT, "Timeout reading from socket", P_SOURCEINFO);
  }

  return string();
}


DatagramSocket::DatagramSocket(const NetworkAddress& addr, port_t port) throw(IOError)
: Socket(addr.family(), SOCK_DGRAM, 0),
  m_peer(create_netaddr(addr.family(), &addr)), m_peerPort(port),
  m_sender(create_netaddr(addr.family(), 0)), m_senderPort(0)
{
}

DatagramSocket::DatagramSocket(int domain) throw(IOError)
: Socket(domain, SOCK_DGRAM, 0),
  m_peer(create_netaddr(domain, 0)), m_peerPort(0),
  m_sender(create_netaddr(domain, 0)), m_senderPort(0)
{
}

DatagramSocket::~DatagramSocket() throw()
{
  try
  {
    close();
  }
  catch(...)
  {
  }

  delete m_peer;
  delete m_sender;
}

size_t DatagramSocket::write(const char* buffer, size_t count) throw(IOError)
{
  int ret;
  socklen_t salen;
  sockaddr* sa = make_sockaddr(*m_peer,m_peerPort,salen);

_write:
  ret = ::sendto(socket_handle(this), buffer, count, 0, sa, salen);
  if(ret == SOCKET_ERROR && socket_errno == EINTR)
    goto _write;

  delete sa;

  if(ret == SOCKET_ERROR)
    throw IOError(socket_errno, "Could not write on socket", P_SOURCEINFO);

  return ret;
}

void DatagramSocket::retrSenderAddr(sockaddr* sa, size_t salen)
{
  switch(domain())
  {
    case PF_INET:
      *m_sender = InetAddress(((sockaddr_in*)sa)->sin_addr);
      m_senderPort = ntohs(((sockaddr_in*)sa)->sin_port);
      break;

    #ifdef HAVE_IPV6
    case PF_INET6:
      *m_sender = Inet6Address(((sockaddr_in6*)sa)->sin6_addr);
      m_senderPort = ntohs(((sockaddr_in6*)sa)->sin6_port);
      break;
    #endif

    #ifdef HAVE_IPX
    case PF_IPX:
      //TODO: *m_sender = IpxAddress(((sockaddr_ipx*)sa)->sipx_addr);
      m_senderPort = ntohs(((sockaddr_ipx*)sa)->sipx_port);
      break;
    #endif

    #ifdef HAVE_ATALK
    case PF_APPLETALK:
      *m_sender = ATalkAddress(((sockaddr_at*)sa)->sat_addr);
      m_senderPort = ntohs(((sockaddr_at*)sa)->sat_port);
      break;
    #endif

    default:
      throw;
  }
}

size_t DatagramSocket::read(char* buffer, size_t count) throw(IOError)
{
  int ret;
  socklen_t salen;
  sockaddr* sa = create_sockaddr(domain(), salen);

_read:
  ret = ::recvfrom(socket_handle(this), buffer, count, MSG_NOSIGNAL, sa, &salen);
  if(ret == SOCKET_ERROR)
  {
    if(socket_errno == EINTR)
      goto _read;

    delete sa;
    throw IOError(socket_errno, "Could not read from socket", P_SOURCEINFO);
  }

  retrSenderAddr(sa, salen);

  delete sa;
  return ret;
}

size_t DatagramSocket::peek(char* buffer, size_t count) throw(IOError)
{
  int ret;
  socklen_t salen;
  sockaddr* sa = create_sockaddr(domain(), salen);

_peek:
  ret = ::recvfrom(socket_handle(this), buffer, count, MSG_PEEK|MSG_NOSIGNAL, sa, &salen);
  if(ret == SOCKET_ERROR)
  {
    if(socket_errno == EINTR)
      goto _peek;

    delete sa;
    throw IOError(socket_errno, "Could not read from socket", P_SOURCEINFO);
  }

  retrSenderAddr(sa, salen);

  delete sa;
  return ret;
}

const NetworkAddress& DatagramSocket::getSender(port_t& port) const throw()
{
  port = m_senderPort;
  return *m_sender;
}

void DatagramSocket::setPeer(const NetworkAddress& addr, port_t port) throw()
{
  *m_peer = addr;
  m_peerPort = port;
}


}
