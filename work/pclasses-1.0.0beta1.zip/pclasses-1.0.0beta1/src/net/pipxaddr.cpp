/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/pipxaddr.h"

#ifdef WIN32
  #include <winsock2.h>
  #include <windows.h>
#else
  #include <sys/types.h>
  #include <sys/socket.h>
  #include <netipx/ipx.h>
  #include <errno.h>
#endif

#include <string.h>

namespace P {

using namespace std;

IpxAddress::IpxAddress()
: NetworkAddress(AF_IPX, 4 + IPX_NODE_LEN)
{}

IpxAddress::IpxAddress(const NetworkAddress& na)
: NetworkAddress(na)
{
  if(na.family() != AF_IPX)
    throw;
}

IpxAddress::IpxAddress(const string& ipxaddr)
: NetworkAddress(AF_IPX, 4 + IPX_NODE_LEN)
{
  *this = ipxaddr;
}

IpxAddress& IpxAddress::operator=(const string& ipxaddr)
{
  //TODO:
  return *this;
}

string IpxAddress::str() const
{
  //TODO:
  string addr;
  return addr;
}

NetworkAddress* IpxAddress::clone() const
{
  return new IpxAddress(*this);
}

ostream& operator<<(ostream& os, const IpxAddress& addr)
{
  os << addr.str();
  return os;
}

istream& operator>>(istream& is, IpxAddress& addr)
{
  string str;
  is >> str;
  addr = str;
  return is;
}

}
