/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/pnetaddr.h"

#ifdef WIN32
  #include <windows.h>
#else
  #include <errno.h>
#endif

#include <string.h>

namespace P {

using namespace std;

NetworkAddress::NetworkAddress(int family, socklen_t addrlen)
: m_family(family), m_addr((void*)new char[addrlen]), m_addrlen(addrlen)
{}

NetworkAddress::NetworkAddress(const NetworkAddress& addr)
: m_family(addr.m_family), m_addr((void*)new char[addr.m_addrlen]),
  m_addrlen(addr.m_addrlen)
{
  memcpy(m_addr, addr.m_addr, m_addrlen);
}

NetworkAddress::~NetworkAddress()
{
  delete[] (char*)m_addr;
}

int NetworkAddress::family() const
{
  return m_family;
}

NetworkAddress& NetworkAddress::operator=(const NetworkAddress& addr)
{
  delete[] (char*)m_addr;
  m_family  = addr.m_family;
  m_addr    = (void*)new char[addr.m_addrlen];
  m_addrlen = addr.m_addrlen;
  memcpy(m_addr, addr.m_addr, m_addrlen);
  return *this;
}

}
