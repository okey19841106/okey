/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/phttpclient.h"
#include "pclasses/piostream.h"
#include "pclasses/pinetaddr.h"
#include <sstream>

namespace P {

using namespace std;


HTTPHeader::HTTPHeader()
{}

HTTPHeader::~HTTPHeader()
{}

const string& HTTPHeader::get(const string& head) const
{
  static string empty;
  const_iterator i = m_values.find(head);
  if(i != m_values.end())
    return i->first;

  return empty;
}

void HTTPHeader::set(const string& head, const string& val)
{
  m_values[head] = val;
}

bool HTTPHeader::remove(const string& head)
{
  iterator i = m_values.find(head);
  if(i != m_values.end())
  {
    m_values.erase(i);
    return true;
  }

  return false;
}

bool HTTPHeader::contains(const string& head) const
{
  return (m_values.find(head) != m_values.end() ? true : false);
}

const string& HTTPHeader::operator[](const string& head) const
{
  return get(head);
}

HTTPRequest::HTTPRequest(reqmethod_t method, const URL& url)
: m_method(method), m_url(url), m_header()
{}

HTTPRequest::~HTTPRequest()
{}

HTTPResponse::HTTPResponse(const string& proto, int code, const string& resp)
: m_proto(proto), m_code(code), m_resp(resp)
{}

HTTPResponse::~HTTPResponse()
{}

HTTPClient::HTTPClient(int domain) throw(IOError)
: StreamSocket(domain)
{}

HTTPClient::HTTPClient(const NetworkAddress& addr, port_t port) throw(IOError)
: StreamSocket(addr, port), m_contentLength(0), m_chunkedEncoding(false),
  m_chunkSize(0), m_bodyLength(0)
{}

HTTPClient::~HTTPClient() throw()
{
  try
  {
    close();
  }
  catch(...)
  {
  }
}

void HTTPClient::sendRequest(const HTTPRequest& req) throw(IOError)
{
  IOStream reqs(*this);

  switch(req.method())
  {
    case HTTPRequest::METHOD_GET:
      reqs << "GET ";
      break;

    case HTTPRequest::METHOD_HEAD:
      reqs << "HEAD ";
      break;

    case HTTPRequest::METHOD_POST:
      reqs << "POST ";
      break;

    case HTTPRequest::METHOD_PUT:
      reqs << "PUT ";
      break;

    case HTTPRequest::METHOD_DELETE:
      reqs << "DELETE ";
      break;

    default:
      throw RuntimeError("HTTP request not implemented",P_SOURCEINFO);
  }

  reqs << req.url().path() << " HTTP/1.1\r\n";
  reqs << "Host: " << req.url().host() << "\r\n";

  HTTPHeader::const_iterator i = req.header().begin();
  while(i != req.header().end())
  {
    if(i->first != "Host")
      reqs << i->first << ": " << i->second << "\r\n";
    ++i;
  }

  reqs << "\r\n";
}

auto_ptr<HTTPResponse> HTTPClient::readResponse() throw(IOError)
{
  string httpProto, httpResponse;
  int httpCode;
  string str = readLine(30000);
  string tmp;

  istringstream is(str);

  is >> httpProto;
  is >> httpCode; //is >> tmp; httpCode = atoi(tmp.c_str());
  is >> httpResponse;

  HTTPResponse* resp = new HTTPResponse(httpProto, httpCode, httpResponse);

  m_contentLength   = 0;
  m_chunkedEncoding = false;
  m_chunkSize       = 0;
  m_bodyLength      = 0;

  while(1)
  {
    try
    {
      str = readLine(30000);
    }
    catch(...)
    {
      delete resp;
      throw;
    }

    if(str == "\r\n")
      break;

    size_t pos = str.find(':');
    if(pos != string::npos)
    {
      string headName = str.substr(0, pos);
      string headVal  = str.substr(pos+2, str.size()-(pos+4));

      resp->header().set(headName, headVal);

      if(headName == "Content-Length")
        m_contentLength = atoi(headVal.c_str());
      else if(headName == "Transfer-Encoding" && headVal == "chunked")
        m_chunkedEncoding = true;
    }
  }

  return auto_ptr<HTTPResponse>(resp);
}

size_t HTTPClient::readBody(const HTTPResponse& resp, char* buffer, size_t size)
{
  size_t ret;

  if(m_chunkedEncoding)
  {
    // get next chunk size if unknown ...
    if(m_chunkSize == 0)
    {
      _bla:
      string str;
      try
      {
        str = readLine(30000);
      }
      catch(IOError& e)
      {
        return 0;
      }

      if(str.empty() || str == "\r\n")
        goto _bla;

      istringstream is(str);
      is >> hex >> m_chunkSize;

      if(!m_chunkSize)
        return 0;
    }

    if(m_bodyLength + size > m_chunkSize)
      size = m_chunkSize - m_bodyLength;

    ret = read(buffer, size);
    m_bodyLength += ret;

    if(m_bodyLength == m_chunkSize)
    {
      m_bodyLength = 0;
      m_chunkSize = 0;
    }
  }
  else
  {
    if(m_contentLength > 0)
    {
      if(m_bodyLength + size > m_contentLength)
        size = m_contentLength - m_bodyLength;

      if(!size)
        return 0;

      ret = read(buffer, size);
      m_bodyLength += ret;
    }
    else
    {
      ret = read(buffer, size);
    }
  }

  return ret;
}

}
