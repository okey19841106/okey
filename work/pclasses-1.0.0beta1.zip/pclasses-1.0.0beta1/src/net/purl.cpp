/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2002  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/purl.h"
#include "pclasses/ptypes.h"
#include "pclasses/pnetdb.h"

#ifndef WIN32
  #include <netinet/in.h>
  #include <arpa/inet.h>
  #include <netdb.h>
#endif

#include <sstream>

namespace P {

using namespace std;

URL::URL()
{
  m_proto = "file";
  m_port    = 0;
  m_path    = "/";
}

URL::URL(const string& url) throw(InvalidURL,NetDbError)
{
  *this = url;
}

URL::URL(const URL& url)
: m_proto(url.m_proto), m_host(url.m_host), m_user(url.m_user),
  m_passwd(url.m_passwd), m_port(url.m_port), m_path(url.m_path)
{}

URL::~URL()
{
}

void URL::setProtocol(const string& proto, bool setPort)
{
  m_proto = proto;

  if(setPort)
  {
    m_port = lookupPort(proto);
  }
}

void URL::setHost(const string& host)
{
  m_host = host;
}

void URL::setUser(const string& user)
{
  m_user = user;
}

void URL::setPassword(const string& passwd)
{
  m_passwd = passwd;
}

void URL::setPort(unsigned short port)
{
  m_port = port;
}

void URL::setPath(const string& path)
{
  if(path.empty())
    m_path = "/";
  else
    m_path = path;
}

URL& URL::operator=(const URL& url)
{
  m_proto = url.m_proto;
  m_host  = url.m_host;
  m_user  = url.m_user;
  m_passwd= url.m_passwd;
  m_port  = url.m_port;
  m_path  = url.m_path;
  return *this;
}

URL& URL::operator=(const string& url) throw(InvalidURL,NetDbError)
{
  string proto, host, user, passwd, path, port;
  istringstream is(url);
  ostringstream os;
 
  char ch;
  bool atfound = url.find('@') != (size_t)-1 ? true : false;
  
  // parse until protocol delimiter found...
  while((is >> ch))
  {
    if(ch == ':')
    {
      if((is >> ch) && ch == '/' &&
         (is >> ch) && ch == '/')
         break;

      throw;
    }
    else if(!isalnum(ch) && !isalpha(ch))
      throw;
    
    os << ch;
  }

  if(!is)
    throw InvalidURL("Invalid url", P_SOURCEINFO);

  proto = os.str();
  os.str("");

  // parse hostname ...
  bool atproc = false;
  while((is >> ch))
  {
    // username in hostname ?
    if(ch == '@')
    {
      user = os.str();
      os.str("");

      size_t pos = user.find(':');
      if(pos != (size_t)-1)
      {      
        passwd = user.substr(pos+1, user.length() - (pos + 1));
        user   = user.substr(0, pos);
      }
            
      atproc = true;
      continue;
    }
    else if(((atfound && ch == ':') && (atproc && ch == ':')) || ch == '/')
      break;

    os << ch;
  }  

  host = os.str();
  os.str("");

  if(!is)
  {
    m_proto = proto;
    m_host  = host;
    m_user  = user;
    m_passwd= passwd;
    m_port  = lookupPort(proto);
    m_path  = "/";
    return *this;
  }
  
  // parse port ...
  if(ch == ':')
  {
    while((is >> ch))
    {
      if(ch == '/')
        break;
      else if(!isdigit(ch))
        throw InvalidURL("Non-digit in port not allowed", P_SOURCEINFO);

      os << ch;
    }

    port = os.str();
    os.str("");
  }

  if(!is)
  {
    m_proto = proto;
    m_host  = host;
    m_user  = user;
    m_passwd= passwd;

    m_port = atoi(port.c_str());
    if(!m_port)
      m_port = lookupPort(proto);
    
    m_path  = "/";
    return *this;
  }

  os << '/';
  
  // parse path
  while((is >> ch))
    os << ch;
    
  m_proto = proto;
  m_host  = host;
  m_user  = user;
  m_passwd= passwd;

  m_port = atoi(port.c_str());
  if(!m_port)
    m_port = lookupPort(proto);

  m_path = os.str();
            
  return *this;    
}

bool URL::operator==(const URL& url) const
{
  if(m_proto == url.m_proto && m_host == url.m_host &&
     m_user == url.m_user && m_passwd == url.m_passwd &&
     m_port == url.m_port && m_path == url.m_path)
     return true;
  return false;
}

string URL::str() const
{
  ostringstream os;
  os << *this;
  return os.str();
}

ostream& operator<<(ostream& os, const URL& url)
{
  os << url.m_proto << "://";

  if(!url.m_user.empty())
  {
    os << url.m_user;
    os << '@';
  }
    
  os << url.m_host;

  if(url.m_port != URL::lookupPort(url.m_proto))
    os << ':' << url.m_port;

  os << url.m_path;
  return os;
}

istream& operator>>(istream& is, URL& url) throw(InvalidURL)
{
  string str;
  if(is)
  {
    is >> str;
    url = str;
  }
  
  return is;
}

unsigned short URL::lookupPort(const string& service, const string& proto)
{
  NetDb::ServiceEntry se = NetDb::serviceByName(service, proto);
  return se.port();
}

}
