/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/pconfig.h"
#include "pclasses/pexception.h"
#include "pclasses/pnetwork.h"

#ifndef WIN32
  #include <sys/types.h>
  #include <sys/ioctl.h>
  #include <sys/socket.h>
  #ifdef HAVE_SOCKIO_H
    #include <sys/sockio.h>
  #endif
  #include <net/if.h>
  #include <netinet/in.h>
  #include <arpa/inet.h>
  #include <unistd.h>
  #include <errno.h>
#else
  #include <winsock2.h>
  #include <ws2tcpip.h>
#endif

namespace P {

using namespace std;

NetDeviceInfo::NetDeviceInfo(const string& devName, const InetAddress& addr, const InetAddress& netmask,
                             const InetAddress& brdcast, int mtu)
: m_devName(m_devName), m_addr(addr),
  m_netmask(netmask), m_broadcast(brdcast), m_mtu(mtu)
{}

NetDeviceInfo::NetDeviceInfo(const NetDeviceInfo& ndi)
: m_devName(ndi.m_devName), m_addr(ndi.m_addr), m_netmask(ndi.m_netmask),
  m_broadcast(ndi.m_broadcast), m_mtu(ndi.m_mtu)
{}

NetDeviceInfo::~NetDeviceInfo()
{}

NetDeviceInfo& NetDeviceInfo::operator=(const NetDeviceInfo& ndi)
{
  m_devName   = ndi.m_devName;
  m_addr      = ndi.m_addr;
  m_netmask   = ndi.m_netmask;
  m_broadcast = ndi.m_broadcast;
  m_mtu       = ndi.m_mtu;
  return *this;
}

void NetDeviceInfo::enumDevices(list<NetDeviceInfo>& devlist)
{
  devlist.clear();

  #ifdef WIN32
  {
    SOCKET s;
    _enumsocket:
    s = WSASocket(AF_INET, SOCK_DGRAM, 0, 0, 0, 0);
    if(s == INVALID_SOCKET)
      throw IOError(WSAGetLastError(), "Could not open socket", P_SOURCEINFO);

    char outbuff[8192];
    DWORD outlen;
    DWORD ret = WSAIoctl(s, SIO_GET_INTERFACE_LIST, 0, 0, outbuff, sizeof(outbuff), &outlen, 0, 0);
    if(ret == SOCKET_ERROR)
      throw IOError(WSAGetLastError(), "Could not ioctl on socket", P_SOURCEINFO);

    INTERFACE_INFO* iflist = (INTERFACE_INFO*)outbuff;
    int ifcount = outlen / sizeof(INTERFACE_INFO);

    InetAddress addr, brdaddr, maskaddr;

    for(int i = 0; i < ifcount; ++i)
    {
      addr     = ((sockaddr_in&)iflist[i].iiAddress).sin_addr;
      brdaddr  = ((sockaddr_in&)iflist[i].iiBroadcastAddress).sin_addr;
      maskaddr = ((sockaddr_in&)iflist[i].iiNetmask).sin_addr;
      devlist.push_back(NetDeviceInfo("", addr, brdaddr, maskaddr, -1));
    }

    closesocket(s);
  }
  #else
  {
    char buffer[8192];
    struct ifconf ifc;

    int fd = socket(AF_INET, SOCK_DGRAM, 0);
    if(fd == -1)
      throw IOError(errno, "Could not open socket", P_SOURCEINFO);

    ifc.ifc_len = sizeof(buffer);
    ifc.ifc_buf = buffer;

    if(ioctl(fd, SIOCGIFCONF, &ifc) == -1)
      throw IOError(errno, "Could not ioctl on socket", P_SOURCEINFO);

    InetAddress addr, brdaddr, maskaddr;
    int mtu;

    int count = ifc.ifc_len / sizeof(ifreq);
    for(int i = 0; i < count; ++i)
    {
      if(ifc.ifc_req[i].ifr_addr.sa_family != AF_INET)
        continue;

      addr = ((sockaddr_in&)ifc.ifc_req[i].ifr_addr).sin_addr;

      struct ifreq devifreq;
      strcpy(devifreq.ifr_name, ifc.ifc_req[i].ifr_name);

      if(ioctl(fd, SIOCGIFBRDADDR, &devifreq) == -1)
        brdaddr = htonl(INADDR_ANY);
      else
        brdaddr = ((sockaddr_in&)devifreq.ifr_broadaddr).sin_addr;

      if(ioctl(fd, SIOCGIFNETMASK, &devifreq) == -1)
        maskaddr = htonl(INADDR_BROADCAST);
      else
        maskaddr = ((sockaddr_in&)devifreq.ifr_addr).sin_addr;

      if(ioctl(fd, SIOCGIFMTU, &devifreq) == -1)
        mtu = 0;
      else
      {
        #ifdef ifr_mtu
        mtu = devifreq.ifr_mtu;
        #else
        mtu = devifreq.ifr_metric;
        #endif
      }

      devlist.push_back(NetDeviceInfo(ifc.ifc_req[i].ifr_name, addr, brdaddr, maskaddr, mtu));
    }

    close(fd);
  }
  #endif
}

}
