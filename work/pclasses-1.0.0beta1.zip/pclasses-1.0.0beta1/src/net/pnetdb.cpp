/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/pconfig.h"
#include "pclasses/pcriticalsection.h"
#include "pclasses/pnetdb.h"
#include "pclasses/pinetaddr.h"

#ifdef HAVE_IPV6
#include "pclasses/pinet6addr.h"
#endif

#ifdef WIN32
  #include <winsock2.h>
  #include <windows.h>
  #include <lmerr.h>
  #define h_errno WSAGetLastError()
#else
  #include <netdb.h>
  #include <errno.h>
#endif


#ifdef WIN32
// char* cast for win32 :)
inline struct hostent* gethostbyaddr(const void* addr, socklen_t addrlen, int family)
{ return gethostbyaddr((const char*)addr, addrlen, family); }
#endif

namespace P {

using namespace std;

string NetDbError::text() const throw()
{
  #ifdef WIN32
  {

    char tmpbuffer[4096];

    HMODULE hModule = NULL;
    DWORD fmtFlags = FORMAT_MESSAGE_IGNORE_INSERTS | FORMAT_MESSAGE_FROM_SYSTEM;

    if(m_err >= NERR_BASE && m_err <= MAX_NERR) 
    {
      hModule = LoadLibraryEx("netmsg.dll", NULL, LOAD_LIBRARY_AS_DATAFILE);

      if(hModule != NULL)
        fmtFlags |= FORMAT_MESSAGE_FROM_HMODULE;
    }

    DWORD msglen = 
      FormatMessage(fmtFlags, hModule, m_err, 
                    MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
                    tmpbuffer, 4096, NULL);

    if(hModule != NULL)
      FreeLibrary(hModule);

    string msg;
    msg.assign(tmpbuffer, msglen);
    return msg;
  }
  #else
  {
    return string(hstrerror(m_err));
  }
  #endif
}

NetDb::HostEntry::HostEntry()
{}

NetDb::HostEntry::HostEntry(const HostEntry& h)
: m_domain(h.m_domain), m_name(h.m_name), m_aliases(h.m_aliases)
{
  vector<NetworkAddress*>::const_iterator i = h.m_addrs.begin();
  while(i != h.m_addrs.end())
  {
    m_addrs.push_back((*i)->clone());
    ++i;
  }
}

NetDb::HostEntry::HostEntry(const hostent* he)
: m_domain(he->h_addrtype), m_name(he->h_name)
{
  int i = 0;
  while(he->h_aliases[i])
    m_aliases.push_back(he->h_aliases[i++]);

  i = 0;
  if(m_domain == AF_INET)
  {
    while(he->h_addr_list[i])
      m_addrs.push_back(new InetAddress(*(in_addr*)he->h_addr_list[i++]));
  }
  #ifdef HAVE_IPV6
  else if(m_domain == AF_INET6)
  {
    while(he->h_addr_list[i])
      m_addrs.push_back(new Inet6Address(*(in6_addr*)he->h_addr_list[i++]));
  }
  #endif
  else
    throw;
}

NetDb::HostEntry::~HostEntry()
{
  vector<NetworkAddress*>::const_iterator i = m_addrs.begin();
  while(i != m_addrs.end())
  {
    delete *i;
    ++i;
  }
}

NetDb::HostEntry& NetDb::HostEntry::operator=(const NetDb::HostEntry& h)
{
  m_domain  = h.m_domain;
  m_name    = h.m_name;
  m_aliases = h.m_aliases;
  
  m_addrs.clear();
  
  vector<NetworkAddress*>::const_iterator i = h.m_addrs.begin();
  while(i != h.m_addrs.end())
  {
    m_addrs.push_back((*i)->clone());
    ++i;
  }
  
  return *this;
}

NetDb::ServiceEntry::ServiceEntry()
{}

NetDb::ServiceEntry::ServiceEntry(const ServiceEntry& s)
: m_name(s.m_name), m_aliases(s.m_aliases), m_port(s.m_port), m_proto(s.m_proto)
{
}

NetDb::ServiceEntry::ServiceEntry(const servent* s)
: m_name(s->s_name), m_aliases(), m_port(ntohs(s->s_port)), m_proto(s->s_proto)
{
  int i = 0;
  while(s->s_aliases[i])
    m_aliases.push_back(s->s_aliases[i++]);
}

NetDb::ServiceEntry::~ServiceEntry()
{}

NetDb::ServiceEntry& NetDb::ServiceEntry::operator=(const NetDb::ServiceEntry& s)
{
  m_name    = s.m_name;
  m_aliases = s.m_aliases;
  m_port    = s.m_port;
  m_proto   = s.m_proto;
  return *this;
}

NetDb::HostEntry NetDb::hostByName(const string& name, int domain) throw(NetDbError)
{
  struct hostent* hep = 0;
  
  #ifdef HAVE_GETHOSTBYNAME2_R
  {
    struct hostent he;
    size_t bufflen;
    char* buff;
    int ret, herr;

    bufflen = 1024;
    buff = (char*)malloc(1024);

    while((ret = gethostbyname2_r(name.c_str(), domain, &he, buff, bufflen, &hep, &herr)) == ERANGE)
    {
      bufflen *= 2;
      buff = (char*)realloc(buff, bufflen);
    }

    if(ret || hep == 0)
    {
      free(buff);
      throw NetDbError(herr, "Could not resolve host by name", P_SOURCEINFO);
    }

    HostEntry host(hep);
    free(buff);
    return host;
  }
  #elif defined(HAVE_GETHOSTBYNAME2)
  {
    #ifndef WIN32
    static CriticalSection mutex;
    CriticalSection::Lock l(mutex);
    #endif
  
    hep = gethostbyname2(name.c_str(), domain);
    if(!hep)
      throw NetDbError(h_errno, "Could not resolve host by name", P_SOURCEINFO);
  
    return HostEntry(hep);
  }
  #else
  {
    #ifndef WIN32
    static CriticalSection mutex;
    CriticalSection::Lock l(mutex);
    #endif
  
    /* gethostbyname can only look up AF_INET */
    if(domain != AF_INET)
      throw NetDbError(0, "Unsupported protocol domain", P_SOURCEINFO);

    hep = gethostbyname(name.c_str());
    if(!hep)
      throw NetDbError(h_errno, "Could not resolve host by name", P_SOURCEINFO);

    return HostEntry(hep);
  }
  #endif
}

NetDb::HostEntry NetDb::hostByAddress(const NetworkAddress& addr) throw(NetDbError)
{
  struct hostent* hep = 0;

  #ifdef HAVE_GETHOSTBYADDR_R
  {
    struct hostent he;
    size_t bufflen;
    char* buff;
    int ret, herr;

    bufflen = 1024;
    buff = (char*)malloc(1024);

    #ifndef sun
    while((ret = gethostbyaddr_r(addr.addr(), addr.addrlen(), addr.family(), &he, buff, bufflen, &hep, &herr)) == ERANGE)
    {
      bufflen *= 2;
      buff = (char*)realloc(buff, bufflen);
    }
    #else
    while(1)
    {
      hep = gethostbyaddr_r((const char*)addr.addr(), addr.addrlen(), addr.family(), &he, buff, bufflen, &herr);
      if(!hep)
      {
        if(errno == ERANGE)
        {
          bufflen *= 2;
          buff = (char*)realloc(buff, bufflen);
          continue;
        }
          
        break;
      }
      else
      {
        ret = 0;
        break;
      }
    }
    #endif

    if(ret || hep == 0)
    {
      free(buff);
      throw NetDbError(herr, "Could not resolve host by address", P_SOURCEINFO);
    }

    HostEntry host(hep);
    free(buff);
    return host;
  }
  #else
  {
    #ifndef WIN32
    static CriticalSection mutex;
    CriticalSection::Lock l(mutex);
    #endif
  
    hep = gethostbyaddr(addr.addr(), addr.addrlen(), addr.family());
    if(!hep)
      throw NetDbError(h_errno, "Could not resolve host by address", P_SOURCEINFO);

    return HostEntry(hep);
  }
  #endif
}

NetDb::ServiceEntry NetDb::serviceByName(const string& name, const string& proto) throw(NetDbError)
{
  servent* res = 0;
  
  #ifdef HAVE_GETSERVBYNAME_R
  {
    char buff[2048];
    servent se;
    
    #ifndef sun
    getservbyname_r(name.c_str(), proto.c_str(), &se, buff, sizeof(buff), &res);
    #else
    res = getservbyname_r(name.c_str(), proto.c_str(), &se, buff, sizeof(buff));
    #endif
    if(res)
      return ServiceEntry(res);
  }
  #else
  {
    #ifndef WIN32
    static CriticalSection mutex;
    CriticalSection::Lock l(mutex);
    #endif
    
    res = getservbyname(name.c_str(), proto.c_str());
    if(res)
      return ServiceEntry(res);
  }
  #endif

  throw NetDbError(h_errno, "Could not resolve service by name", P_SOURCEINFO);
}

NetDb::ServiceEntry NetDb::serviceByPort(port_t port, const string& proto) throw(NetDbError)
{
  servent* res = 0;
  
  #ifdef HAVE_GETSERVBYPORT_R
  {
    char buff[2048];
    servent se;
    
    #ifndef sun
    getservbyport_r(port, proto.c_str(), &se, buff, sizeof(buff), &res);
    #else
    res = getservbyport_r(port, proto.c_str(), &se, buff, sizeof(buff));
    #endif
    if(res)
      return ServiceEntry(res);
  }
  #else
  {
    #ifndef WIN32
    static CriticalSection mutex;
    CriticalSection::Lock l(mutex);
    #endif
    
    res = getservbyport(port, proto.c_str());
    if(res)
      return ServiceEntry(res);
  }
  #endif

  throw NetDbError(h_errno, "Could not resolve service by port", P_SOURCEINFO);
}

}
