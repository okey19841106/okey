/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/config.h"
#include "pclasses/patalkaddr.h"

#ifdef WIN32
  #include <winsock2.h>
#else
  #include <sys/types.h>
  #include <sys/socket.h>
  #include <netatalk/at.h>
#endif

#include <errno.h>
#include <string.h>

namespace P {

using namespace std;

ATalkAddress::ATalkAddress()
: NetworkAddress(AF_APPLETALK, sizeof(at_addr))
{
}

ATalkAddress::ATalkAddress(const NetworkAddress& na) throw(LogicError)
: NetworkAddress(na)
{
  if(na.family() != AF_APPLETALK)
    throw LogicError("Cannot construct ATalkAddress from other NetworkAddress", P_SOURCEINFO);
}

ATalkAddress::ATalkAddress(const at_addr& addr)
: NetworkAddress(AF_APPLETALK, sizeof(at_addr))
{
  memcpy(_addr(), &addr, sizeof(at_addr));
}

ATalkAddress::ATalkAddress(const string& ataddr)
: NetworkAddress(AF_APPLETALK, sizeof(at_addr))
{
  *this = ataddr;
}

const at_addr& ATalkAddress::ataddr() const
{
  return *((at_addr*)_addr());
}

ATalkAddress& ATalkAddress::operator=(const NetworkAddress& addr) throw(LogicError)
{
  NetworkAddress::operator=(addr);

  if(addr.family() != AF_APPLETALK)
    throw LogicError("Cannot assign other NetworkAddress than ATalkAddress", P_SOURCEINFO);

  return *this;
}

ATalkAddress& ATalkAddress::operator=(const at_addr& addr)
{
  memcpy(_addr(), &addr, sizeof(at_addr));
  return *this;
}

ATalkAddress& ATalkAddress::operator=(const string& ataddr)
{
  //@todo iplement ATalkAddress::operator=(string)
  return *this;
}

string ATalkAddress::str() const
{
  //@todo implement ATalkAddress::str()
  string addr;
  return addr;
}

NetworkAddress* ATalkAddress::clone() const
{
  return new ATalkAddress(*this);
}

ostream& operator<<(ostream& os, const ATalkAddress& addr)
{
  os << addr.str();
  return os;
}

istream& operator>>(istream& is, ATalkAddress& addr)
{
  string str;
  is >> str;
  addr = str;
  return is;
}

}
