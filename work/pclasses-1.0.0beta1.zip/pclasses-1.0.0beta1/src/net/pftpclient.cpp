/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/config.h"

#ifndef WIN32
  #include <netinet/in.h>
#else
  #include <winsock2.h>
#endif

#include "pclasses/piostream.h"
#include "pclasses/pftpclient.h"
#include "pclasses/pinetaddr.h"

#ifdef HAVE_IPV6
#include "pclasses/pinet6addr.h"
#endif

#include <sstream>

namespace P {

using namespace std;

FTPError::FTPError(const char* what, const list<string>& text, const SourceInfo& si) throw()
: RuntimeError(what, si)
{
  try
  {
    ostringstream os;
    for(list<string>::const_iterator i = text.begin(); i != text.end(); i++)
    {
      if(i != text.begin())
        os << pendl;

      os << *i;
    }

    m_text = os.str();
  }
  catch(...)
  {
  }
}

FTPError::~FTPError() throw()
{
}


FTPResponse::FTPResponse(unsigned int code, list<string>& text)
: m_code(code), m_text(text)
{
}

FTPResponse::~FTPResponse()
{
}

ostream& operator<<(ostream& os, const FTPResponse& resp)
{
  list<string> tl = resp.text();
  for(list<string>::const_iterator i = tl.begin(); i != tl.end(); i++)
    os << *i << pendl;

  return os;
}


FTPData::FTPData(FTPClient* cl, StreamSocketServer& srv) throw(IOError)
: StreamSocket(srv), m_client(cl)
{
}

FTPData::FTPData(FTPClient* cl, const NetworkAddress& addr, port_t port) throw(IOError)
: StreamSocket(addr,port), m_client(cl)
{
}

FTPData::~FTPData() throw()
{
  try
  {
    close();
  }
  catch(...)
  {
  }
}

size_t FTPData::write(const char* buffer, size_t count) throw(IOError)
{
  return StreamSocket::write(buffer, count);
}

size_t FTPData::read(char* buffer, size_t count) throw(IOError)
{
  size_t ret = StreamSocket::read(buffer, count);
  if(ret == 0)
    close();

  return ret;
}


FTPClient::FTPClient(int domain) throw(IOError)
: StreamSocket(domain), m_transMode(ModeStream), m_transType(TypeASCII), m_dataMode(Passive), m_dataConn(0), m_lastResp(0)
{
}

FTPClient::FTPClient(const NetworkAddress& addr, port_t port) throw(IOError)
: StreamSocket(addr.family()), m_transMode(ModeStream), m_transType(TypeASCII), m_dataMode(Passive), m_dataConn(0), m_lastResp(0)
{
  connect(addr, port);
}

FTPClient::~FTPClient() throw()
{
  try
  {
    close();
  }
  catch(...)
  {
  }

  if(m_lastResp)
    delete m_lastResp;
}

bool FTPClient::testResponse() throw(IOError)
{
  return wait(pendingInput, 0);
}

void FTPClient::connect(const NetworkAddress& addr, port_t port) throw(IOError, FTPError)
{
  StreamSocket::connect(addr, port);

  m_transMode = ModeStream;
  m_transType = TypeASCII;

  const FTPResponse* resp = readResponse();

  if(!resp->isPositiveCompletion())
    throw FTPError("FTP server not ready", resp->text(), P_SOURCEINFO);
}

void FTPClient::close() throw(IOError)
{
  if(m_dataConn)
  {
    delete m_dataConn;
    m_dataConn = 0;
  }

  StreamSocket::shutdown(StreamSocket::disableBoth);
  StreamSocket::close();
}

void FTPClient::sendCmd(const string& cmd) throw(IOError)
{
  ostringstream cmds;
  cmds << cmd << "\r\n";

  string strt = cmds.str();
  write(strt.c_str(), strt.size());
}

const FTPResponse* FTPClient::readResponse() throw(IOError)
{
  bool multiLineResp = false;

  list<string> resptext;
  unsigned int respcode;
  size_t respl = 0;
  string resps;

  resps = readLine(30000);
  respl = resps.size();
  resptext.push_back(resps);

  if(respl > 3)
  {
    string tmp = resps.substr(0,3);
    istringstream istmp(tmp);
    istmp >> respcode;

    if(respl > 4 && resps[3] == '-')
      multiLineResp = true;
  }
  else
  {
    throw;
  }

  while(multiLineResp)
  {
    resps = readLine(30000);
    respl = resps.size();
    resptext.push_back(resps);

    // end of response ?
    if(respl > 3 && resps[0] != ' ' && resps[3] == ' ')
      break;
  }

  if(m_lastResp)
  {
    delete m_lastResp;
    m_lastResp = 0;
  }

  m_lastResp = new FTPResponse(respcode, resptext);
  return m_lastResp;
}

const FTPResponse* FTPClient::lastResponse()
{
  return m_lastResp;
}

void FTPClient::login(const string& user, const string& passwd, const string& acct) throw(IOError,FTPError)
{
  // send username and read the response...
  ostringstream users;
  users << "USER " << user;
  sendCmd(users.str());

  const FTPResponse* resp = readResponse();
  if(resp->isPositiveCompletion())
    return;

  if(!resp->isPositiveIntermediate())
    throw FTPError("Unknown response for USER command", resp->text(), P_SOURCEINFO);

  // send password and read response...
  ostringstream passs;
  passs << "PASS " << passwd;
  sendCmd(passs.str());

  resp = readResponse();

  // account required for login ?
  if(resp->code() == 332)
  {
    ostringstream accts;
    accts << "ACCT " << acct;
    sendCmd(accts.str());

    resp = readResponse();
  }

  if(!resp->isPositiveCompletion())
    throw FTPError("Login failed", resp->text(), P_SOURCEINFO);
}

void FTPClient::logout() throw(IOError,FTPError)
{
  if(m_dataConn)
  {
    delete m_dataConn;
    m_dataConn = 0;
  }

  sendCmd("QUIT");
  const FTPResponse* resp = readResponse();

  if(!resp->isPositiveCompletion())
    throw FTPError("Logout failed", resp->text(), P_SOURCEINFO);
}

void FTPClient::setMode(transMode_t mode) throw(IOError, FTPError)
{
  ostringstream modes;
  modes << "MODE ";

  switch(mode)
  {
    case ModeStream:
        modes << "S";
        break;

    case ModeBlock:
        modes << "B";
        break;

    case ModeCompressed:
        modes << "C";
        break;

    default:
        throw;
  }

  sendCmd(modes.str());
  const FTPResponse* resp = readResponse();

  if(!resp->isPositiveCompletion())
    throw FTPError("Could not set transfer mode", resp->text(), P_SOURCEINFO);

  m_transMode = mode;
}

void FTPClient::setType(transType_t type) throw(IOError, FTPError)
{
  ostringstream types;
  types << "TYPE ";

  switch(type)
  {
    case TypeASCII:
      types << "A";
      break;

    case TypeEBCDIC:
      types << "E";
      break;

    case TypeImage:
      types << "I";
      break;

    default:
      break;
  }

  sendCmd(types.str());
  const FTPResponse* resp = readResponse();

  if(!resp->isPositiveCompletion())
    throw FTPError("Could not set transfer type", resp->text(), P_SOURCEINFO);

  m_transType = type;
}

string FTPClient::cwd() throw(IOError, FTPError)
{
  sendCmd("PWD");

  const FTPResponse* resp = readResponse();
  if(!resp->isPositiveCompletion())
    throw FTPError("Could not get working directory", resp->text(), P_SOURCEINFO);

  istringstream is(*resp->text().begin());

  string tmp, dir;
  is >> tmp;
  is >> dir;

  if(dir.size() > 0 && dir[0] == '\"')
    dir = dir.substr(1, dir.size()-2);

  return dir;
}

void FTPClient::chdir(const string& path) throw(IOError, FTPError)
{
  ostringstream chdirs;
  chdirs << "CWD " << path;

  sendCmd(chdirs.str());

  const FTPResponse* resp = readResponse();
  if(!resp->isPositiveCompletion())
    throw FTPError("Could not change directory", resp->text(), P_SOURCEINFO);
}

void FTPClient::cdup() throw(IOError, FTPError)
{
  sendCmd("CDUP");

  const FTPResponse* resp = readResponse();
  if(!resp->isPositiveCompletion())
    throw FTPError("Could not change directory", resp->text(), P_SOURCEINFO);
}

void FTPClient::mkdir(const string& path) throw(IOError, FTPError)
{
  ostringstream mkdirs;
  mkdirs << "MKD " << path;

  sendCmd(mkdirs.str());

  const FTPResponse* resp = readResponse();
  if(!resp->isPositiveCompletion())
    throw FTPError("Could not create directory", resp->text(), P_SOURCEINFO);
}

void FTPClient::rmdir(const string& path) throw(IOError, FTPError)
{
  ostringstream rmdirs;
  rmdirs << "RMD " << path;

  sendCmd(rmdirs.str());

  const FTPResponse* resp = readResponse();
  if(!resp->isPositiveCompletion())
    throw FTPError("Could not remove directory", resp->text(), P_SOURCEINFO);
}

void FTPClient::remove(const string& path) throw(IOError, FTPError)
{
  ostringstream dels;
  dels << "RM " << path;

  sendCmd(dels.str());

  const FTPResponse* resp = readResponse();
  if(!resp->isPositiveCompletion())
    throw FTPError("Could not delete file", resp->text(), P_SOURCEINFO);
}

void FTPClient::noop() throw(IOError, FTPError)
{
  sendCmd("NOOP");

  const FTPResponse* resp = readResponse();
  if(!resp->isPositiveCompletion())
    throw FTPError("Could not execute NOOP", resp->text(), P_SOURCEINFO);
}

void FTPClient::initDataConn(const string& cmd) throw(IOError, FTPError)
{
  FTPData* dataConn = 0;
  const FTPResponse* resp = 0;
  auto_ptr<NetworkAddress> srvaddr;
  auto_ptr<StreamSocketServer> srv;
  port_t srvport = 0;

  if(m_dataMode == Active)
  {
    switch(domain())
    {
      case AF_INET:
        {
          auto_ptr<NetworkAddress> tmp = auto_ptr<NetworkAddress>(new InetAddress());
          srvaddr = tmp;
        }
        break;


      #ifdef HAVE_IPV6
      case AF_INET6:
        {
          auto_ptr<NetworkAddress> tmp = auto_ptr<NetworkAddress>(new Inet6Address());
          srvaddr = tmp;
        }
        break;
      #endif
    }

    auto_ptr<StreamSocketServer> tmp = auto_ptr<StreamSocketServer>(new StreamSocketServer(domain()));
    srv = tmp;
    srv->listen();

    port_t tmpport;
    srv->getName(*srvaddr, srvport);
    getName(*srvaddr, tmpport);

    /* init ACTIVE data connection ... */
    ostringstream transmodes;
    switch(domain())
    {
      case AF_INET:
        {
          InetAddress* inaddr = (InetAddress*)srvaddr.get();
          transmodes << "PORT "
                    << (int)inaddr->oct1() << "," << (int)inaddr->oct2() << ","
                    << (int)inaddr->oct3() << "," << (int)inaddr->oct4() << ","
                    << (int)((uint8_t)(srvport >> 8)) << ","
                    << (int)((uint8_t)(srvport));
        }
        break;

      #ifdef HAVE_IPV6
      case AF_INET6:
        {
          Inet6Address* inaddr = (Inet6Address*)srvaddr.get();
        }
        break;
      #endif
    }

    sendCmd(transmodes.str());

    resp = readResponse();
    if(!resp->isPositiveCompletion())
      throw FTPError("Could not init data connection", resp->text(), P_SOURCEINFO);
  }
  else
  {
    ostringstream transmodes;
    transmodes << "PASV";
    sendCmd(transmodes.str());

    resp = readResponse();
    if(!resp->isPositiveCompletion())
      throw FTPError("Could not init data connection", resp->text(), P_SOURCEINFO);

    istringstream is(*resp->text().begin());
    char ch = 0;
    do
    {
      is >> ch;
    } while(ch != '(');

    int oct1, oct2, oct3, oct4, port1, port2;
    is >> oct1; is >> ch;
    is >> oct2; is >> ch;
    is >> oct3; is >> ch;
    is >> oct4; is >> ch;
    is >> port1; is >> ch;
    is >> port2;

    srvport = port1 << 8 | port2;
    auto_ptr<NetworkAddress> tmp = auto_ptr<NetworkAddress>(new InetAddress(oct1,oct2,oct3,oct4));
    srvaddr = tmp;
    dataConn = new FTPData(this, *srvaddr, srvport);
  }

  sendCmd(cmd);

  resp = readResponse();
  if(!resp->isPositivePreliminary())
    throw FTPError("Could not start data connection", resp->text(), P_SOURCEINFO);

  if(m_dataMode == Active)
  {
    dataConn = new FTPData(this, *srv);
  }

  if(m_dataConn)
    delete m_dataConn;

  m_dataConn = dataConn;
}

FTPData* FTPClient::dir(const string& path) throw(IOError, FTPError)
{
  ostringstream dirs;
  dirs << "LIST";
  if(!path.empty())
    dirs << " " << path;

  initDataConn(dirs.str());
  return m_dataConn;
}

FTPData* FTPClient::store(const string& path) throw(IOError, FTPError)
{
  ostringstream stores;
  stores << "STOR " << path;

  initDataConn(stores.str());
  return m_dataConn;
}

FTPData* FTPClient::retrieve(const string& path) throw(IOError, FTPError)
{
  ostringstream stores;
  stores << "RETR " << path;

  initDataConn(stores.str());
  return m_dataConn;
}

}
