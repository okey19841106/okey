/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/pinet6addr.h"

#ifdef WIN32
  #include <winsock2.h>
  #include <windows.h>
#else
  #include <netinet/in.h>
  #include <arpa/inet.h>
  #include <errno.h>
#endif

#include <string.h>

namespace P {

using namespace std;

Inet6Address::Inet6Address()
: NetworkAddress(AF_INET6, sizeof(in6_addr))
{}

Inet6Address::Inet6Address(const NetworkAddress& na)
: NetworkAddress(na)
{
  if(na.family() != AF_INET6)
    throw;
}

Inet6Address::Inet6Address(const string& ipaddr)
: NetworkAddress(AF_INET, sizeof(in_addr))
{
  *this = ipaddr;
}

Inet6Address::Inet6Address(const in6_addr& addr)
: NetworkAddress(AF_INET6, sizeof(in6_addr))
{
  memcpy(_addr(), &addr, sizeof(in6_addr));
}

const in6_addr& Inet6Address::inaddr() const
{
  return *((in6_addr*)_addr());
}

string Inet6Address::str() const
{
  //@todo implement Inet6Address::str()
  return "";
}

NetworkAddress* Inet6Address::clone() const
{
  return new Inet6Address(*this);
}

Inet6Address& Inet6Address::operator=(const string& ipaddr)
{
  //@todo implement Inet6Address::operator=(string)
  return *this;
}

Inet6Address& Inet6Address::operator=(const in6_addr& addr)
{
  memcpy(_addr(), &addr, sizeof(in6_addr));
  return *this;
}

ostream& operator<<(ostream& os, const Inet6Address& addr)
{
  os << addr.str();
  return os;
}

istream& operator>>(istream& is, Inet6Address& addr)
{
  string str;
  is >> str;
  addr = str;
  return is;
}

}
