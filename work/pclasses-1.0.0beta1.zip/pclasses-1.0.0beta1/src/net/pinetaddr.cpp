/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/pinetaddr.h"

#ifdef WIN32
  #include <winsock2.h>
  #include <windows.h>
#else
  #include <netinet/in.h>
  #include <arpa/inet.h>
  #include <errno.h>
#endif

#include <string.h>

namespace P {

using namespace std;

InetAddress::InetAddress()
: NetworkAddress(AF_INET, sizeof(in_addr))
{}

InetAddress::InetAddress(const NetworkAddress& na)
: NetworkAddress(na)
{
  if(na.family() != AF_INET)
    throw;
}

InetAddress::InetAddress(uint32_t addr)
: NetworkAddress(AF_INET, sizeof(in_addr))
{
  *this = addr;
}

InetAddress::InetAddress(const in_addr& addr)
: NetworkAddress(AF_INET, sizeof(in_addr))
{
  *this = addr;
}

InetAddress::InetAddress(const string& ipaddr)
: NetworkAddress(AF_INET, sizeof(in_addr))
{
  *this = ipaddr;
}

InetAddress::InetAddress(uint8_t oct1, uint8_t oct2, uint8_t oct3, uint8_t oct4)
: NetworkAddress(AF_INET, sizeof(in_addr))
{
  uint32_t addr = (oct1 << 24) | (oct2 << 16) | (oct3 << 8) | oct4;
  *(uint32_t*)_addr() = htonl(addr);
}

const in_addr& InetAddress::inaddr() const
{
  return *((in_addr*)_addr());
}

uint8_t InetAddress::oct1() const
{
  uint32_t addr = ntohl((uint32_t&)inaddr());
  return (uint8_t)(addr >> 24);
}

uint8_t InetAddress::oct2() const
{
  uint32_t addr = ntohl((uint32_t&)inaddr());
  return (uint8_t)(addr >> 16);
}

uint8_t InetAddress::oct3() const
{
  uint32_t addr = ntohl((uint32_t&)inaddr());
  return (uint8_t)(addr >> 8);
}

uint8_t InetAddress::oct4() const
{
  uint32_t addr = ntohl((uint32_t&)inaddr());
  return (uint8_t)addr;
}

InetAddress& InetAddress::operator=(const in_addr& addr)
{
  memcpy(_addr(), &addr, sizeof(in_addr));
  return *this;
}

InetAddress& InetAddress::operator=(uint32_t addr)
{
  memcpy(_addr(), &addr, sizeof(uint32_t));
  return *this;
}

InetAddress& InetAddress::operator=(const string& ipaddr)
{
  #ifdef WIN32
  ((in_addr*)_addr())->S_un.S_addr = inet_addr(ipaddr.c_str());
  #else
  in_addr l_addr;
  if(!inet_aton(ipaddr.c_str(), &l_addr))
  {
    *this = InetAddress();
    return *this;
  }
  *((in_addr*)_addr()) = l_addr;
  #endif

  return *this;
}

string InetAddress::str() const
{
  string addr = inet_ntoa(*((in_addr*)_addr()));
  return addr;
}

NetworkAddress* InetAddress::clone() const
{
  return new InetAddress(*this);
}

ostream& operator<<(ostream& os, const InetAddress& addr)
{
  os << addr.str();
  return os;
}

istream& operator>>(istream& is, InetAddress& addr)
{
  string str;
  is >> str;
  addr = str;
  return is;
}

}
