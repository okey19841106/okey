/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/psqlvalue.h"
#include <sstream>

namespace P {

using namespace std;

SQLValue::SQLValue(bool null)
: m_null(null)
{
}
 
SQLValue::~SQLValue()
{
}


SQLString::SQLString()
: SQLValue(), m_str("<NULL>")
{
}

SQLString::SQLString(const string& str)
: SQLValue(false), m_str(str)
{
}

SQLString::~SQLString()
{
}

void SQLString::setNull() throw()
{
  m_null = true;
  m_str  = "<NULL>";
}

const string& SQLString::value() const throw()
{
  return m_str;
}

string SQLString::str() const throw()
{
  return m_str;
}

SQLString& SQLString::operator=(const string& str)
{
  m_null = str.empty();
  m_str  = str;
  return *this;
}


SQLInt::SQLInt()
: SQLValue()
{
}

SQLInt::SQLInt(int val)
: SQLValue(false), m_val(val)
{
}

SQLInt::~SQLInt()
{
}

void SQLInt::setNull() throw()
{
  m_null = true;
  m_val = 0;
}

int SQLInt::value() const throw()
{
  return m_val;
}

string SQLInt::str() const throw()
{
  if(!isNull())
  {
    ostringstream os;
    os << m_val;
    return os.str();
  }
  
  return "<NULL>";
}

SQLInt& SQLInt::operator=(int val)
{
  m_null = false;
  m_val  = val;
  return *this;
}

#ifdef HAVE_64BIT_INT

SQLBigInt::SQLBigInt()
: SQLValue()
{
}

SQLBigInt::SQLBigInt(int64_t val)
: SQLValue(false), m_val(val)
{
}

SQLBigInt::~SQLBigInt()
{
}

void SQLBigInt::setNull() throw()
{
  m_null = true;
  m_val = 0;
}

int64_t SQLBigInt::value() const throw()
{
  return m_val;
}

string SQLBigInt::str() const throw()
{
  if(!isNull())
  {
    ostringstream os;
    os << m_val;
    return os.str();
  }
  
  return "<NULL>";
}

SQLBigInt& SQLBigInt::operator=(int64_t val)
{
  m_null = false;
  m_val  = val;
  return *this;
}

#endif


SQLDouble::SQLDouble()
: SQLValue()
{
}

SQLDouble::SQLDouble(const double& val)
: SQLValue(false), m_val(val)
{
}

SQLDouble::~SQLDouble()
{
}

void SQLDouble::setNull() throw()
{
  m_null = true;
  m_val  = 0.0f;
}

const double& SQLDouble::value() const throw()
{
  return m_val;
}

string SQLDouble::str() const throw()
{
  if(!isNull())
  {
    ostringstream os;
    os << m_val;
    return os.str();
  }
  
  return "<NULL>";
}

SQLDouble& SQLDouble::operator=(const double& val)
{
  m_null = false;
  m_val  = val;
  return *this;
}


SQLDateTime::SQLDateTime()
: SQLValue()
{
}

SQLDateTime::SQLDateTime(const DateTime& dt)
: SQLValue(false), m_val(dt)
{
}

SQLDateTime::~SQLDateTime()
{
}

void SQLDateTime::setNull() throw()
{
  m_null = true;
  m_val  = DateTime(Date(1970, 1, 1), Time(0, 0, 0));
}

const DateTime& SQLDateTime::value() const throw()
{
  return m_val;
}

string SQLDateTime::str() const throw()
{
  if(!isNull())
  {
    ostringstream os;
    os << m_val;
    return os.str();
  }
  
  return "<NULL>";
}

SQLDateTime& SQLDateTime::operator=(const DateTime& dt)
{
  m_null = false;
  m_val  = dt;
  return *this;
}

}
