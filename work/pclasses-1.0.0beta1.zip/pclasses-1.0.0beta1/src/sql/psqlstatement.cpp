/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/psqlstatement.h"

namespace P {

using namespace std;

SQLResult::SQLResult(auto_ptr<SQLDriver::ResultHandle> handle)
: m_handle(handle)
{
}

SQLResult::SQLResult(SQLStatement& stmt)
{
  if(stmt.state() < SQLStatement::Executed)
    stmt.exec();
    
  /* compiler bug? ... 
    gcc < 3 does not compile this without a temporary auto_ptr<> */
  auto_ptr<SQLDriver::ResultHandle> h = stmt.handle()->result();
  m_handle = h;
}

SQLResult::~SQLResult()
{
}
    
unsigned int SQLResult::columnCount() const throw()
{
  return m_handle->columnCount();
}

string SQLResult::columnName(unsigned int pos) const
{
  return m_handle->columnName(pos);
}

bool SQLResult::fetch()
{
  return m_handle->fetch();
}

const SQLValue& SQLResult::operator[](const string& field)
{
  return m_handle->value(field);
}

const SQLValue& SQLResult::operator[](unsigned int field)
{
  return m_handle->value(field);
}

SQLStatement::SQLStatement(SQLConnection& conn, const string& stmt)
: m_state(Initial), m_conn(conn), m_handle(conn.handle()->createStmt())
{
  m_stmt << stmt;
}

SQLStatement::~SQLStatement()
{
}

void SQLStatement::prepare() throw(SQLError)
{
  if(state() >= Prepared)
    return;

  handle()->prepare(m_stmt.str());

  m_state = Prepared;
}

void SQLStatement::exec() throw(SQLError)
{
  if(state() < Prepared)
    prepare();

  handle()->exec();

  m_state = Executed;
}

auto_ptr<SQLResult> SQLStatement::result() throw(SQLError)
{
  if(state() < Executed)
    exec();

  return auto_ptr<SQLResult>(new SQLResult(handle()->result()));
}

sqlcount_t SQLStatement::affectedRows() const throw()
{
  return handle()->affectedRows();
}

void SQLStatement::format(const string& fmt, const map<string,const SQLValue*>& vals)
{
  string mystr = fmt;
  map<string,const SQLValue*>::const_iterator i = vals.begin();
  while(i != vals.end())
  {
    string field = ":" + i->first;

    string::size_type pos = mystr.find(field);
    if(pos != string::npos)
      mystr.replace(pos, field.size(), handle()->sqlstr(*i->second));

    ++i;
  }

  m_stmt.str(mystr);
}

SQLStatement& SQLStatement::operator<<(char ch)
{
  m_stmt << ch;
  return *this;
}

SQLStatement& SQLStatement::operator<<(const char* str)
{
  m_stmt << str;
  return *this;
}

SQLStatement& SQLStatement::operator<<(const std::string& str)
{
  m_stmt << str;
  return *this;
}

SQLStatement& SQLStatement::operator<<(const SQLValue& val)
{
  m_stmt << handle()->sqlstr(val);
  return *this;
}

}
