/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/piomanager.h"

namespace P {

using namespace std;

IOManager::IOManager()
{
}

IOManager::~IOManager()
{
  // destroy all plugins we have created ...
  map<string,IOHandler*>::const_iterator i = m_plugins.begin();
  while(i != m_plugins.end())
  {
    m_pluginFactory.destroy(i->second);
    ++i;
  }
}

IORequest_Get* IOManager::get(const URL& url)
{
  IOHandler* handler = findCreateHandler(url.protocol());
  return handler->get(url);
}

IORequest_Put* IOManager::put(const URL& url)
{
  IOHandler* handler = findCreateHandler(url.protocol());
  return handler->put(url);
}

IORequest_Unlink* IOManager::unlink(const URL& url)
{
  IOHandler* handler = findCreateHandler(url.protocol());
  return handler->unlink(url);
}

IORequest_MakeDir* IOManager::mkdir(const URL& url)
{
  IOHandler* handler = findCreateHandler(url.protocol());
  return handler->mkdir(url);
}

IORequest_RemoveDir* IOManager::rmdir(const URL& url)
{
  IOHandler* handler = findCreateHandler(url.protocol());
  return handler->rmdir(url);
}

IORequest_ListDir* IOManager::list(const URL& url)
{
  IOHandler* handler = findCreateHandler(url.protocol());
  return handler->list(url);
}

void IOManager::finish(IORequest* req)
{
  IOHandler* handler = req->handler();
  handler->finish(req);
}

IOHandler* IOManager::findCreateHandler(const string& proto)
{
  // try find a already created plugin instance
  map<string,IOHandler*>::const_iterator i = m_plugins.find(proto);
  if(i != m_plugins.end())
    return i->second;

  // do we provide a plugin for this protocol ?
  if(!m_pluginFactory.provides(proto.c_str()))
    throw RuntimeError("No handler for protocol found", P_SOURCEINFO);

  IOHandler* handler = m_pluginFactory.create(proto.c_str());
  if(!handler)
    throw RuntimeError("Could not handler plugin instance", P_SOURCEINFO);

  m_plugins.insert(make_pair(proto,handler));
  return handler;
}

}
