/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/pmime.h"
#include "pclasses/pfile.h"
#include "pclasses/ptokenizer.h"

#include <algorithm>

namespace P {

using namespace std;

MimeType::MimeType(const string& mediaType, const string& subType,
                   const FileExtVector& fileExts)
: m_mediaType(mediaType), m_subType(subType), m_fileExts(fileExts)
{
}

MimeType::~MimeType()
{
}


MimeTypeDb::MimeTypeDb()
{
  readMimeTypes();
}

MimeTypeDb::~MimeTypeDb()
{
  m_types.clear();
}

MimeType* MimeTypeDb::findByMimeType(const string& mimeTypeName) const
{
  typedef multimap<string,MimeType>::const_iterator MI;

  StringTokenizer tok(mimeTypeName,"/");
  string strMediaType, strSubType;

  tok >> strMediaType;
  tok >> strSubType;

  const MimeType* type = 0;
  pair<MI,MI> i = m_types.equal_range(strMediaType);
  while(1)
  {
    type = &(*i.first).second;

    if(type->subType() == strSubType)
      return const_cast<MimeType*>(type);

    if(i.first == i.second)
      break;

    ++i.first;
  }

  return 0;
}

MimeType* MimeTypeDb::findByFileExt(const string& fileExt) const
{
  const MimeType* type = 0;
  multimap<string,MimeType>::const_iterator i = m_types.begin();

  while(i != m_types.end())
  {
    type = &i->second;

    const MimeType::FileExtVector& fileExts = type->fileExts();

    if(find(fileExts.begin(), fileExts.end(), fileExt) != fileExts.end())
      return const_cast<MimeType*>(type);

    ++i;
  }

  return 0;
}

bool MimeTypeDb::add(const MimeType& type)
{
  if(findByMimeType(type.mimeType()))
    return false;

  insert(type);
  return true;
}

void MimeTypeDb::insert(const MimeType& type)
{
  m_types.insert(make_pair(type.mediaType(), type));
}

File* openMimeTypeFile()
{
  const char* fileNames[] = {
  #ifndef WIN32
    "/usr/share/pclasses/mime.types",
    "/usr/local/share/pclasses/mime.types",
    "/etc/mime.types",
    "/etc/apache2/conf/mime.types",
  #else
  #endif
    0
  };

  File* file = 0;
  unsigned int fileIndex = 0;

  while(fileNames[fileIndex] != 0)
  {
    try
    {
      file = new File(fileNames[fileIndex], File::Read, File::Normal, File::OpenExisting, File::AllowRead);
    }
    catch(...)
    {
      /* Throw out exception if file exists or we do'nt have more filenames
        to try ... */
      if(File::exists(fileNames[fileIndex]) || !fileNames[fileIndex+1])
        throw;

      ++fileIndex;
      continue;
    }

    break;
  }

  return file;
}

void MimeTypeDb::readMimeTypes()
{
  auto_ptr<File> mimeTypeFile(openMimeTypeFile());
  if(!mimeTypeFile.get())
    return;

  IOStream strm(*mimeTypeFile);
  string line;
  string strMediaType, strSubType, strFileExt;
  vector<string> fileExts;

  while(!strm.eof())
  {
    getline(strm, line);

    if(!line.empty() && line[0] != '#')
    {
      StringTokenizer tok(line,"/ \t", StringTokenizer::MatchAny);

      tok >> strMediaType;
      tok >> strSubType;

      if(tok)
      {
        while(tok)
        {
          tok >> strFileExt;
          if(strFileExt.empty())
            continue;

          fileExts.push_back(strFileExt);
        }
      }

      m_types.insert(make_pair(strMediaType, MimeType(strMediaType, strSubType, fileExts)));
      fileExts.clear();
    }
  }
}


}
