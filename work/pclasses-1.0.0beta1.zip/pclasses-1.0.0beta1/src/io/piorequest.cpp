/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/piorequest.h"

namespace P {

using namespace std;

IORequest::Error::Error(const char* what, const string& text, const SourceInfo& si) throw()
: RuntimeError(what, si), m_text(text)
{}

IORequest::Error::~Error() throw()
{}


IORequest::IORequest(IOHandler* handler, const URL& url)
: m_handler(handler), m_url(url), m_state(IORequest::Initial)
{}

IORequest::~IORequest()
{}


IORequest_Get::IORequest_Get(IOHandler* handler, const URL& url)
: IORequest(handler,url)
{}

IORequest_Get::~IORequest_Get()
{}


IORequest_Put::IORequest_Put(IOHandler* handler, const URL& url)
: IORequest(handler,url)
{}

IORequest_Put::~IORequest_Put()
{}


IORequest_Unlink::IORequest_Unlink(IOHandler* handler, const URL& url)
: IORequest(handler,url)
{}

IORequest_Unlink::~IORequest_Unlink()
{}


IORequest_MakeDir::IORequest_MakeDir(IOHandler* handler, const URL& url)
: IORequest(handler,url)
{}

IORequest_MakeDir::~IORequest_MakeDir()
{}


IORequest_RemoveDir::IORequest_RemoveDir(IOHandler* handler, const URL& url)
: IORequest(handler,url)
{}

IORequest_RemoveDir::~IORequest_RemoveDir()
{}


IORequest_ListDir::IORequest_ListDir(IOHandler* handler, const URL& url)
: IORequest(handler,url)
{}

IORequest_ListDir::~IORequest_ListDir()
{}

}
