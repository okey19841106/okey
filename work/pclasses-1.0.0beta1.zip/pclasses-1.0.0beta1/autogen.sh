#!/bin/sh

if test ! -d admin; then
	mkdir admin
fi

export WANT_AUTOMAKE=1.8
export WNAT_AUTOCONF=2.5

if test -n `which autoreconf`; then
	autoreconf -fi
else
	libtoolize -c -f
	aclocal $ACLOCALDIRS -I m4
	autoheader
	automake --add-missing --copy
	autoconf -f
fi

rm COPYING
rm -f config.cache
