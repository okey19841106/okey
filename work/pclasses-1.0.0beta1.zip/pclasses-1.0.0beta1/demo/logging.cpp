/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <pclasses/plogplugin.h>
#include <pclasses/plog.h>
#include <pclasses/ptime.h>
#include <pclasses/pconfig.h>
#include <pclasses/pxmlconfigstore.h>
#include <iostream>

using namespace std;
using namespace P;

int main(int argc, char* argv[])
{
  LoggerPluginFactory* factory = new LoggerPluginFactory();

  SystemLog* syslog = new SystemLog("logtest");

  Logger* consolelog = factory->create("console");
  if(consolelog)
  {
    consolelog->start("stdout");
    syslog->addLogger(consolelog);
  }

  Logger* filelog = factory->create("file");
  if(filelog)
  {
    filelog->start("logging.log");
    syslog->addLogger(filelog);
  }

  Logger* sqllog = factory->create("sql");
  if(filelog)
  {
    sqllog->start("driver=mysql;user=bla;passwd=bla;hostname=localhost;dbname=test");
    syslog->addLogger(sqllog);
  }

  for(int i = 0; i < 10; ++i)
    (*syslog)(LOG_INFO) << "this is a test log message" << endl;

  delete syslog;

  if(sqllog)
    factory->destroy(sqllog);
  if(consolelog)
    factory->destroy(consolelog);
  if(filelog)
    factory->destroy(filelog);

  delete factory;
}
