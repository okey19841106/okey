/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2003  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */


#include <pclasses/pftpclient.h>
#include <pclasses/pinetaddr.h>
#include <pclasses/pnetdb.h>
#include <iostream>

using namespace P;
using namespace std;

int main(int argc, char* argv[])
{
  NetDb::HostEntry he;

  try {

    cout << "Looking up host '" << argv[1] << "' ..." << endl;
    he = NetDb::hostByName(argv[1], AF_INET);

    FTPClient cl(he.addr(0).family());

    cout << "Connecting to " << he.addr(0).str() << "..." << endl;
    cl.connect(he.addr(0), 21);

    cout << "Logging in ..." << endl;
    cl.login("anonymous", "test@", "");

    string dir = cl.cwd();

    cout << "Current working directory: " << dir << endl;
  }
  catch(NetDbError& e)
  {
    cout << e.what() << ": " << e.text() << endl;
  }
  catch(FTPError& e)
  {
    cout << e.what() << endl;
  }

  return 0;
}
