/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2002  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <pclasses/pthread_.h>
#include <pclasses/pnamedpipe.h>
#include <iostream>

using namespace P;
using namespace std;

class ServerClientThread: public Thread, private NamedPipe {
  public:
    ServerClientThread(NamedPipeServer& srv) throw(IOError)
    : Thread(), NamedPipe(srv)
    {
      start();
    }

    ServerClientThread::~ServerClientThread() throw()
    {
    }

  protected:
    bool initial()
    { return true; }

    void main()
    {
      char* welcome = "welcome!\n";

      write(welcome, strlen(welcome));

      cout << "Sent." << endl;
      close();
    }

    void final()
    {
      cout << "Disconnected" << endl;
      delete this;
    }
};

int main(int argc, char* argv[])
{
  NamedPipeServer* srv;

  try {
    srv = new NamedPipeServer("/tmp/pclasses-np-demo");
  }
  catch(IOError& e)
  {
    cout << "Could not create named pipe:" << e.errnum() << endl;
    return 1;
  }

  while(1)
  {
    if(srv->waitClient(1000))
    {
      cout << "New client connected" << endl;
      new ServerClientThread(*srv);
    }
  }

}
