/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2002  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <pclasses/psqlplugin.h>
#include <pclasses/psqlconnection.h>
#include <pclasses/psqlstatement.h>
#include <pclasses/pconfig.h>
#include <pclasses/pxmlconfigstore.h>
#include <iostream>

using namespace std;
using namespace P;

int main(int argc, char* argv[])
{
  XMLConfigStore cfgStore("sql.xml");
  Config cfg(cfgStore);

  SQLDriverPluginFactory* factory = new SQLDriverPluginFactory();
 
  Config::Key* pluginsCfg = cfg.root().key("sql-plugins");
  if(!pluginsCfg)
  {
    cout << "Configuration key 'sql-plugins' not found." << endl;
    return 1;
  }
  
  Config::Key::value_iterator i = pluginsCfg->values().begin();
  for(; i != pluginsCfg->values().end(); ++i)
  {
    factory->addPlugin(i->second.c_str());
  }

  SQLDriver* driver = factory->create("mysql");
  if(!driver)
  {
    cerr << "Mysql driver not found." << endl;
    delete factory;
    return 1;
  }
  
  cout << "Connecting to database..." << endl;
  
  try
  {
    SQLConnection sqlconn(driver, "root", "root", "mysql", "");
    
    SQLStatement userStmt(sqlconn);
    userStmt << "SELECT * FROM user";

    SQLStatement hostStmt(sqlconn);
    hostStmt << "SELECT * FROM host";
        
    SQLResult userRes(userStmt);
    SQLResult hostRes(hostStmt);
    
    for(int i = 0; i < userRes.columnCount(); ++i)
      cout << userRes.columnName(i) << " ";
    
    cout << endl;
      
    while(userRes.fetch())
    {
      for(int i = 0; i < userRes.columnCount(); ++i)
        cout << userRes[userRes.columnName(i)].str() << " ";
      cout << endl;
    }

    for(int i = 0; i < hostRes.columnCount(); ++i)
      cout << hostRes.columnName(i) << " ";
    
    cout << endl;
      
    while(hostRes.fetch())
    {
      for(int i = 0; i < hostRes.columnCount(); ++i)
        cout << hostRes[hostRes.columnName(i)].str() << " ";
      cout << endl;
    }
  }
  catch(SQLError& e)
  {
    cerr << "Database error: " << e.text() << endl;
  }
  
  factory->destroy(driver);
  delete factory;
  
  return 0;
}
