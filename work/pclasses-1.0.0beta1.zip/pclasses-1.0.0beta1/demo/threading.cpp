/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2002  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <pclasses/pthread_.h>
#include <iostream>

using namespace P;
using namespace std;

class MyWorker: public Thread {
  protected:
    bool initial();
    void main();
    void suspended();
    void resumed();
    void final();
};


bool MyWorker::initial()
{
  cout << "init" << endl;
  return true;
}

void MyWorker::main()
{
  cout << "running" << endl;
  while(!testCancel())
  {
    cout << "hello from thread" << endl;
    Thread::sleep(10);
  }
}

void MyWorker::suspended()
{
  cout << "suspended" << endl;
}

void MyWorker::resumed()
{
  cout << "resumed" << endl;
}

void MyWorker::final()
{
  cout << "final" << endl;
}

int main(int argc, char* argv[])
{
  Semaphore sem;
  MyWorker* worker = new MyWorker;

  worker->start(&sem);
  sem.wait();

  Thread::sleep(100);
  
  if(!worker->suspend(1000))
  {
    cout << "could not suspend thread" << endl;
    return 1;
  }

  worker->resume();

  Thread::sleep(100);
      
  if(!worker->stop(1000))
  {
    cout << "could not stop thread" << endl;
    return 1;
  }
      
  delete worker;
}
