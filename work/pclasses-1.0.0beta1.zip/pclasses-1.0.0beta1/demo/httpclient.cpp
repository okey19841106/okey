/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2002  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */


#include <pclasses/phttpclient.h>
#include <pclasses/pinetaddr.h>
#include <pclasses/pnetdb.h>
#include <pclasses/ptypes.h>
#include <iostream>

using namespace P;
using namespace std;

int main(int argc, char* argv[])
{
  NetDb::HostEntry he;

  try {
    he = NetDb::hostByName("equinoxx.darklab.org", AF_INET);
    cout << he.name() << endl;
    cout << InetAddress(he.addr(0)) << endl;
  }
  catch(NetDbError& e)
  {
    cout << e.what() << ": " << e.text() << endl;
  }
    
  HTTPClient httpc(AF_INET);
  httpc.connect(InetAddress("192.168.1.16"), 80);

  HTTPRequest req(HTTPRequest::METHOD_GET, URL("http://equinox.darklab.org/"));
  req.header().setConnection("keep-alive");
  httpc.sendRequest(req);

  auto_ptr<HTTPResponse> resp = httpc.readResponse();

  HTTPHeader::const_iterator i = resp->header().begin();
  while(i != resp->header().end())
  {
    cout << i->first << ": " << i->second << "\r\n";
    ++i;
  }

  P::size_t ret;
  char buff[1024];

  do {
    ret = httpc.readBody(*resp, buff, 1024);
    if(ret > 0)
      cout.write(buff, ret);
    else
      break;
  
  } while(ret > 0);


  HTTPRequest req2(HTTPRequest::METHOD_GET, URL("http://equinox.darklab.org/"));
  req2.header().setConnection("keep-alive");
  httpc.sendRequest(req2);

  auto_ptr<HTTPResponse> resp2 = httpc.readResponse();

  HTTPHeader::const_iterator i2 = resp2->header().begin();
  while(i2 != resp2->header().end())
  {
    cout << i2->first << ": " << i2->second << "\r\n";
    ++i2;
  }

  do {
    ret = httpc.readBody(*resp2, buff, 1024);
    if(ret > 0)
      cout.write(buff, ret);
    else
      break;

  } while(ret > 0);
 
  
  //httpc.head();
}
