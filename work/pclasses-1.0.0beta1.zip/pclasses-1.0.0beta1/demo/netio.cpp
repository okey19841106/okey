/*
 *   P::Classes - Portable C++ Application Framework
 *   Copyright (C) 2000-2004  Christian Prochnow <cproch@seculogix.de>
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "pclasses/piomanager.h"
#include "pclasses/piorequest.h"
#include <iostream>

using namespace std;
using namespace P;

int main(int argc, char* argv[])
{
  if(argc < 3)
  {
    cerr << "Usage: netio [method] [url]" << endl;
    cerr << "method = GET|MKDIR|RMDIR|UNLINK|LIST" << endl;
    return 1;
  }

  string method = argv[1];
  URL url = string(argv[2]);

  IOManager* ioman = new IOManager();

  try
  {
    ioman->addPlugin("../src/plugins/io/file/.libs/pio_file.so");
    ioman->addPlugin("../src/plugins/io/http/.libs/pio_http.so");
    ioman->addPlugin("../src/plugins/io/ftp/.libs/pio_ftp.so");

    if(method == "GET")
    {
      IORequest_Get* job = ioman->get(url);
      job->open();

      char buffer[4096];
      size_t ret = 0;

      do
      {
        ret = job->receive(buffer, sizeof(buffer));
        cout.write(buffer, ret);
      }
      while(ret > 0);

      job->close();
      ioman->finish(job);
    }
    else if(method == "MKDIR")
    {
      IORequest_MakeDir* job = ioman->mkdir(url);
      job->mkdir();
      ioman->finish(job);
    }
    else if(method == "RMDIR")
    {
      IORequest_RemoveDir* job = ioman->rmdir(url);
      job->rmdir();
      ioman->finish(job);
    }
    else if(method == "DEL")
    {
      IORequest_Unlink* job = ioman->unlink(url);
      job->unlink();
      ioman->finish(job);
    }
    else if(method == "LIST")
    {
      IORequest_ListDir* job = ioman->list(url);
      job->list();
      ioman->finish(job);
    }
    else
    {
      cerr << "Unknown method." << endl;
    }
  }
  catch(IORequest::Error& e)
  {
    cerr << e.what() << ": " << e.text() << endl;
  }
  catch(IOError& e)
  {
    cerr << e.text() << endl;
  }
  catch(RuntimeError& e)
  {
    cerr << e.what() << endl;
  }

  delete ioman;
}
