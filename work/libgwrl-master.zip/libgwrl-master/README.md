# LIBGWRL

A high performance cross platform event reactor and proactor written in C.
Featuring kqueue, epoll, poll, select, IO Completion Ports for Windows,
and a small code base with minimal #ifdef source splitting.

# WEBSITE

http://gngrwzrd.com/libgwrl/

# DOCUMENTATION

http://gngrwzrd.com/libgwrl/pod.html
