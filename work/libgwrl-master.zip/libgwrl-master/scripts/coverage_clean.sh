#!/bin/bash
../../scripts/runtest.py -s ./ -d 1
rm -rf ../gcov_files/