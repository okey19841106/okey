#!/bin/bash
pod2html ../../docs/pod/doc.pod --css=pod.css > ../../docs/html/pod.html